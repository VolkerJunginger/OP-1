/* SPDX-License-Identifier: GPL-3.0-only */
#include <assert.h>
#include <stdio.h>
#include <stdarg.h>
#include <math.h>
#include <string.h>
#include "plugin/device.c"
#include "plugin/dsp.c"

static int16_t rings[2][RING_WORDS];
static unsigned allocations;
static const struct opus_hosted_effect *host;
static int focus, shift, browser;
static void (*observed_key)(int, int);
static void (*observed_knob)(int, short);
static int text_draws;
static unsigned char segment_fills[14][4], logo_colours[sizeof logo_banks][4];
static int control_y[6], control_size[6], text_objects;
static const struct opus_folder *folder;
static unsigned char incoming[ROM_MAX], stored[ROM_BANKS][ROM_MAX];
static unsigned position[3 + ROM_BANKS], stored_size[ROM_BANKS], incoming_size;

int opus_on_folder(struct opl_self *self, const struct opus_folder *f)
{
    assert(self && !strcmp(f->name, "mv1rom") && f->max == ROM_MAX);
    folder = f;
    return 1;
}

void *opus_alloc_audio(struct opl_self *self, unsigned bytes)
{
    (void)self;
    assert(allocations < 2 && bytes == sizeof rings[0]);
    return rings[allocations++];
}
int opus_effect_host(struct opl_self *self, const struct opus_hosted_effect *effect)
{
    (void)self;
    assert(effect->size == sizeof *effect);
    host = effect;
    return 0x5355;
}
int opus_flash_headroom(void) { return 32768; }
int opus_fn_held(void) { return 0; }
int opus_fx_owner(void) { return focus; }
int opus_fx_list_shown(void) { return browser; }
int opus_sound_slot(int instrument) { (void)instrument; return 0; }
void opus_on_key_after(struct opl_self *self, void (*fn)(int, int))
{ assert(self && fn); observed_key = fn; }
void opus_on_knob_after(struct opl_self *self, void (*fn)(int, short))
{ assert(self && fn); observed_knob = fn; }
int fw_shift_held(void) { return shift; }
int fw_yaffs_stat(const char *path, unsigned *st) { (void)path; (void)st; return -1; }
int fw_yaffs_mkdir(const char *path, int mode) { (void)path; (void)mode; return 0; }
int fw_yaffs_open(const char *path, int flags, int mode)
{
    (void)mode;
    if (!strcmp(path, "/yaffs2/mod/esc.midiverb/screen.svg")) return 1;
    if (!strcmp(path, "/incoming")) { position[2] = 0; return 2; }
    for (unsigned bank = 0; bank < ROM_BANKS; ++bank) {
        if (strcmp(path, banks[bank].path)) continue;
        position[3 + bank] = 0;
        if (flags) stored_size[bank] = 0;
        else if (!stored_size[bank]) return -1;
        return 3 + (int)bank;
    }
    assert(0);
    return -1;
}
int fw_yaffs_close(int fd) { assert(fd >= 1 && fd < 3 + ROM_BANKS); return 0; }
int fw_yaffs_unlink(const char *path)
{
    for (unsigned bank = 0; bank < ROM_BANKS; ++bank)
        if (!strcmp(path, banks[bank].path)) { stored_size[bank] = 0; return 0; }
    return -1;
}
int fw_yaffs_read(int fd, void *buf, unsigned n)
{
    assert(fd >= 2 && fd < 3 + ROM_BANKS);
    unsigned size = fd == 2 ? incoming_size : stored_size[fd - 3];
    if (n > size - position[fd]) n = size - position[fd];
    memcpy(buf, (fd == 2 ? incoming : stored[fd - 3]) + position[fd], n);
    position[fd] += n;
    return (int)n;
}
int fw_yaffs_write(int fd, const void *buf, unsigned n)
{
    if (fd == 1) assert(buf == screen_svg && n == sizeof screen_svg - 1);
    else {
        assert(fd >= 3 && fd < 3 + ROM_BANKS && stored_size[fd - 3] + n <= ROM_MAX);
        memcpy(stored[fd - 3] + stored_size[fd - 3], buf, n);
        stored_size[fd - 3] += n;
    }
    return (int)n;
}
void *fw_text_new(void *mem, int x, int y, int size, const unsigned char *rgba, int align)
{
    assert(x >= 0 && x <= 320 * 1024 && y >= 0 && y + size <= 146);
    assert(rgba && align >= 0 && align <= 2);
    if (text_objects < 6) {
        control_y[text_objects] = y;
        control_size[text_objects] = size;
        assert(align == (text_objects & 1 ? 2 : 0));
    }
    ++text_objects;
    return mem;
}
void fw_text_draw(void *mem, void *raster, const int *matrix)
{ (void)mem; (void)raster; (void)matrix; ++text_draws; }
void fw_set_text(void *mem, const char *str) { (void)mem; assert(strlen(str) < 32); }
void *fw_screen_raster(void) { return 0; }
void fw_screen_draw(void *scr) { assert(scr); }

int fw_snprintf(char *dst, unsigned size, const char *format, ...)
{
    va_list args;
    va_start(args, format);
    int result = vsnprintf(dst, size, format, args);
    va_end(args);
    return result;
}

void *fw_svg_node_find(void *document, const char *id, int warn)
{
    assert(document && !warn && (!strncmp(id, "seg", 3) || !strncmp(id, "logo", 4)));
    return document;
}

void *fw_screen_fill(void *scr, const char *id)
{
    if (!strncmp(id, "logo", 4)) {
        int index = (id[4] - '0') * 10 + id[5] - '0';
        assert(scr && index >= 0 && (unsigned)index < sizeof logo_banks);
        return logo_colours[index];
    }
    int index = (id[3] - '0') * 10 + id[4] - '0';
    assert(scr && index >= 0 && index < 14);
    return segment_fills[index];
}

static double filter_gain(double frequency)
{
    struct tank state = {0};
    double in_energy = 0, out_energy = 0;
    for (int i = 0; i < 8192; ++i) {
        int in = (int)(12000 * sin(6.283185307179586 * frequency * i / 44100));
        int out = reconstruct(&state, in);
        if (i > 256) {
            in_energy += in * in;
            out_energy += out * out;
        }
    }
    return 10 * log10(out_energy / in_energy);
}

static void (*setting_callback)(const char *, int);
int opus_setting(struct opl_self *self, const char *name)
{ assert(self && (!strcmp(name, "reconstruction") || !strcmp(name, "engine"))); return !strcmp(name, "reconstruction"); }
void opus_on_setting(struct opl_self *self, void (*fn)(const char *, int))
{ assert(self && fn); setting_callback = fn; }

static void test_bypass(void)
{
    static int16_t on_ring[RING_WORDS], off_ring[RING_WORDS];
    struct tank on = {.ring = on_ring, .clear_at = RING_WORDS, .wet_new = 12000};
    struct tank off = on;
    off.ring = off_ring;
    short filtered[64] = {0}, raw[64] = {0};
    const unsigned controls[4] = {0, 90, 0, 100};
    tank_render(&on, filtered, controls, 0, 1, 0);
    tank_render(&off, raw, controls, 0, 0, 0);
    assert(memcmp(filtered, raw, sizeof raw));
    assert(on.feedback == off.feedback && !memcmp(on_ring, off_ring, sizeof on_ring));
    assert(!off.dac_z1 && !off.dac_z2 && !off.dac_z3);
}

static void test_engines(void)
{
    static int16_t original_ring[RING_WORDS], lite_ring[RING_WORDS];
    struct tank original = {.ring = original_ring, .clear_at = RING_WORDS};
    struct tank lite = {.ring = lite_ring, .clear_at = RING_WORDS};
    unsigned controls[4] = {50, 90, 0, 100};
    short a[64] = {24000}, b[64] = {24000};
    for (int i = 0; i < 200; ++i) {
        tank_render(&original, a, controls, 0, 1, 0);
        tank_render(&lite, b, controls, 0, 1, 1);
        assert(!memcmp(a, b, sizeof a));
        memset(a, 0, sizeof a);
        memset(b, 0, sizeof b);
    }
    for (unsigned bank = 0; bank < ROM_BANKS; ++bank) {
        for (unsigned program = 0; program < banks[bank].programs; ++program) {
            if (!lite_profile(bank, program)) continue;
            memset(lite_ring, 0, sizeof lite_ring);
            tank_reset(&lite);
            lite.clear_at = RING_WORDS;
            controls[0] = program;
            int heard = 0;
            b[0] = 24000;
            for (int block = 0; block < 128; ++block) {
                tank_render(&lite, b, controls, bank, 1, 1);
                for (int j = 0; j < 64; ++j) heard |= b[j];
                memset(b, 0, sizeof b);
            }
            assert(heard);
        }
    }
}

int main(int argc, char **argv)
{
    assert(argc == 4);
    test_bypass();
    test_engines();
    assert(fabs(filter_gain(1000)) < 0.2);
    assert(fabs(filter_gain(10136) + 3.01) < 0.1);
    assert(fabs(filter_gain(18000) + 24.31) < 0.2);
    struct opl_self self = {sizeof self, "esc.midiverb", "/yaffs2/mod/esc.midiverb", 0};
    assert(opl_init(&self) == 0 && allocations == 2 && folder && !rom_ready);
    assert(reconstruction && setting_callback);
    setting_callback("reconstruction", 0);
    assert(!reconstruction);
    setting_callback("reconstruction", 1);
    assert(reconstruction);
    short par[8];
    memcpy(par, host->defaults, sizeof par);
    short block[64], backup[64];
    for (int i = 0; i < 64; ++i) block[i] = backup[i] = (short)(i * 123);
    host->render(0, block, par);
    assert(!memcmp(block, backup, sizeof block));
    void *screen = &self;
    host->screen_init(&screen);
    host->screen_draw(&screen, 0);
    for (int i = 0; i < 6; i += 2)
        assert(control_y[i] == control_y[i + 1] && control_size[i] == control_size[i + 1]);
    assert(text_draws == 7 && !strcmp(text[6].shown, "add rom in mods/mv1rom"));
    for (unsigned bank = 0; bank < ROM_BANKS; ++bank) {
        FILE *f = fopen(argv[bank + 1], "rb");
        assert(f);
        incoming_size = (unsigned)fread(incoming, 1, ROM_MAX, f);
        assert(incoming_size == banks[bank].size);
        fclose(f);
        incoming[0] ^= 1;
        assert(!folder->take(banks[bank].file, "/incoming") && !stored_size[bank]);
        incoming[0] ^= 1;
        assert(!folder->take("other.bin", "/incoming"));
        assert(folder->take(banks[bank].file, "/incoming"));
    }
    folder->changed();
    assert(rom_ready == 7);
    assert(!low_cpu);
    setting_callback("engine", 1);
    host->render(0, block, par);
    assert(low_cpu && active_engine[0] == 1 && tanks[0].clear_at == 2048);
    setting_callback("engine", 0);
    host->render(0, block, par);
    assert(!low_cpu && active_engine[0] == 0 && tanks[0].clear_at == 2048);
    par[0] = encode(0, 13, 0);
    host->render(0, block, par);
    host->screen_draw(&screen, 0);
    assert(!strcmp(text[6].shown, "1.0 sec medium warm"));
    unsigned expected_14 = 6 | (102u << 7);
    for (int i = 0; i < 14; ++i)
        assert(segment_fills[i][0] == ((expected_14 & (1u << i)) ? 255 : 43));
    memcpy(block, backup, sizeof block);
    assert(!host->key(0, 0x3b, 1) && !host->key(0, 0x3b, 0));
    assert(!host->key(2, 0x3e, 1));
    host->render_stereo(2, block, backup, par);
    assert(!memcmp(block, backup, sizeof block));
    /* MIDIverb I: 01, II: 17, MidiFex: 25. Each bank restores its own choice. */
    assert(host->turn(0, par, 3, -100));
    const unsigned wanted[] = {0, 17, 24};
    for (unsigned i = 1; i < ROM_BANKS; ++i) {
        assert(host->key(0, 0x3e, 1) && current_bank(0) == bank_order[i]);
        assert(bank_program[0][bank_order[i]] == 0);
        assert(host->turn(0, par, 3, (int)wanted[i]));
    }
    for (unsigned i = 0; i < ROM_BANKS; ++i) {
        assert(host->key(0, 0x3e, 1) && current_bank(0) == bank_order[i]);
        host->render(0, block, par);
        assert(active_program[0] == wanted[i] && bank_program[0][bank_order[i]] == wanted[i]);
    }
    assert(host->key(0, 0x3e, 1) && current_bank(0) == 0);
    unsigned noise = 42;
    for (unsigned i = 0; i < ROM_BANKS; ++i) {
        unsigned bank = bank_order[i];
        assert(current_bank(0) == bank && current_bank(1) == 0);
        assert(host->turn(0, par, 3, 100) && bank_program[0][bank] == banks[bank].programs - 1);
        assert(host->turn(0, par, 3, -100) && bank_program[0][bank] == 0);
        assert(host->turn(0, par, 0, 100) && decode(2, par[2], bank) == 100);
        assert(host->turn(0, par, 2, 100) && decode(3, par[3], bank) == 100);
        host->screen_draw(&screen, 0);
        for (unsigned i = 0; i < sizeof logo_banks; ++i)
            assert(logo_colours[i][3] == ((logo_banks[i] & (1u << bank)) ? 255 : 0));
        assert(!strcmp(text[0].shown, "feedback") && !strcmp(text[4].shown, "mix"));
        int active = 0;
        for (unsigned program = 0; program < banks[bank].programs; ++program) {
            assert(host->turn(0, par, 3, program != 0));
            for (int n = 0; n < 230; ++n) {
                for (int i = 0; i < 64; ++i) {
                    noise = noise * 1664525u + 1013904223u;
                    block[i] = (short)(noise >> 16);
                }
                par[1] = encode(1, (unsigned)n % 101, bank);
                host->render(0, block, par);
                for (int i = 0; i < 64; ++i) active |= block[i];
            }
        }
        assert(active);
        assert(host->key(0, 0x3e, 1) && host->key(0, 0x3e, 0));
    }
    assert(current_bank(0) == 0);
    par[3] = encode(3, 0, 0);
    memcpy(block, backup, sizeof block);
    host->render(0, block, par);
    assert(!memcmp(block, backup, sizeof block));
    stored_size[1] = 0;
    folder->changed();
    assert(rom_ready == 5 && host->key(0, 0x3e, 1) && current_bank(0) == 2);
    /* A synth reload may replace the OS parameters even when this FX stays. */
    assert(host->turn(0, par, 3, 52 - (int)bank_program[0][2]));
    par[1] = encode(1, 12, 2);
    par[2] = encode(2, 80, 2);
    par[3] = encode(3, 65, 2);
    for (int i = 0; i < 12; ++i) host->render(0, block, par);
    assert(active_program[0] == 52 && active_bank[0] == 2 && tanks[0].pointer);
    unsigned previous_pointer = tanks[0].pointer;
    memcpy(par, host->defaults, sizeof par);
    host->init(0);
    host->render(0, block, par);
    assert(current_bank(0) == 2 && active_program[0] == 52);
    assert(cached_controls[0].decoded[1] == 12 && cached_controls[0].decoded[2] == 80 &&
           cached_controls[0].decoded[3] == 65 && tanks[0].pointer > previous_pointer);
    assert(host->turn(0, par, 2, 1));
    host->render(0, block, par);
    assert(cached_controls[0].decoded[0] == 52 && cached_controls[0].decoded[1] == 12 &&
           cached_controls[0].decoded[2] == 80 && cached_controls[0].decoded[3] == 66);

    /* A committed effect choice can initialize after the browser closes. */
    browser = 1;
    observed_key(0x25, 1);
    observed_knob(0, 1024);
    browser = 0;
    memcpy(par, host->defaults, sizeof par);
    host->init(0);
    host->render(0, block, par);
    assert(current_bank(0) == 0 && active_program[0] == 0 && tanks[0].pointer == 0);
    assert(cached_controls[0].decoded[1] == 90 && cached_controls[0].decoded[2] == 0 &&
           cached_controls[0].decoded[3] == 50);
    memset(stored_size, 0, sizeof stored_size);
    folder->changed();
    assert(!rom_ready);
    memcpy(block, backup, sizeof block);
    host->render(0, block, par);
    assert(!memcmp(block, backup, sizeof block));
    puts("PASS: all ROM banks, ROM switching, new controls, filter and mono audio stress");
}
