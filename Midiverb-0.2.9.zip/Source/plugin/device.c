/* SPDX-License-Identifier: GPL-3.0-only */
#include "opus_plugin.h"
#include "op1fw.h"
#include "dsp.h"
#include "screen_data.h"
#include "screen_file.h"
#include "rom_file.h"
#include "names.h"

static struct tank tanks[2];
static volatile unsigned selected_bank[2], screen_controls[3];
static volatile unsigned bank_program[2][ROM_BANKS];
static short last_program_word[2];
static const unsigned bank_order[] = {0, 2, 1};
static unsigned active_program[2], active_rom[2], active_bank[2];
static struct control_cache {
    short raw[4];
    unsigned decoded[4], bank;
} cached_controls[2];
static char screen_path[256];
static struct opus_hosted_effect effect;
/* Hosted init runs for synth changes as well as effect selection.
 * The browser observers identify selections without taking any keys. */
enum { NO_INIT, RELOAD, EFFECT_CHOICE };
static unsigned pending_init[2], has_controls[2];
static volatile unsigned effect_choice[16], held_mask[2];
static short reload_baseline[2][4], held_words[2][4];

static void mark_browser_choice(void)
{
    if (!opus_fx_list_shown()) return;
    int owner = opus_fx_owner();
    if (owner >= 0 && owner < 16) effect_choice[owner] = 1;
}

static void after_key(int key, int pressed)
{
    if (!pressed) return;
    if (key == 0x24 || key == 0x25) mark_browser_choice();
    else if (!opus_fx_list_shown())
        for (int i = 0; i < 16; ++i) effect_choice[i] = 0;
}

static void after_knob(int encoder, short delta)
{
    (void)encoder;
    if (delta) mark_browser_choice();
}

static const short low[4] = {64, 0, 0, 8192};
static const short high[4] = {14528, 24576, 22528, 32767};
static const unsigned defaults[4] = {0, 90, 0, 50};
/* Physical encoders are reordered while native sound words keep their original layout. */
static const unsigned control_word[4] = {2, 1, 3, 0};

static unsigned current_bank(int pos)
{
    unsigned loaded = rom_ready;
    unsigned bank = selected_bank[pos];
    if (loaded & (1u << bank)) return bank;
    for (unsigned i = 0; i < ROM_BANKS; ++i)
        if (loaded & (1u << bank_order[i])) return bank_order[i];
    return 0;
}

static unsigned decode(int encoder, short value, unsigned bank)
{
    unsigned max = encoder ? 100 : banks[bank].programs - 1;
    int range = high[encoder] - low[encoder];
    int offset = value - low[encoder];
    if (offset <= 0) return 0;
    if (offset >= range) return max;
    return (unsigned)((offset * (int)max + range / 2) / range);
}

static short encode(int encoder, unsigned value, unsigned bank)
{
    unsigned max = encoder ? 100 : banks[bank].programs - 1;
    return (short)(low[encoder] + ((high[encoder] - low[encoder]) * (int)value + (int)max / 2) / (int)max);
}

static unsigned pack_controls(const short *par, unsigned bank)
{
    unsigned packed = 0;
    for (int i = 0; i < 4; ++i) packed |= decode(i, par[i], bank) << (i * 7);
    return packed;
}

static void initialize(int pos)
{
    if (pos == 2) return;
    int owner = pos * 8 + opus_sound_slot(pos);
    unsigned choice = owner >= 0 && owner < 16 ? effect_choice[owner] : 0;
    if (owner >= 0 && owner < 16) effect_choice[owner] = 0;
    int browser = opus_fx_list_shown() && opus_fx_owner() == owner;
    pending_init[pos] = browser || choice ? EFFECT_CHOICE : RELOAD;
}

static void apply_init(int pos, const short *par)
{
    unsigned pending = pending_init[pos];
    if (pending == NO_INIT) return;
    pending_init[pos] = NO_INIT;
    struct control_cache *cache = &cached_controls[pos];
    /* A browser selection carries the native default words. Synth and
     * preset loads can call init without committing an effect selection. */
    int fresh = pending == EFFECT_CHOICE;
    for (int i = 0; i < 4; ++i)
        if (par[i] != effect.defaults[i]) fresh = 0;

    if (has_controls[pos]) last_program_word[pos] = par[0];
    if (fresh || !has_controls[pos]) {
        tank_reset(&tanks[pos]);
        if (fresh) {
            selected_bank[pos] = 0;
            for (unsigned i = 0; i < ROM_BANKS; ++i) bank_program[pos][i] = 0;
        }
        held_mask[pos] = 0;
        return;
    }
    for (int i = 1; i < 4; ++i) {
        reload_baseline[pos][i] = par[i];
        held_words[pos][i] = cache->raw[i];
    }
    held_mask[pos] = 14;
}

static volatile int reconstruction = 1, low_cpu;
static int active_engine[2];

static void setting_changed(const char *name, int value)
{
    if (same_name(name, "reconstruction")) reconstruction = value != 0;
    else if (same_name(name, "engine")) low_cpu = value != 0;
}

static void mono(int pos, short *buf, const short *par)
{
    if (pos == 2) return;
    apply_init(pos, par);
    unsigned bank = current_bank(pos);
    struct control_cache *cache = &cached_controls[pos];
    if ((!has_controls[pos] && bank == 0) ||
        (cache->bank == bank && par[0] != last_program_word[pos]))
        bank_program[pos][bank] = decode(0, par[0], bank);
    last_program_word[pos] = par[0];
    cache->decoded[0] = bank_program[pos][bank];
    unsigned mask = held_mask[pos], packed = cache->decoded[0];
    for (int i = 1; i < 4; ++i) {
        if ((mask & (1u << i)) && par[i] != reload_baseline[pos][i]) mask &= ~(1u << i);
        short value = (mask & (1u << i)) ? held_words[pos][i] : par[i];
        if (value != cache->raw[i]) {
            cache->raw[i] = value;
            cache->decoded[i] = decode(i, value, bank);
        }
        packed |= cache->decoded[i] << (i * 7);
    }
    held_mask[pos] = mask;
    has_controls[pos] = 1;
    cache->bank = bank;
    screen_controls[pos] = packed;
    if (!rom_ready) return;
    unsigned revision = rom_revision;
    int engine = low_cpu;
    if (cache->decoded[0] != active_program[pos] ||
        revision != active_rom[pos] || bank != active_bank[pos] || engine != active_engine[pos]) {
        active_program[pos] = cache->decoded[0];
        active_rom[pos] = revision;
        active_bank[pos] = bank;
        active_engine[pos] = engine;
        tank_reset(&tanks[pos]);
        if (bank) extra_reset(tanks[pos].extra, bank, cache->decoded[0]);
    }
    tank_render(&tanks[pos], buf, cache->decoded, bank, reconstruction, engine);
}

static void master(int pos, short *left, short *right, const short *par)
{
    (void)pos; (void)left; (void)right; (void)par;
}

static int key(int pos, int code, int pressed)
{
    if (pos == 2 || opus_fn_held() || fw_shift_held()) return 0;
    if (code == 0x3e) {
        if (pressed) {
            unsigned bank = current_bank(pos), loaded = rom_ready;
            for (unsigned i = 0; i < ROM_BANKS; ++i) {
                bank = bank ? bank - 1 : ROM_BANKS - 1;
                if (loaded & (1u << bank)) {
                    selected_bank[pos] = bank;
                    break;
                }
            }
        }
        return 1;
    }
    return 0;
}

static int turn(int pos, short *par, int encoder, int detents)
{
    if (encoder < 0 || encoder > 3 || opus_fn_held()) return 0;
    if (pos == 2) return 1;
    unsigned bank = current_bank(pos), word = control_word[encoder];
    int max = word ? 100 : (int)banks[bank].programs - 1;
    if (detents < -100) detents = -100;
    if (detents > 100) detents = 100;
    unsigned mask = held_mask[pos];
    for (int i = 0; i < 4; ++i)
        if (mask & (1u << i)) par[i] = held_words[pos][i];
    int current = word ? (int)decode((int)word, par[word], bank) : (int)bank_program[pos][bank];
    int next = current + detents;
    if (next < 0) next = 0;
    if (next > max) next = max;
    if (!word) bank_program[pos][bank] = (unsigned)next;
    if (word || bank == 0) par[word] = encode((int)word, (unsigned)next, bank);
    held_mask[pos] = 0;
    screen_controls[pos] = pack_controls(par, bank);
    return 1;
}

struct screen_text {
    unsigned object[41];
    char shown[32];
};
static struct screen_text text[7];
static const int identity[9] = {1024, 0, 0, 0, 1024, 0, 0, 0, 1024};
static const unsigned char colours[3][4] = {
    {77, 158, 255, 255}, {0, 237, 149, 255}, {255, 255, 255, 255}
};
static unsigned char *segments[14];
static unsigned char *logo_fills[sizeof logo_banks];
static unsigned last_logo = ROM_BANKS;
static int text_ready;

static void screen_init(void *scr)
{
    if (!scr) return;
    void *document = *(void **)scr;
    for (int i = 0; i < 14; ++i) {
        char id[] = "seg00";
        id[3] += i / 10;
        id[4] += i % 10;
        segments[i] = document && fw_svg_node_find(document, id, 0) ? fw_screen_fill(scr, id) : 0;
    }
    for (unsigned i = 0; i < sizeof logo_banks; ++i) {
        char id[] = "logo00";
        id[4] += i / 10;
        id[5] += i % 10;
        logo_fills[i] = document && fw_svg_node_find(document, id, 0) ? fw_screen_fill(scr, id) : 0;
    }
    last_logo = ROM_BANKS;
    if (text_ready) return;
    for (int i = 0; i < 3; ++i) {
        fw_text_new(text[i * 2].object, 174 * 1024, 48 + i * 28, 11, colours[i], 0);
        fw_text_new(text[i * 2 + 1].object, 307 * 1024, 48 + i * 28, 11, colours[2], 2);
    }
    fw_text_new(text[6].object, 13 * 1024, 131, 11, colours[2], 0);
    text_ready = 1;
}

static void update_logo(unsigned bank)
{
    if (bank == last_logo) return;
    for (unsigned i = 0; i < sizeof logo_banks; ++i) {
        unsigned char *fill = logo_fills[i];
        if (fill) {
            fill[2] = 255;
            fill[3] = (logo_banks[i] & (1u << bank)) ? 255 : 0;
        }
    }
    last_logo = bank;
}

static void update_digits(unsigned number, int visible)
{
    static const unsigned char masks[10] = {63, 6, 91, 79, 102, 109, 125, 7, 127, 111};
    unsigned mask = visible ? masks[number / 10] | ((unsigned)masks[number % 10] << 7) : 0;
    for (int i = 0; i < 14; ++i) {
        unsigned char *colour = segments[i];
        if (colour) {
            int on = (mask >> i) & 1;
            colour[0] = on ? 255 : 43;
            colour[1] = on ? 41 : 13;
            colour[2] = on ? 71 : 20;
        }
    }
}

static void draw_text(int slot, const char *value)
{
    struct screen_text *t = text + slot;
    int n = 0;
    while (n < (int)sizeof t->shown - 1 && value[n] && value[n] == t->shown[n]) ++n;
    if (value[n] != t->shown[n]) {
        for (; n < (int)sizeof t->shown - 1 && value[n]; ++n) t->shown[n] = value[n];
        t->shown[n] = 0;
        fw_set_text(t->object, t->shown);
    }
    fw_text_draw(t->object, fw_screen_raster(), identity);
}

static void screen_draw(void *scr, int dt)
{
    (void)dt;
    if (!scr) return;
    static const char *const labels[] = {"feedback", "cutoff", "mix"};
    static const char *const *const names[] = {program_names, midifex_names, midiverb2_names};
    int owner = opus_fx_owner();
    int pos = owner == 16 ? 2 : (owner >= 8);
    unsigned bank = pos == 2 ? 0 : current_bank(pos);
    unsigned packed = screen_controls[pos];
    unsigned program = pos == 2 ? 0 : bank_program[pos][bank];
    if (program >= banks[bank].programs) program = banks[bank].programs - 1;
    update_logo(bank);
    update_digits(program + banks[bank].first, pos != 2 && rom_ready);
    fw_screen_draw(scr);
    if (!text_ready) return;
    if (pos == 2) draw_text(6, "synth / drum only");
    else if (!rom_ready) draw_text(6, "add rom in mods/mv1rom");
    else draw_text(6, names[bank][program]);
    for (int i = 0; i < 3; ++i) {
        char value[20];
        unsigned v = (packed >> (control_word[i] * 7)) & 127;
        if (i == 1) fw_snprintf(value, sizeof value, "%i hz", (int)(1000 + v * 100));
        else fw_snprintf(value, sizeof value, "%i%%", (int)v);
        draw_text(i * 2, labels[i]);
        draw_text(i * 2 + 1, value);
    }
}

static struct opus_hosted_effect effect = {
    .size = sizeof effect, .name = "midiverb",
    .init = initialize, .render = mono, .render_stereo = master,
    .svg = screen_path, .screen_init = screen_init, .screen_draw = screen_draw,
    .key = key, .turn = turn
};

int opl_init(struct opl_self *self)
{
    unsigned n = 0;
    while (self->folder[n] && n < sizeof screen_path - sizeof "/screen.svg") {
        screen_path[n] = self->folder[n];
        ++n;
    }
    if (self->folder[n]) return -1;
    const char *suffix = "/screen.svg";
    while (*suffix) screen_path[n++] = *suffix++;
    screen_path[n] = 0;
    for (int i = 0; i < 2; ++i) {
        tanks[i].ring = opus_alloc_audio(self, RING_WORDS * sizeof *tanks[i].ring);
        if (!tanks[i].ring) return -2;
        tank_reset(&tanks[i]);
    }
    for (int i = 0; i < 4; ++i) effect.defaults[i] = encode(i, defaults[i], 0);
    for (int i = 0; i < 3; ++i) screen_controls[i] = pack_controls(effect.defaults, 0);
    if (!native_screen_file(self, screen_path, screen_svg, sizeof screen_svg - 1)) return -3;
    if (!opus_on_folder(self, &rom_folder)) return -4;
    rom_changed();
    int result = opus_effect_host(self, &effect);
    if (result < 0) return result;
    reconstruction = opus_setting(self, "reconstruction") != 0;
    low_cpu = opus_setting(self, "engine") != 0;
    opus_on_setting(self, setting_changed);
    opus_on_key_after(self, after_key);
    opus_on_knob_after(self, after_knob);
    return 0;
}
