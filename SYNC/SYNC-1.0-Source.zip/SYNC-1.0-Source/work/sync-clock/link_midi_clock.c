/* SPDX-License-Identifier: GPL-3.0-or-later */
#include "link_midi_clock.h"

bool link_midi_clock_poll(struct link_midi_clock *clock,
                          const link_session *session, int64_t host_us)
{
    int64_t ghost, beat;
    if (!session->state.node || !link_session_peer_count(session) ||
        !link_clock_ghost_at(&session->clock, host_us, &ghost) ||
        !link_timeline_beat_at(&session->state.timeline, ghost, &beat)) {
        clock->armed = false;
        return false;
    }

    /* Floor(beat * 24 / 1000000) without overflowing on large timelines. */
    int64_t whole = beat / 1000000;
    int64_t remainder = beat % 1000000;
    if (remainder < 0) {
        --whole;
        remainder += 1000000;
    }
    int64_t tick = whole * 24 + remainder * 24 / 1000000;
    if (!clock->armed || clock->session_id != session->state.session) {
        clock->session_id = session->state.session;
        clock->last_tick = tick;
        clock->armed = true;
        return false;
    }

    if (tick <= clock->last_tick)
        return false;
    clock->last_tick = tick;
    return true;
}
