/* SPDX-License-Identifier: GPL-3.0-or-later */
#include "sample_clock.h"

int sync_sample_time(const struct sync_sample_clock *anchor, uint64_t sample,
                     uint64_t *monotonic_us)
{
    int earlier = sample < anchor->sample;
    uint64_t delta = earlier ? anchor->sample - sample : sample - anchor->sample;
    uint64_t whole = delta / 441;
    uint32_t remainder = (uint32_t)(delta % 441);
    uint32_t fraction = (remainder * 10000u + 220u) / 441u;
    uint64_t limit = earlier ? anchor->monotonic_us : UINT64_MAX - anchor->monotonic_us;
    if (whole > UINT64_MAX / 10000u)
        return 0;
    uint64_t elapsed = whole * 10000u;
    if (elapsed > limit || fraction > limit - elapsed)
        return 0;
    elapsed += fraction;
    *monotonic_us = earlier ? anchor->monotonic_us - elapsed
                            : anchor->monotonic_us + elapsed;
    return 1;
}
