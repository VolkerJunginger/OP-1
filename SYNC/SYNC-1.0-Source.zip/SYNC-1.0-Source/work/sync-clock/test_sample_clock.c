#include "sample_clock.h"
#include <assert.h>
#include <stdio.h>

int main(void)
{
    const struct sync_sample_clock anchor = {44100, 2000000};
    uint64_t time;
    assert(sync_sample_time(&anchor, 0, &time) && time == 1000000);
    assert(sync_sample_time(&anchor, 44100, &time) && time == 2000000);
    assert(sync_sample_time(&anchor, 44164, &time) && time == 2001451);
    assert(sync_sample_time(&anchor, 88200, &time) && time == 3000000);
    assert(!sync_sample_time(&anchor, UINT64_MAX, &time));
    const struct sync_sample_clock near_zero = {100, 0};
    assert(!sync_sample_time(&near_zero, 99, &time));
    const struct sync_sample_clock near_overflow = {100, UINT64_MAX};
    assert(!sync_sample_time(&near_overflow, 101, &time));
    puts("PASS 44.1 kHz monotonic sample time, rounding and overflow guards");
}
