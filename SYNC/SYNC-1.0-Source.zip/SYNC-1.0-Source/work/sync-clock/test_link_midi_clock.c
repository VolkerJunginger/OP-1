#include "link_midi_clock.h"
#include <assert.h>
#include <stdio.h>

int main(void)
{
    link_session session;
    assert(link_session_open(&session, 1, (link_endpoint){0xc0a80102, 5001}, 0, 500000));
    struct link_midi_clock clock = {0};
    assert(!link_midi_clock_poll(&clock, &session, 0));

    session.peers[0].state.node = 2;
    session.peers[0].expires = 1000000;
    session.peers[0].state.session = session.state.session;
    assert(!link_midi_clock_poll(&clock, &session, 0));
    assert(!link_midi_clock_poll(&clock, &session, 20832));
    assert(link_midi_clock_poll(&clock, &session, 20834));
    assert(!link_midi_clock_poll(&clock, &session, 20834));
    assert(link_midi_clock_poll(&clock, &session, 100000));
    assert(!link_midi_clock_poll(&clock, &session, 100000));
    assert(!link_midi_clock_poll(&clock, &session, 40000));
    assert(link_midi_clock_poll(&clock, &session, 105000));

    session.state.timeline.beat_origin = -1000000;
    session.state.timeline.time_origin = 200000;
    session.state.session = 3;
    session.peers[0].state.session = 3;
    assert(!link_midi_clock_poll(&clock, &session, 199999));
    assert(clock.last_tick == -25);
    assert(link_midi_clock_poll(&clock, &session, 200000));
    session.peers[0].expires = 0;
    assert(!link_midi_clock_poll(&clock, &session, 300000) && !clock.armed);
    puts("PASS Link MIDI clock boundaries, negative phase, skip, session and disconnect");
}
