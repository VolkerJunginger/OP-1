/* SPDX-License-Identifier: GPL-3.0-or-later */
#ifndef ESC_SAMPLE_CLOCK_H
#define ESC_SAMPLE_CLOCK_H
#include <stdint.h>

struct sync_sample_clock {
    uint64_t sample;
    uint64_t monotonic_us;
};

/* Project a sample position from a measured anchor at the nominal 44.1 kHz.
 * The anchor's timestamp must describe that sample, in the same monotonic
 * domain used for Link clock measurement. Round elapsed time to nearest us.
 * Returns zero if the resulting unsigned time is unrepresentable. */
int sync_sample_time(const struct sync_sample_clock *anchor, uint64_t sample,
                     uint64_t *monotonic_us);

#endif
