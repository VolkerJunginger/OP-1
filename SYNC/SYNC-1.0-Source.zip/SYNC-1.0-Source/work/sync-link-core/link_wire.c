/* SPDX-License-Identifier: GPL-2.0-or-later
 * Wire format from Ableton Link 4.1.1 discovery/v1 and link/v1,
 * Copyright Ableton AG. See README.md for exact reference and tests.
 */
#include "link_wire.h"

enum {
    TIMELINE = 0x746d6c6e, SESSION = 0x73657373, TRANSPORT = 0x73747374,
    MEASURE_IPV4 = 0x6d657034, AUDIO_IPV4 = 0x61657034,
    HOST_TIME = 0x5f5f6874, GHOST_TIME = 0x5f5f6774, PREV_GHOST_TIME = 0x5f706774
};

static const uint8_t discovery_magic[] = {'_', 'a', 's', 'd', 'p', '_', 'v', 1};
static const uint8_t measurement_magic[] = {'_', 'l', 'i', 'n', 'k', '_', 'v', 1};

static uint64_t read_be(const uint8_t *src, unsigned width)
{
    uint64_t value = 0;
    for (unsigned i = 0; i < width; ++i)
        value = (value << 8) | src[i];
    return value;
}

static int64_t read_signed(const uint8_t *src)
{
    const uint64_t bits = read_be(src, 8);
    return bits <= INT64_MAX ? (int64_t)bits : -1 - (int64_t)(UINT64_MAX - bits);
}

static uint8_t *write_be(uint8_t *dst, uint64_t value, unsigned width)
{
    for (unsigned i = width; i != 0; --i) {
        dst[i - 1] = (uint8_t)value;
        value >>= 8;
    }
    return dst + width;
}

static bool magic_matches(const uint8_t *src, const uint8_t *magic)
{
    for (unsigned i = 0; i < 8; ++i)
        if (src[i] != magic[i])
            return false;
    return true;
}

static void write_magic(uint8_t *dst, const uint8_t *magic)
{
    for (unsigned i = 0; i < 8; ++i)
        dst[i] = magic[i];
}

static uint8_t *entry_header(uint8_t *dst, uint32_t key, uint32_t size)
{
    return write_be(write_be(dst, key, 4), size, 4);
}

static uint8_t *entry_u64(uint8_t *dst, uint32_t key, uint64_t value)
{
    return write_be(entry_header(dst, key, 8), value, 8);
}

static uint8_t *entry_endpoint(uint8_t *dst, uint32_t key, link_endpoint endpoint)
{
    dst = write_be(entry_header(dst, key, 6), endpoint.ipv4, 4);
    return write_be(dst, endpoint.port, 2);
}

size_t link_discovery_encode(uint8_t *dst, size_t capacity, const link_discovery *msg)
{
    const bool bye = msg->type == LINK_BYE;
    const bool audio = msg->audio.port != 0;
    const size_t size = bye ? 20u : 107u + (audio ? 14u : 0u);

    if (capacity < size || msg->type < LINK_ALIVE || msg->type > LINK_BYE ||
        (!bye && (!msg->ttl || !msg->measurement.port || msg->timeline.us_per_beat <= 0)))
        return 0;

    write_magic(dst, discovery_magic);
    dst[8] = (uint8_t)msg->type;
    dst[9] = bye ? 0 : msg->ttl;
    dst[10] = 0;
    dst[11] = 0;
    uint8_t *out = write_be(dst + 12, msg->node, 8);
    if (!bye) {
        out = entry_header(out, TIMELINE, 24);
        out = write_be(out, (uint64_t)msg->timeline.us_per_beat, 8);
        out = write_be(out, (uint64_t)msg->timeline.beat_origin, 8);
        out = write_be(out, (uint64_t)msg->timeline.time_origin, 8);
        out = entry_u64(out, SESSION, msg->session);
        out = entry_header(out, TRANSPORT, 17);
        *out++ = msg->playing;
        out = write_be(out, (uint64_t)msg->transport_beat, 8);
        out = write_be(out, (uint64_t)msg->transport_timestamp, 8);
        out = entry_endpoint(out, MEASURE_IPV4, msg->measurement);
        if (audio)
            entry_endpoint(out, AUDIO_IPV4, msg->audio);
    }
    return size;
}

static bool claim_entry(unsigned *seen, unsigned mask, uint32_t size, uint32_t expected)
{
    if ((*seen & mask) || size != expected)
        return false;
    *seen |= mask;
    return true;
}

bool link_discovery_decode(link_discovery *msg, const uint8_t *src, size_t size)
{
    if (size < 20 || size >= LINK_SYNC_MAX_PACKET || !magic_matches(src, discovery_magic))
        return false;
    const unsigned type = src[8];
    if (type < LINK_ALIVE || type > LINK_BYE || src[10] || src[11])
        return false;

    link_discovery parsed = {0};
    parsed.type = (link_discovery_type)type;
    parsed.ttl = src[9];
    parsed.node = read_be(src + 12, 8);
    if (type == LINK_BYE) {
        if (size != 20 || parsed.ttl)
            return false;
        *msg = parsed;
        return true;
    }

    enum { HAS_TIMELINE = 1, HAS_SESSION = 2, HAS_TRANSPORT = 4, HAS_MEASURE = 8,
           HAS_AUDIO = 16, REQUIRED = HAS_TIMELINE | HAS_SESSION | HAS_MEASURE };
    unsigned seen = 0;
    const uint8_t *end = src + size;
    for (const uint8_t *entry = src + 20; entry < end;) {
        if (end - entry < 8)
            return false;
        const uint32_t key = (uint32_t)read_be(entry, 4);
        const uint32_t length = (uint32_t)read_be(entry + 4, 4);
        entry += 8;
        if (length > (size_t)(end - entry))
            return false;
        switch (key) {
        case TIMELINE:
            if (!claim_entry(&seen, HAS_TIMELINE, length, 24))
                return false;
            parsed.timeline.us_per_beat = read_signed(entry);
            parsed.timeline.beat_origin = read_signed(entry + 8);
            parsed.timeline.time_origin = read_signed(entry + 16);
            break;
        case SESSION:
            if (!claim_entry(&seen, HAS_SESSION, length, 8))
                return false;
            parsed.session = read_be(entry, 8);
            break;
        case TRANSPORT:
            if (!claim_entry(&seen, HAS_TRANSPORT, length, 17))
                return false;
            parsed.playing = entry[0] != 0;
            parsed.transport_beat = read_signed(entry + 1);
            parsed.transport_timestamp = read_signed(entry + 9);
            break;
        case MEASURE_IPV4:
        case AUDIO_IPV4: {
            const bool measure = key == MEASURE_IPV4;
            if (!claim_entry(&seen, measure ? HAS_MEASURE : HAS_AUDIO, length, 6))
                return false;
            link_endpoint *endpoint = measure ? &parsed.measurement : &parsed.audio;
            endpoint->ipv4 = (uint32_t)read_be(entry, 4);
            endpoint->port = (uint16_t)read_be(entry + 4, 2);
            break;
        }
        }
        entry += length;
    }

    if ((seen & REQUIRED) != REQUIRED || !parsed.ttl || !parsed.measurement.port ||
        parsed.timeline.us_per_beat <= 0)
        return false;
    *msg = parsed;
    return true;
}

size_t link_measurement_encode(uint8_t *dst, size_t capacity, const link_measurement *msg)
{
    const bool pong = msg->type == LINK_PONG;
    const size_t size = 25u + (pong ? 32u : 0u) + (msg->has_previous_ghost_time ? 16u : 0u);
    if (capacity < size || (!pong && msg->type != LINK_PING))
        return 0;

    write_magic(dst, measurement_magic);
    dst[8] = (uint8_t)msg->type;
    uint8_t *out = dst + 9;
    if (pong) {
        out = entry_u64(out, SESSION, msg->session);
        out = entry_u64(out, GHOST_TIME, (uint64_t)msg->ghost_time);
    }
    out = entry_u64(out, HOST_TIME, (uint64_t)msg->host_time);
    if (msg->has_previous_ghost_time)
        entry_u64(out, PREV_GHOST_TIME, (uint64_t)msg->previous_ghost_time);
    return size;
}

bool link_measurement_decode(link_measurement *msg, const uint8_t *src, size_t size)
{
    if (size < 9 || size >= LINK_SYNC_MAX_PACKET || !magic_matches(src, measurement_magic))
        return false;
    const unsigned type = src[8];
    if (type != LINK_PING && type != LINK_PONG)
        return false;

    enum { HAS_HOST = 1, HAS_GHOST = 2, HAS_PREVIOUS = 4, HAS_SESSION = 8 };
    unsigned seen = 0;
    link_measurement parsed = {0};
    parsed.type = (link_measurement_type)type;
    const uint8_t *end = src + size;
    for (const uint8_t *entry = src + 9; entry < end;) {
        if (end - entry < 8)
            return false;
        const uint32_t key = (uint32_t)read_be(entry, 4);
        const uint32_t length = (uint32_t)read_be(entry + 4, 4);
        entry += 8;
        if (length > (size_t)(end - entry))
            return false;
        switch (key) {
        case HOST_TIME:
            if (!claim_entry(&seen, HAS_HOST, length, 8))
                return false;
            parsed.host_time = read_signed(entry);
            break;
        case GHOST_TIME:
            if (!claim_entry(&seen, HAS_GHOST, length, 8))
                return false;
            parsed.ghost_time = read_signed(entry);
            break;
        case PREV_GHOST_TIME:
            if (!claim_entry(&seen, HAS_PREVIOUS, length, 8))
                return false;
            parsed.previous_ghost_time = read_signed(entry);
            parsed.has_previous_ghost_time = true;
            break;
        case SESSION:
            if (!claim_entry(&seen, HAS_SESSION, length, 8))
                return false;
            parsed.session = read_be(entry, 8);
            break;
        }
        entry += length;
    }

    const unsigned required = type == LINK_PONG ? HAS_HOST | HAS_GHOST | HAS_SESSION : HAS_HOST;
    if ((seen & required) != required || (type == LINK_PING && (seen & (HAS_GHOST | HAS_SESSION))))
        return false;
    *msg = parsed;
    return true;
}
