/* SPDX-License-Identifier: GPL-2.0-or-later
 * Offset measurement based on Ableton Link 4.1.1 Measurement and
 * MeasurementService, Copyright Ableton AG.
 */
#include "link_clock.h"

enum {
    MAX_RTT_US = 50000,
    MAX_CORRECTION_PPM = 200,
    MIN_DRIFT_INTERVAL_US = 10000000,
    MAX_DRIFT_INTERVAL_US = 120000000
};

static bool sane_time(int64_t time)
{
    /* Leave headroom for paired sums and doubled differences. */
    return time >= -INT64_MAX / 4 && time <= INT64_MAX / 4;
}

void link_clock_begin(link_clock_measurement *measurement)
{
    measurement->count = 0;
}

static void add_offset(link_clock_measurement *measurement, int64_t offset_x2)
{
    unsigned index = measurement->count;
    if (index == LINK_CLOCK_POINTS)
        return;
    while (index && measurement->offsets_x2[index - 1] > offset_x2) {
        measurement->offsets_x2[index] = measurement->offsets_x2[index - 1];
        --index;
    }
    measurement->offsets_x2[index] = offset_x2;
    ++measurement->count;
}

bool link_clock_add_pong(link_clock_measurement *measurement, const link_measurement *pong,
                         int64_t sent, int64_t received)
{
    if (pong->type != LINK_PONG || !sent || !pong->ghost_time || pong->host_time != sent ||
        !sane_time(sent) || !sane_time(received) || !sane_time(pong->ghost_time) ||
        received < sent || received - sent > MAX_RTT_US)
        return false;

    add_offset(measurement, 2 * pong->ghost_time - received - sent);
    if (pong->has_previous_ghost_time && pong->previous_ghost_time &&
        sane_time(pong->previous_ghost_time))
        add_offset(measurement, pong->ghost_time + pong->previous_ghost_time - 2 * sent);
    return true;
}

bool link_clock_finish(const link_clock_measurement *measurement, int64_t *offset)
{
    if (measurement->count != LINK_CLOCK_POINTS)
        return false;
    const int64_t doubled = measurement->offsets_x2[LINK_CLOCK_POINTS / 2];
    *offset = doubled / 2 + doubled % 2;
    return true;
}

void link_clock_init(link_clock *clock, int64_t host_time)
{
    *clock = (link_clock){host_time, 0, 0};
}

bool link_clock_reanchor(link_clock *clock, int64_t host_time, int64_t offset, bool estimate_drift)
{
    if (!sane_time(host_time) || !sane_time(offset) || !sane_time(clock->host_anchor) ||
        !sane_time(clock->ghost_anchor) || host_time < clock->host_anchor)
        return false;

    const int64_t elapsed = host_time - clock->host_anchor;
    const int64_t offset_change = offset - (clock->ghost_anchor - clock->host_anchor);
    int32_t rate = 0;
    if (estimate_drift && elapsed >= MIN_DRIFT_INTERVAL_US && elapsed <= MAX_DRIFT_INTERVAL_US) {
        const int64_t max_offset_change = elapsed * MAX_CORRECTION_PPM / 1000000;
        /* Ignore rate estimates outside the bound rather than extrapolating a
         * large session change or network-delay spike as oscillator drift. */
        if (offset_change >= -max_offset_change && offset_change <= max_offset_change)
            rate = (int32_t)(offset_change * 1000000 / elapsed);
    }
    *clock = (link_clock){host_time, host_time + offset, rate};
    return true;
}

bool link_clock_ghost_at(const link_clock *clock, int64_t host_time, int64_t *ghost_time)
{
    if (!sane_time(host_time) || !sane_time(clock->host_anchor) || !sane_time(clock->ghost_anchor) ||
        clock->rate_ppm < -MAX_CORRECTION_PPM || clock->rate_ppm > MAX_CORRECTION_PPM)
        return false;
    const int64_t elapsed = host_time - clock->host_anchor;
    const int64_t correction = (elapsed / 1000000) * clock->rate_ppm
                             + (elapsed % 1000000) * clock->rate_ppm / 1000000;
    *ghost_time = clock->ghost_anchor + elapsed + correction;
    return true;
}
