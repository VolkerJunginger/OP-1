/* SPDX-License-Identifier: GPL-2.0-or-later */
#ifndef ESC_LINK_WIRE_H
#define ESC_LINK_WIRE_H

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#define LINK_DISCOVERY_GROUP UINT32_C(0xe04c4e4b)
#define LINK_DISCOVERY_PORT 20808
#define LINK_SYNC_MAX_PACKET 512

typedef struct {
    int64_t us_per_beat;
    int64_t beat_origin;
    int64_t time_origin;
} link_timeline;

typedef struct {
    uint32_t ipv4; /* Numeric address, independent of machine byte order. */
    uint16_t port;
} link_endpoint;

typedef enum {
    LINK_ALIVE = 1,
    LINK_RESPONSE = 2,
    LINK_BYE = 3
} link_discovery_type;

typedef struct {
    link_discovery_type type;
    uint8_t ttl;
    uint64_t node;
    uint64_t session;
    link_timeline timeline;
    bool playing;
    int64_t transport_beat;
    int64_t transport_timestamp;
    link_endpoint measurement;
    link_endpoint audio;
} link_discovery;

typedef enum {
    LINK_PING = 1,
    LINK_PONG = 2
} link_measurement_type;

typedef struct {
    link_measurement_type type;
    uint64_t session;
    int64_t ghost_time;
    int64_t host_time;
    bool has_previous_ghost_time;
    int64_t previous_ghost_time;
} link_measurement;

/* Encoders return the number of bytes written, or zero. Decoders leave the
 * output unchanged on failure. All functions are independent of I/O. */
size_t link_discovery_encode(uint8_t *dst, size_t capacity, const link_discovery *msg);
bool link_discovery_decode(link_discovery *msg, const uint8_t *src, size_t size);
size_t link_measurement_encode(uint8_t *dst, size_t capacity, const link_measurement *msg);
bool link_measurement_decode(link_measurement *msg, const uint8_t *src, size_t size);

/* Exact integer math in units of microseconds and microbeats. Quantum must
 * be positive, in microbeats. Phase is returned in [0, quantum). */
bool link_timeline_beat_at(const link_timeline *timeline, int64_t ghost_time, int64_t *beat);
bool link_timeline_time_at(const link_timeline *timeline, int64_t beat, int64_t *ghost_time);
bool link_beat_phase(int64_t beat, int64_t quantum, int64_t *phase);

#endif
