/* SPDX-License-Identifier: GPL-2.0-or-later */
#include "link_wire.h"

static bool add(int64_t first, int64_t second, int64_t *result)
{
    if ((second > 0 && first > INT64_MAX - second) ||
        (second < 0 && first < INT64_MIN - second))
        return false;
    *result = first + second;
    return true;
}

static bool subtract(int64_t first, int64_t second, int64_t *result)
{
    if ((second < 0 && first > INT64_MAX + second) ||
        (second > 0 && first < INT64_MIN + second))
        return false;
    *result = first - second;
    return true;
}

/* Divide before scaling to avoid overflowing during long sessions. Both
 * factors are positive and bounded by 60,000,000, so the remainder product
 * is representable. Round halfway away from zero as in the reference. */
static bool scale(int64_t value, int64_t numerator, int64_t denominator, int64_t *result)
{
    const int64_t whole = value / denominator;
    if (whole > INT64_MAX / numerator || whole < INT64_MIN / numerator)
        return false;
    const int64_t remainder = (value % denominator) * numerator;
    const int64_t rounded = remainder >= 0 ? remainder + denominator / 2
                                           : remainder - denominator / 2;
    return add(whole * numerator, rounded / denominator, result);
}

bool link_timeline_beat_at(const link_timeline *timeline, int64_t ghost_time, int64_t *beat)
{
    const int64_t period = timeline->us_per_beat;
    int64_t delta;
    return period > 0 && period <= 60000000 &&
           subtract(ghost_time, timeline->time_origin, &delta) &&
           scale(delta, 1000000, period, &delta) &&
           add(timeline->beat_origin, delta, beat);
}

bool link_timeline_time_at(const link_timeline *timeline, int64_t beat, int64_t *ghost_time)
{
    const int64_t period = timeline->us_per_beat;
    int64_t delta;
    return period > 0 && period <= 60000000 &&
           subtract(beat, timeline->beat_origin, &delta) &&
           scale(delta, period, 1000000, &delta) &&
           add(timeline->time_origin, delta, ghost_time);
}

bool link_beat_phase(int64_t beat, int64_t quantum, int64_t *phase)
{
    if (quantum <= 0)
        return false;
    const int64_t remainder = beat % quantum;
    *phase = remainder < 0 ? remainder + quantum : remainder;
    return true;
}
