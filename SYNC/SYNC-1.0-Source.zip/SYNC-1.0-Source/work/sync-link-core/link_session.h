/* SPDX-License-Identifier: GPL-2.0-or-later */
#ifndef ESC_LINK_SESSION_H
#define ESC_LINK_SESSION_H

#include "link_clock.h"

#define LINK_MAX_PEERS 8
#define LINK_TX_CAPACITY 121

typedef enum {
    LINK_SOCKET_DISCOVERY,
    LINK_SOCKET_MEASUREMENT
} link_socket;

typedef struct {
    link_socket socket;
    link_endpoint target;
    size_t size;
    uint8_t data[LINK_TX_CAPACITY];
} link_transmit;

typedef struct {
    link_discovery state;
    int64_t expires;
    int64_t next_measurement;
} link_peer;

typedef struct {
    link_discovery state;
    link_peer peers[LINK_MAX_PEERS];
    link_clock clock;
    link_clock_measurement measurement;
    int64_t next_broadcast;
    int64_t ping_sent;
    int64_t previous_ghost_time;
    unsigned attempts;
    unsigned measuring; /* LINK_MAX_PEERS when idle. */
    bool transport_sync;
} link_session;

/* All calls belong to a single non-audio worker. The adapter binds distinct
 * unicast source sockets for discovery and measurement and joins the
 * discovery multicast group on the IPv4 interface. A nonempty tx is copied
 * or sent before the next state-machine call. Reinitialize on reconnect
 * with a fresh random node id and the new measurement address. */
bool link_session_open(link_session *session, uint64_t node, link_endpoint measurement,
                       int64_t now, int64_t us_per_beat);
void link_session_close(link_session *session, link_transmit *tx);
void link_session_poll(link_session *session, int64_t now, link_transmit *tx);
void link_session_receive(link_session *session, link_socket socket, link_endpoint from,
                          const uint8_t *packet, size_t size, int64_t now, link_transmit *tx);
bool link_session_set_tempo(link_session *session, int64_t now, int64_t us_per_beat);
bool link_session_set_playing(link_session *session, int64_t now, bool playing);
unsigned link_session_peer_count(const link_session *session);

#endif
