# SYNC Link Core

Transport-independent C implementation of the IPv4 sync path. All state is owned by a single non-audio worker. It emits at most one datagram per call without doing I/O. It uses bounded state for eight peers and one in-flight measurement. The eight-peer capacity is a port decision.

The reference tag `Link-4.1.1` resolves to commit `5ba907ae027a8c2ec8824463e37296dcefc5e9be`, verified using GitHub's compare endpoint.

- `link_wire.c` implements discovery and clock measurement encoders and decoders, including an optional IPv4 audio endpoint in discovery. Source references are `include/ableton/{discovery,link}/v1/Messages.hpp`, `discovery/Payload.hpp`, `link/NodeState.hpp`, `link/PeerState.hpp`, `link/EndpointV4.hpp` and `link/PayloadEntries.hpp`.
- `link_timeline.c` implements integer microsecond and microbeat conversion and quantum phase, based on `link/{Timeline,Tempo,Beats,Phase}.hpp`.
- `link_clock.c` uses the two offset observations from `link/Measurement.hpp` and the median principle from `link/MeasurementService.hpp`. This port caps RTT at 50 ms and uses 101 observations. Over successive measurements it estimates drift within ±200 ppm in integer arithmetic. The upstream service uses a unit slope for its measurement result. The drift filter is a port decision.
- `link_session.c` uses the discovery interval and TTL from `discovery/{UdpMessenger,PeerGateway}.hpp`, ghost age and ID comparison from `link/Sessions.hpp`, clock replies from `link/PingResponder.hpp`, and tempo/transport state from `link/{Controller,ClientSessionTimelines}.hpp`. For integration simplicity it measures one candidate at a time and preserves the same local node ID after the last remote peer disappears. The adapter provides a fresh random node ID on connection. Current transport state is stored whether or not the local instrument is opted into transport sync. The adapter must gate application to the instrument with the local setting.

The USB/lwIP adapter should join `224.76.78.75:20808` on the USB IPv4 network interface. Discovery goes out from a unicast source socket which also receives discovery replies. Measurement uses a separate bidirectional unicast socket, advertised in the discovery packet. Call the core only after the interface and socket bindings are ready, and close it before discarding the sockets when possible. Read the timeline through a synchronized handoff from the non-audio thread. The host test harness is a development dependency only.

## Verification

Run `sh tests/host.sh` for native Clang ASan/UBSan tests. Passed a three-node simulated-network test covering election, matching ghost times, tempo and transport propagation, explicit departure, new node identity on reconnect and expiry after disconnect. The clock test covers sample selection, RTT/echo rejection, outliers and a synthetic 100 ppm drift.

Run `sh tests/reference.sh /path/to/link-checkout` to compare 5 types of wire messages and over 18,000 timing conversions to the upstream C++ serializer and timelines. It expects the pinned tag and Asio submodule. The local run used the original upstream protocol/timeline headers fetched from the pinned reference and a host-only IPv4 address/endpoint shim in place of Asio. This verified wire bytes and timing but did not exercise Asio networking. Actual Live interoperability, CDC-ECM/lwIP runtime, firmware clock integration and Blackfin on-device performance remain untested.

Ableton Link source is Copyright Ableton AG and available under GPL-2.0-or-later or a commercial licence. The C port is marked GPL-2.0-or-later. The OPUS SDK is GPL-3.0 with additional terms documented in the chosen kit. A combined GPL distribution would need the applicable GPL terms, SDK notices and complete corresponding source.
