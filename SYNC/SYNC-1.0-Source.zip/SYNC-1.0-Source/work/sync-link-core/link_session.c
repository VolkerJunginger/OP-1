/* SPDX-License-Identifier: GPL-2.0-or-later
 * Link 4.1.1 session rules informed by Sessions, Controller, UdpMessenger,
 * Measurement and PingResponder. Reference Copyright Ableton AG.
 */
#include "link_session.h"

enum {
    SESSION_TIE_US = 500000,
    DISCOVERY_INTERVAL_US = 250000,
    MEASURE_INTERVAL_US = 30000000,
    PING_TIMEOUT_US = 50000,
    MEASURE_ATTEMPTS = 6,
    MIN_PERIOD_US = 60606, /* 999 BPM on wire */
    MAX_PERIOD_US = 3000000 /* 20 BPM */
};

static const link_endpoint multicast = {LINK_DISCOVERY_GROUP, LINK_DISCOVERY_PORT};

static bool valid_now(int64_t time)
{
    return time >= 0 && time <= INT64_MAX / 4;
}

static bool valid_period(int64_t period)
{
    return period >= MIN_PERIOD_US && period <= MAX_PERIOD_US;
}

static bool same_endpoint(link_endpoint a, link_endpoint b)
{
    return a.ipv4 == b.ipv4 && a.port == b.port;
}

static bool send_discovery(const link_session *session, link_discovery_type type,
                           link_endpoint to, link_transmit *tx)
{
    link_discovery state = session->state;
    state.type = type;
    tx->socket = LINK_SOCKET_DISCOVERY;
    tx->target = to;
    tx->size = link_discovery_encode(tx->data, sizeof(tx->data), &state);
    return tx->size != 0;
}

static void send_measurement(const link_measurement *msg, link_endpoint to, link_transmit *tx)
{
    tx->socket = LINK_SOCKET_MEASUREMENT;
    tx->target = to;
    tx->size = link_measurement_encode(tx->data, sizeof(tx->data), msg);
}

bool link_session_open(link_session *session, uint64_t node, link_endpoint measurement,
                       int64_t now, int64_t us_per_beat)
{
    if (!node || !measurement.ipv4 || !measurement.port || !valid_now(now) ||
        !valid_period(us_per_beat))
        return false;
    *session = (link_session){0};
    session->state = (link_discovery){
        .type = LINK_ALIVE, .ttl = 5, .node = node, .session = node,
        .timeline = {us_per_beat, 0, 0}, .measurement = measurement,
    };
    session->measuring = LINK_MAX_PEERS;
    link_clock_init(&session->clock, now);
    return true;
}

void link_session_close(link_session *session, link_transmit *tx)
{
    tx->size = 0;
    if (session->state.node) {
        send_discovery(session, LINK_BYE, multicast, tx);
        session->state.node = 0;
    }
}

unsigned link_session_peer_count(const link_session *session)
{
    unsigned count = 0;
    for (unsigned i = 0; i < LINK_MAX_PEERS; ++i)
        count += session->peers[i].expires != 0 &&
                 session->peers[i].state.session == session->state.session;
    return count;
}

static void mark_changed(link_session *session)
{
    session->next_broadcast = 0;
}

static void refresh_local_session(link_session *session, int64_t now)
{
    if (session->state.session == session->state.node || link_session_peer_count(session))
        return;
    int64_t ghost, beat;
    if (!link_clock_ghost_at(&session->clock, now, &ghost) ||
        !link_timeline_beat_at(&session->state.timeline, ghost, &beat))
        beat = 0;
    session->state.session = session->state.node;
    session->state.timeline.beat_origin = beat;
    session->state.timeline.time_origin = 0;
    session->state.transport_timestamp = 0;
    session->state.transport_beat = 0;
    session->state.playing = false;
    link_clock_init(&session->clock, now);
    mark_changed(session);
}

static void finish_measurement(link_session *session, int64_t now)
{
    link_peer *peer = &session->peers[session->measuring];
    peer->next_measurement = now + MEASURE_INTERVAL_US;
    session->measuring = LINK_MAX_PEERS;
    int64_t offset, current_ghost;
    if (!link_clock_finish(&session->measurement, &offset) ||
        !link_clock_ghost_at(&session->clock, now, &current_ghost))
        return;

    const int64_t ghost_difference = now + offset - current_ghost;
    const bool same_session = peer->state.session == session->state.session;
    const bool wins_tie = ghost_difference > -SESSION_TIE_US && ghost_difference < SESSION_TIE_US &&
                          peer->state.session < session->state.session;
    if ((same_session || ghost_difference > SESSION_TIE_US || wins_tie) &&
        link_clock_reanchor(&session->clock, now, offset, same_session)) {
        if (!same_session) {
            session->state.session = peer->state.session;
            session->state.timeline = peer->state.timeline;
            session->state.playing = peer->state.playing;
            session->state.transport_timestamp = peer->state.transport_timestamp;
            session->state.transport_beat = peer->state.transport_beat;
        }
        mark_changed(session);
    }
}

static void remove_peer(link_session *session, unsigned index)
{
    session->peers[index].expires = 0;
    if (session->measuring == index)
        session->measuring = LINK_MAX_PEERS;
}

static void send_ping(link_session *session, int64_t now, link_transmit *tx)
{
    const link_measurement ping = {
        .type = LINK_PING, .host_time = now,
        .has_previous_ghost_time = session->previous_ghost_time != 0,
        .previous_ghost_time = session->previous_ghost_time,
    };
    session->ping_sent = now;
    send_measurement(&ping, session->peers[session->measuring].state.measurement, tx);
}

void link_session_poll(link_session *session, int64_t now, link_transmit *tx)
{
    tx->size = 0;
    if (!session->state.node || !valid_now(now))
        return;

    for (unsigned i = 0; i < LINK_MAX_PEERS; ++i)
        if (session->peers[i].expires && session->peers[i].expires <= now)
            remove_peer(session, i);
    refresh_local_session(session, now);

    if (now >= session->next_broadcast) {
        send_discovery(session, LINK_ALIVE, multicast, tx);
        session->next_broadcast = now + DISCOVERY_INTERVAL_US;
        return;
    }
    if (session->measuring != LINK_MAX_PEERS) {
        if (now - session->ping_sent < PING_TIMEOUT_US)
            return;
        if (++session->attempts == MEASURE_ATTEMPTS) {
            session->peers[session->measuring].next_measurement = now + 1000000;
            session->measuring = LINK_MAX_PEERS;
            return;
        }
        session->previous_ghost_time = 0;
        send_ping(session, now, tx);
        return;
    }

    /* Measure candidates one at a time. Within each set of due peers prefer
     * the founding node, which supplies the least indirect clock. */
    unsigned chosen = LINK_MAX_PEERS;
    for (unsigned i = 0; i < LINK_MAX_PEERS; ++i) {
        const link_peer *peer = &session->peers[i];
        if (!peer->expires || peer->next_measurement > now)
            continue;
        if (peer->state.session == session->state.node)
            continue; /* Its ghost clock is our local clock. */
        if (chosen == LINK_MAX_PEERS || peer->state.node == peer->state.session)
            chosen = i;
    }
    if (chosen != LINK_MAX_PEERS) {
        session->measuring = chosen;
        session->attempts = 0;
        session->previous_ghost_time = 0;
        link_clock_begin(&session->measurement);
        send_ping(session, now, tx);
    }
}

static void receive_discovery(link_session *session, link_endpoint from,
                              const uint8_t *packet, size_t size, int64_t now, link_transmit *tx)
{
    link_discovery state;
    if (!link_discovery_decode(&state, packet, size) || !state.node ||
        state.node == session->state.node)
        return;

    unsigned found = LINK_MAX_PEERS, free_slot = LINK_MAX_PEERS;
    for (unsigned i = 0; i < LINK_MAX_PEERS; ++i) {
        const link_peer *peer = &session->peers[i];
        if (peer->expires && peer->state.node == state.node)
            found = i;
        if (!peer->expires && free_slot == LINK_MAX_PEERS)
            free_slot = i;
    }
    if (state.type == LINK_BYE) {
        if (found != LINK_MAX_PEERS && session->peers[found].state.measurement.ipv4 == from.ipv4)
            remove_peer(session, found);
        refresh_local_session(session, now);
        return;
    }
    if (!valid_period(state.timeline.us_per_beat) || !state.session ||
        state.measurement.ipv4 != from.ipv4)
        return;
    if (state.type == LINK_ALIVE)
        send_discovery(session, LINK_RESPONSE, from, tx);
    if (found == LINK_MAX_PEERS) {
        if (free_slot == LINK_MAX_PEERS)
            return;
        found = free_slot;
    }

    link_peer *peer = &session->peers[found];
    if (!peer->expires || peer->state.session != state.session ||
        !same_endpoint(peer->state.measurement, state.measurement)) {
        remove_peer(session, found);
        peer->next_measurement = now;
    }
    peer->state = state;
    peer->expires = now + ((int64_t)state.ttl + 1) * 1000000;

    if (state.session != session->state.session)
        return;
    if (state.timeline.beat_origin > session->state.timeline.beat_origin) {
        session->state.timeline = state.timeline;
        mark_changed(session);
    }
    if (state.transport_timestamp > session->state.transport_timestamp) {
        session->state.playing = state.playing;
        session->state.transport_timestamp = state.transport_timestamp;
        session->state.transport_beat = state.transport_beat;
        mark_changed(session);
    }
}

static void receive_measurement(link_session *session, link_endpoint from,
                                const uint8_t *packet, size_t size, int64_t now, link_transmit *tx)
{
    link_measurement message;
    if (!link_measurement_decode(&message, packet, size))
        return;

    if (message.type == LINK_PING) {
        if (link_clock_ghost_at(&session->clock, now, &message.ghost_time)) {
            message.type = LINK_PONG;
            message.session = session->state.session;
            send_measurement(&message, from, tx);
        }
        return;
    }
    if (session->measuring == LINK_MAX_PEERS)
        return;
    const link_discovery *peer = &session->peers[session->measuring].state;
    if (!same_endpoint(peer->measurement, from) || peer->session != message.session ||
        !link_clock_add_pong(&session->measurement, &message, session->ping_sent, now))
        return;
    if (session->measurement.count == LINK_CLOCK_POINTS) {
        finish_measurement(session, now);
        return;
    }
    session->previous_ghost_time = message.ghost_time;
    session->attempts = 0;
    send_ping(session, now, tx);
}

void link_session_receive(link_session *session, link_socket socket, link_endpoint from,
                          const uint8_t *packet, size_t size, int64_t now, link_transmit *tx)
{
    tx->size = 0;
    if (!session->state.node || !valid_now(now))
        return;
    if (socket == LINK_SOCKET_DISCOVERY)
        receive_discovery(session, from, packet, size, now, tx);
    else if (socket == LINK_SOCKET_MEASUREMENT)
        receive_measurement(session, from, packet, size, now, tx);
}

bool link_session_set_tempo(link_session *session, int64_t now, int64_t us_per_beat)
{
    if (!session->state.node || !valid_now(now) || !valid_period(us_per_beat))
        return false;
    if (session->state.timeline.us_per_beat == us_per_beat)
        return true;
    int64_t ghost, beat;
    if (!link_clock_ghost_at(&session->clock, now, &ghost) ||
        !link_timeline_beat_at(&session->state.timeline, ghost, &beat))
        return false;

    /* The reference compares origin beats, so edits must advance the
     * origin while preserving the old beat at the change time. */
    const int64_t previous = session->state.timeline.beat_origin;
    if (beat <= previous) {
        if (previous == INT64_MAX)
            return false;
        const link_timeline at_change = {us_per_beat, beat, ghost};
        beat = previous + 1;
        if (!link_timeline_time_at(&at_change, beat, &ghost))
            return false;
    }
    session->state.timeline = (link_timeline){us_per_beat, beat, ghost};
    mark_changed(session);
    return true;
}

bool link_session_set_playing(link_session *session, int64_t now, bool playing)
{
    if (!session->state.node || !session->transport_sync || !valid_now(now))
        return false;
    int64_t ghost, beat;
    if (!link_clock_ghost_at(&session->clock, now, &ghost) ||
        ghost <= session->state.transport_timestamp ||
        !link_timeline_beat_at(&session->state.timeline, ghost, &beat))
        return false;
    session->state.playing = playing;
    session->state.transport_timestamp = ghost;
    session->state.transport_beat = beat;
    mark_changed(session);
    return true;
}
