#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
reference=${1:?Path to Ableton Link 4.1.1 source checkout}
scratch=$(mktemp -d)
trap 'rm -rf "$scratch"' EXIT
flags="-g -fsanitize=address,undefined"
"${CC:-cc}" -std=c11 -Wall -Wextra -Wconversion -Werror $flags -c link_wire.c -o "$scratch/wire.o"
"${CC:-cc}" -std=c11 -Wall -Wextra -Wconversion -Werror $flags -c link_timeline.c -o "$scratch/timeline.o"
"${CXX:-c++}" -std=c++17 -DASIO_STANDALONE -DASIO_NO_TYPEID $flags -I. -I"$reference/include" \
    -I"$reference/modules/asio-standalone/asio/include" \
    tests/reference.cpp "$scratch/wire.o" "$scratch/timeline.o" -o "$scratch/reference"
"$scratch/reference"
