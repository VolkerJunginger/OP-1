/* SPDX-License-Identifier: GPL-2.0-or-later */
#include "link_clock.h"
#include <assert.h>

int main(void)
{
    const int64_t offset = -1000123;
    link_clock_measurement sample;
    link_clock_begin(&sample);
    int64_t result;
    assert(!link_clock_finish(&sample, &result));
    for (unsigned i = 0; i < LINK_CLOCK_POINTS; ++i) {
        const int64_t sent = 2000000 + 10000 * i;
        const bool outlier = i % 9 == 0;
        link_measurement packet = {
            .type = LINK_PONG, .host_time = sent,
            .ghost_time = sent + offset + (outlier ? 40 : 10),
        };
        assert(!link_clock_add_pong(&sample, &packet, sent + 1, sent + 20));
        assert(!link_clock_add_pong(&sample, &packet, sent, sent + 100000));
        assert(link_clock_add_pong(&sample, &packet, sent, sent + 20));
    }
    assert(link_clock_finish(&sample, &result) && result == offset);
    assert(sample.count == LINK_CLOCK_POINTS);

    link_clock clock;
    link_clock_init(&clock, 1000);
    assert(link_clock_ghost_at(&clock, 500, &result) && result == -500);
    assert(link_clock_reanchor(&clock, 2000000, offset, false));
    assert(link_clock_ghost_at(&clock, 3000000, &result) && result == 3000000 + offset);
    assert(link_clock_reanchor(&clock, 32000000, offset + 3000, true));
    assert(clock.rate_ppm == 100);
    assert(link_clock_ghost_at(&clock, 42000000, &result) && result == 42004000 + offset);
    assert(link_clock_reanchor(&clock, 62000000, offset + 200000, true));
    assert(clock.rate_ppm == 0);
    assert(!link_clock_reanchor(&clock, 31, offset, false));

    assert(link_beat_phase(-1200000, 4000000, &result) && result == 2800000);
    assert(!link_beat_phase(1, 0, &result));
}
