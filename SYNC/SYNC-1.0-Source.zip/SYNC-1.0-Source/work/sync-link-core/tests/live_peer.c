/* SPDX-License-Identifier: GPL-2.0-or-later */
#include <arpa/inet.h>
#include <errno.h>
#include <poll.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

#include "../link_session.h"

static volatile sig_atomic_t stopping;

static void stop(int sig)
{
    (void)sig;
    stopping = 1;
}

static int64_t now_us(void)
{
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (int64_t)ts.tv_sec * 1000000 + ts.tv_nsec / 1000;
}

static struct sockaddr_in address(uint32_t ip, uint16_t port)
{
    struct sockaddr_in addr = {0};
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = htonl(ip);
    addr.sin_port = htons(port);
    return addr;
}

static int open_udp(struct sockaddr_in addr, int multicast, struct in_addr iface)
{
    int fd = socket(AF_INET, SOCK_DGRAM, 0);
    if (fd < 0)
        return -1;
    int on = 1;
    if ((multicast && setsockopt(fd, SOL_SOCKET, SO_REUSEPORT, &on, sizeof on)) ||
        bind(fd, (struct sockaddr *)&addr, sizeof addr)) {
        perror("UDP bind");
        close(fd);
        return -1;
    }
    if (multicast) {
        struct ip_mreq group = { { htonl(LINK_DISCOVERY_GROUP) }, iface };
        if (setsockopt(fd, IPPROTO_IP, IP_ADD_MEMBERSHIP, &group, sizeof group)) {
            perror("multicast join");
            close(fd);
            return -1;
        }
    }
    return fd;
}

static void send_tx(const int sockets[3], const link_transmit *tx)
{
    if (!tx->size)
        return;
    struct sockaddr_in dst = address(tx->target.ipv4, tx->target.port);
    if (sendto(sockets[tx->socket == LINK_SOCKET_MEASUREMENT ? 2 : 1],
               tx->data, tx->size, 0, (struct sockaddr *)&dst, sizeof dst) < 0)
        perror("Link sendto");
}

int main(int argc, char **argv)
{
    struct in_addr iface;
    if (argc != 2 || inet_pton(AF_INET, argv[1], &iface) != 1 || iface.s_addr == INADDR_ANY) {
        fprintf(stderr, "Usage: %s <local IPv4 interface address>\n", argv[0]);
        return 2;
    }

    uint32_t ip = ntohl(iface.s_addr);
    int sockets[3] = {-1, -1, -1};
    int status = 1;
    sockets[0] = open_udp(address(0, LINK_DISCOVERY_PORT), 1, iface);
    if (sockets[0] < 0)
        goto done;
    sockets[1] = open_udp(address(ip, 0), 0, iface);
    sockets[2] = open_udp(address(ip, 0), 0, iface);
    if (sockets[1] < 0 || sockets[2] < 0)
        goto done;
    if (setsockopt(sockets[1], IPPROTO_IP, IP_MULTICAST_IF, &iface, sizeof iface)) {
        perror("multicast interface");
        goto done;
    }

    struct sockaddr_in local;
    socklen_t local_size = sizeof local;
    if (getsockname(sockets[2], (struct sockaddr *)&local, &local_size)) {
        perror("getsockname");
        goto done;
    }
    uint64_t id;
    arc4random_buf(&id, sizeof id);
    link_session session;
    link_endpoint measurement = {ip, ntohs(local.sin_port)};
    if (!link_session_open(&session, id ? id : 1, measurement, now_us(), 500000))
        goto done;

    signal(SIGINT, stop);
    signal(SIGTERM, stop);
    setvbuf(stdout, NULL, _IOLBF, 0);
    printf("C Link peer listening on %s\n", argv[1]);
    unsigned last_peers = UINT32_MAX;
    int64_t last_tempo = 0;
    uint64_t last_session = 0;
    struct pollfd fd[3];
    for (unsigned i = 0; i < 3; ++i)
        fd[i] = (struct pollfd){sockets[i], POLLIN, 0};

    link_transmit tx;
    while (!stopping) {
        link_session_poll(&session, now_us(), &tx);
        send_tx(sockets, &tx);
        int ready = poll(fd, 3, 10);
        if (ready < 0 && errno != EINTR) {
            perror("poll");
            goto done;
        }
        for (unsigned i = 0; ready > 0 && i < 3; ++i) {
            if (!(fd[i].revents & POLLIN))
                continue;
            uint8_t bytes[LINK_SYNC_MAX_PACKET + 1];
            struct sockaddr_in remote;
            socklen_t remote_size = sizeof remote;
            ssize_t size = recvfrom(sockets[i], bytes, sizeof bytes, 0,
                                    (struct sockaddr *)&remote, &remote_size);
            if (size <= 0 || size > LINK_SYNC_MAX_PACKET)
                continue;
            link_endpoint from = {ntohl(remote.sin_addr.s_addr), ntohs(remote.sin_port)};
            link_session_receive(&session, i == 2 ? LINK_SOCKET_MEASUREMENT : LINK_SOCKET_DISCOVERY,
                                 from, bytes, (size_t)size, now_us(), &tx);
            send_tx(sockets, &tx);
        }

        unsigned peers = link_session_peer_count(&session);
        int64_t tempo = session.state.timeline.us_per_beat;
        if (peers != last_peers || tempo != last_tempo || session.state.session != last_session) {
            printf("peers=%u tempo=%.3f BPM session=%016llx\n", peers,
                   60000000.0 / (double)tempo, (unsigned long long)session.state.session);
            last_peers = peers;
            last_tempo = tempo;
            last_session = session.state.session;
        }
    }
    link_session_close(&session, &tx);
    send_tx(sockets, &tx);
    status = 0;
done:
    for (unsigned i = 0; i < 3; ++i)
        if (sockets[i] >= 0)
            close(sockets[i]);
    return status;
}
