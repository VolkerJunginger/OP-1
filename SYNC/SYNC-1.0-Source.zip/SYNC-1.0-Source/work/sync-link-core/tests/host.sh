#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
scratch=$(mktemp -d)
trap 'rm -rf "$scratch"' EXIT
"${CC:-cc}" -std=c11 -pedantic -Wall -Wextra -Wconversion -Werror -g \
    -fsanitize=address,undefined -I. tests/test_clock.c link_clock.c link_timeline.c \
    -o "$scratch/test_clock"
"$scratch/test_clock"
"${CC:-cc}" -std=c11 -pedantic -Wall -Wextra -Wconversion -Werror -g \
    -fsanitize=address,undefined -I. tests/test_session.c link_session.c \
    link_clock.c link_timeline.c link_wire.c -o "$scratch/test_session"
"$scratch/test_session"
"${CC:-cc}" -std=c11 -pedantic -Wall -Wextra -Wconversion -Werror -g \
    -fsanitize=address,undefined -I. tests/test_wire.c link_wire.c -o "$scratch/test_wire"
"$scratch/test_wire"
