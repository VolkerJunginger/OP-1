/* SPDX-License-Identifier: GPL-2.0-or-later */
#include "link_wire.h"
#include <assert.h>
#include <string.h>

int main(void)
{
    uint8_t bytes[LINK_SYNC_MAX_PACKET] = {0};
    const link_discovery original = {
        .type = LINK_ALIVE, .ttl = 5, .node = 1, .session = 2,
        .timeline = {500000, -2000000, 3000000},
        .measurement = {0xa9fe0101, 49152},
    };
    const size_t size = link_discovery_encode(bytes, sizeof(bytes), &original);
    assert(size == 107);
    link_discovery output = {.type = LINK_RESPONSE, .node = 777};
    for (size_t i = 0; i < size; ++i) {
        assert(!link_discovery_decode(&output, bytes, i));
        assert(output.node == 777 && output.type == LINK_RESPONSE);
    }
    assert(link_discovery_decode(&output, bytes, size));
    assert(output.node == original.node && output.session == original.session);
    assert(output.timeline.beat_origin == original.timeline.beat_origin);

    /* Unknown TLV can be skipped, including an audio feature from a
     * newer peer. Duplicate known TLVs leave the output untouched. */
    const uint8_t unknown[] = {'a', 'b', 'c', 'd', 0, 0, 0, 1, 0x11};
    memcpy(bytes + size, unknown, sizeof(unknown));
    assert(link_discovery_decode(&output, bytes, size + sizeof(unknown)));
    memcpy(bytes + size, bytes + size - 14, 14);
    assert(!link_discovery_decode(&output, bytes, size + 14));
    assert(!link_discovery_decode(&output, bytes, LINK_SYNC_MAX_PACKET));

    const link_measurement measurement = {
        .type = LINK_PONG, .session = 2, .ghost_time = INT64_MIN, .host_time = INT64_MAX,
    };
    const size_t measurement_size = link_measurement_encode(bytes, sizeof(bytes), &measurement);
    assert(measurement_size == 57);
    link_measurement decoded = {.session = 777};
    for (size_t i = 0; i < measurement_size; ++i) {
        assert(!link_measurement_decode(&decoded, bytes, i));
        assert(decoded.session == 777);
    }
    assert(link_measurement_decode(&decoded, bytes, measurement_size));
    assert(decoded.ghost_time == INT64_MIN && decoded.host_time == INT64_MAX);
}
