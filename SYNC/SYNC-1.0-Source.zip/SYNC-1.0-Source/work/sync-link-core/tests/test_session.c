/* SPDX-License-Identifier: GPL-2.0-or-later */
#include "link_session.h"
#include <assert.h>

typedef struct {
    link_session state;
    link_endpoint discovery;
    link_endpoint measurement;
    int64_t shift;
} simulated_peer;

static bool same_endpoint(link_endpoint a, link_endpoint b)
{
    return a.ipv4 == b.ipv4 && a.port == b.port;
}

/* Three nodes, each with its own monotone clock epoch. Hand generated
 * frames to the matching socket with 20us one-way simulated latency. */
static void transmit(simulated_peer *peers, unsigned source, int64_t now, link_transmit *packet)
{
    for (unsigned steps = 0; packet->size && steps < 250; ++steps) {
        simulated_peer *sender = &peers[source];
        const link_socket socket = packet->socket;
        const bool multicast = packet->target.ipv4 == LINK_DISCOVERY_GROUP;
        const link_endpoint from = socket == LINK_SOCKET_MEASUREMENT
                                   ? sender->measurement : sender->discovery;
        link_transmit reply = {0};
        const unsigned origin = source;
        now += 20;

        for (unsigned i = 0; i < 3; ++i) {
            if (origin == i)
                continue;
            simulated_peer *target = &peers[i];
            const link_endpoint address = socket == LINK_SOCKET_MEASUREMENT
                                          ? target->measurement : target->discovery;
            if (!multicast && !same_endpoint(address, packet->target))
                continue;
            link_transmit response;
            link_session_receive(&target->state, socket, from, packet->data,
                                  packet->size, now + target->shift, &response);
            if (response.size) {
                if (multicast) {
                    assert(response.socket == LINK_SOCKET_DISCOVERY);
                    assert(same_endpoint(response.target, sender->discovery));
                    link_session_receive(&sender->state, response.socket, target->discovery,
                                          response.data, response.size,
                                          now + 20 + sender->shift, &reply);
                    assert(!reply.size);
                } else {
                    reply = response;
                    source = i;
                    break;
                }
            }
        }
        *packet = reply;
    }
    assert(!packet->size);
}

static void poll_all(simulated_peer *nodes, int64_t time)
{
    for (unsigned i = 0; i < 3; ++i) {
        link_transmit tx;
        const int64_t step_time = time + i * 10000;
        link_session_poll(&nodes[i].state, step_time + nodes[i].shift, &tx);
        transmit(nodes, i, step_time, &tx);
    }
}

int main(void)
{
    simulated_peer nodes[3] = {
        {.discovery = {0xa9fe0101, 50000}, .measurement = {0xa9fe0101, 50001}, .shift = 120000},
        {.discovery = {0xa9fe0102, 50000}, .measurement = {0xa9fe0102, 50001}, .shift = 300000},
        {.discovery = {0xa9fe0103, 50000}, .measurement = {0xa9fe0103, 50001}, .shift = 810000},
    };
    for (unsigned i = 0; i < 3; ++i)
        assert(link_session_open(&nodes[i].state, i + 1, nodes[i].measurement,
                                  100000 + nodes[i].shift, 500000));
    for (int64_t time = 100000; time < 900000; time += 35000)
        poll_all(nodes, time);

    for (unsigned i = 0; i < 3; ++i) {
        assert(nodes[i].state.state.session == 1);
        assert(link_session_peer_count(&nodes[i].state) == 2);
        int64_t ghost;
        assert(link_clock_ghost_at(&nodes[i].state.clock, 900000 + nodes[i].shift, &ghost));
        assert(ghost == 800000);
    }

    nodes[1].state.transport_sync = true;
    assert(link_session_set_playing(&nodes[1].state, 930000 + nodes[1].shift, true));
    assert(link_session_set_tempo(&nodes[1].state, 930000 + nodes[1].shift, 450000));
    poll_all(nodes, 950000);
    assert(nodes[0].state.state.playing);
    assert(nodes[2].state.state.timeline.us_per_beat == 450000);

    link_transmit tx;
    link_session_close(&nodes[0].state, &tx);
    transmit(nodes, 0, 990000, &tx);
    assert(link_session_peer_count(&nodes[1].state) == 1);
    link_session_close(&nodes[1].state, &tx);
    transmit(nodes, 1, 1000000, &tx);
    assert(link_session_peer_count(&nodes[2].state) == 0);
    assert(nodes[2].state.state.session == 3);
    assert(nodes[2].state.state.timeline.us_per_beat == 450000);

    assert(link_session_open(&nodes[0].state, 4, nodes[0].measurement,
                             1050000 + nodes[0].shift, 500000));
    for (int64_t time = 1050000; time < 2000000; time += 35000)
        poll_all(nodes, time);
    assert(nodes[0].state.state.session == 3);
    assert(nodes[2].state.state.session == 3);

    /* Simulate an unplug without a BYE. */
    nodes[2].state.state.node = 0;
    link_session_poll(&nodes[0].state, 9000000 + nodes[0].shift, &tx);
    assert(link_session_peer_count(&nodes[0].state) == 0);
    assert(nodes[0].state.state.session == 4);
}
