/* SPDX-License-Identifier: GPL-2.0-or-later */
#include <ableton/discovery/v1/Messages.hpp>
#include <ableton/link/EndpointV4.hpp>
#include <ableton/link/NodeState.hpp>
#include <ableton/link/PayloadEntries.hpp>
#include <ableton/link/v1/Messages.hpp>
#include <cassert>
#include <cstring>

extern "C" {
#include "link_wire.h"
}

using namespace std::chrono_literals;
namespace ad = ableton::discovery;
namespace al = ableton::link;

int main()
{
    constexpr uint64_t node_id = 0x0102030405060708;
    constexpr uint64_t session_id = 0xfedcba9876543210;
    const al::NodeId node{{1, 2, 3, 4, 5, 6, 7, 8}};
    const al::SessionId session{{0xfe, 0xdc, 0xba, 0x98, 0x76, 0x54, 0x32, 0x10}};
    const al::Timeline timeline{al::Tempo{491803us}, al::Beats{-4.0}, 1000000us};
    const al::StartStopState start{true, al::Beats{1.5}, 3000000us};
    const al::EndpointV4<0x6d657034> measure{{ad::IpAddressV4{0xa9fe0102}, 49152}};
    const al::EndpointV4<0x61657034> audio{{ad::IpAddressV4{0xa9fe0102}, 49153}};
    const auto payload = toPayload(al::NodeState{node, session, timeline, start})
                         + ad::makePayload(measure);
    const auto audio_payload = payload + ad::makePayload(audio);
    std::array<uint8_t, LINK_SYNC_MAX_PACKET> cpp{}, c{};
    link_discovery tx{LINK_ALIVE, 5, node_id, session_id,
                      {491803, -4000000, 1000000}, true, 1500000, 3000000,
                      {0xa9fe0102, 49152}, {}};
    auto check = [&](auto end) {
        const auto bytes = link_discovery_encode(c.data(), c.size(), &tx);
        assert(bytes == static_cast<size_t>(end - cpp.begin()));
        assert(std::memcmp(c.data(), cpp.data(), bytes) == 0);
        link_discovery rx{};
        assert(link_discovery_decode(&rx, cpp.data(), bytes));
        assert(rx.type == tx.type && rx.node == tx.node && rx.ttl == tx.ttl);
        if (tx.type != LINK_BYE) {
            assert(rx.session == tx.session && rx.playing == tx.playing);
            assert(rx.timeline.beat_origin == tx.timeline.beat_origin);
            assert(rx.measurement.ipv4 == tx.measurement.ipv4);
            assert(rx.audio.port == tx.audio.port);
        }
        for (size_t i = 0; i < bytes; ++i)
            assert(link_discovery_encode(c.data(), i, &tx) == 0);
    };
    check(ad::v1::aliveMessage(node, 5, payload, cpp.begin()));
    tx.type = LINK_RESPONSE;
    tx.audio = {0xa9fe0102, 49153};
    check(ad::v1::responseMessage(node, 5, audio_payload, cpp.begin()));
    tx.type = LINK_BYE;
    tx.ttl = 0;
    check(ad::v1::byeByeMessage(node, cpp.begin()));

    const auto ping = ad::makePayload(al::HostTime{123456us}, al::PrevGHostTime{-234us});
    const auto pong = ad::makePayload(al::SessionMembership{session}, al::GHostTime{3456us});
    link_measurement measurement{LINK_PING, session_id, 3456, 123456, true, -234};
    auto check_measurement = [&](auto end) {
        const auto bytes = link_measurement_encode(c.data(), c.size(), &measurement);
        assert(bytes == static_cast<size_t>(end - cpp.begin()));
        assert(std::memcmp(c.data(), cpp.data(), bytes) == 0);
        link_measurement rx{};
        assert(link_measurement_decode(&rx, cpp.data(), bytes));
        assert(rx.host_time == measurement.host_time);
        assert(rx.previous_ghost_time == measurement.previous_ghost_time);
        if (rx.type == LINK_PONG) {
            assert(rx.session == session_id);
            assert(rx.ghost_time == measurement.ghost_time);
        }
        for (size_t i = 0; i < bytes; ++i)
            assert(link_measurement_encode(c.data(), i, &measurement) == 0);
    };
    check_measurement(al::v1::pingMessage(ping, cpp.begin()));
    measurement.type = LINK_PONG;
    check_measurement(al::v1::pongMessage(pong + ping, cpp.begin()));

    for (int64_t t = -1000000; t <= 5000000; t += 1279) {
        int64_t result;
        assert(link_timeline_beat_at(&tx.timeline, t, &result));
        assert(result == timeline.toBeats(std::chrono::microseconds{t}).microBeats());
    }
    for (int64_t beat = -1000000; beat <= 5000000; beat += 443) {
        int64_t result;
        assert(link_timeline_time_at(&tx.timeline, beat, &result));
        const auto reference = timeline.fromBeats(al::Beats{static_cast<double>(beat) / 1e6});
        assert(result == reference.count());
    }
}
