/* SPDX-License-Identifier: GPL-2.0-or-later */
#ifndef ESC_LINK_CLOCK_H
#define ESC_LINK_CLOCK_H

#include "link_wire.h"

#define LINK_CLOCK_POINTS 101

typedef struct {
    /* Doubled offsets preserve half-microseconds until the final median. */
    int64_t offsets_x2[LINK_CLOCK_POINTS];
    unsigned count;
} link_clock_measurement;

typedef struct {
    int64_t host_anchor;
    int64_t ghost_anchor;
    int32_t rate_ppm;
} link_clock;

void link_clock_begin(link_clock_measurement *measurement);
bool link_clock_add_pong(link_clock_measurement *measurement, const link_measurement *pong,
                         int64_t sent, int64_t received);
bool link_clock_finish(const link_clock_measurement *measurement, int64_t *offset);
void link_clock_init(link_clock *clock, int64_t host_time);
bool link_clock_reanchor(link_clock *clock, int64_t host_time, int64_t offset, bool estimate_drift);
bool link_clock_ghost_at(const link_clock *clock, int64_t host_time, int64_t *ghost_time);

#endif
