/* SPDX-License-Identifier: GPL-3.0-or-later */
#include "ecm_port.h"

void ecm_port_reset(struct ecm_port *port)
{
    ecm_configured(&port->control, 0);
    ecm_rx_reset(&port->receive);
    port->packet_bytes = 0;
}

int ecm_port_configure(struct ecm_port *port, unsigned packet_bytes)
{
    ecm_port_reset(port);
    if (packet_bytes != ECM_BULK_PACKET && packet_bytes != ECM_BULK_HIGH_SPEED)
        return 0;
    port->packet_bytes = packet_bytes;
    ecm_configured(&port->control, 1);
    return 1;
}

int ecm_port_set_alt(struct ecm_port *port, unsigned alternate)
{
    unsigned previous = port->control.data_alt;
    if (!ecm_data_alt(&port->control, alternate))
        return 0;
    if (alternate != previous)
        ecm_rx_reset(&port->receive);
    return 1;
}

void ecm_port_receive(struct ecm_port *port, const uint8_t *data, unsigned length,
                      ecm_receive_fn receive, void *context)
{
    ecm_rx_packet_at_speed(&port->receive, &port->control, port->packet_bytes,
                           data, length, receive, context);
}
