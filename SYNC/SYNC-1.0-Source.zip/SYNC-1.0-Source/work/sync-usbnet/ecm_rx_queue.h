/* SPDX-License-Identifier: GPL-3.0-or-later */
#ifndef ESC_ECM_RX_QUEUE_H
#define ESC_ECM_RX_QUEUE_H
#include "ecm_bulk.h"

enum { ECM_RX_QUEUE_SIZE = 4 };
struct ecm_rx_entry {
    unsigned generation, length;
    uint8_t frame[ECM_MAX_FRAME];
};

/* Single producer in the USB thread, single consumer in the main pass.
 * Reset only the producer's partial frame. The consumer discards old entries
 * by generation, so reset never interrupts a frame already being consumed. */
struct ecm_rx_queue {
    struct ecm_rx receiver;
    struct ecm_rx_entry entries[ECM_RX_QUEUE_SIZE];
    volatile unsigned write, read, dropped;
    unsigned generation;
};

void ecm_rx_queue_packet(struct ecm_rx_queue *queue, const struct ecm_state *state,
                         unsigned packet_size, const uint8_t *data, unsigned length,
                         unsigned generation);
void ecm_rx_queue_drain(struct ecm_rx_queue *queue, unsigned generation,
                        ecm_receive_fn receive, void *context);
#endif
