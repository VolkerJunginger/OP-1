"""Check the known USB ABI against local OP-1 images without modifying them."""
import argparse
import binascii
import io
import lzma
import struct
import tarfile
from pathlib import Path

# Fingerprints identify the static findings. They do not establish that a
# new USB function can be installed, or that closing it releases all DMA.
SIGNATURES = {
    "native MIDI send entry": (0x019E0D18, "00e80000e305a66f"),
    "native tempo mode setter": (0x01A5EA68, "00e80000f505a66f38300de170184de18c012f92"),
    "native MIDI timestamp history reset": (0x019DE510, "09e1dc7c49e190fff86308931000"),
    "native parser clock state base": (0x019E31FE, "0ce10c604ce18b01"),
    "native parser clock divider": (0x019E3992, "60a0000c09180864c160010960b0"),
    "register USB function": (0x01A6D6F8, "09e1a41e49e18c0104cc004008930000"),
    "DCD high speed reset call": (0x01A6B2D4, "00e3500a"),
    "DCD full speed reset call": (0x01A6B2DC, "00e3560a"),
    "USB thread dispatch": (0x01A6B37C, "ffe318fc"),
    "USB thread semaphore wait": (0x01A6B368, "04cc09420891000009e1e8b649e1a0ff"),
    "USB event core": (0x01A6ABAC, "00e80d00e3053830"),
    "normal USB stop wrapper call": (0x01A6EE30, "ffe3eae8"),
    "normal USB stop": (0x01A6EE0C, "00e80400f5bc0de1"),
    "normal USB start": (0x01A6ED54, "00e80000c404a66f"),
    "device object constructor": (0x01A6CD28, "00e8000070053030"),
    "device graph destructor": (0x01A6E60C, "00e80300e305a66f"),
    "SETUP path A": (0x01A6AFAC, "00e36713"),
    "SETUP path B": (0x01A6B0D6, "00e3d212"),
    "start USB device": (0x01A6BF54, "00e80000e3052832"),
    "stop USB device": (0x01A6C004, "00e80000f405a66f"),
    "device object creation call": (0x01A6BFB0, "00e3bc06"),
    "device controller start dispatch": (0x01A6BFCC, "29e5110018916100"),
    "device descriptor graph destruction call": (0x01A6CD90, "00e33e0c"),
    "configuration lookup": (0x01A6C078, "0832010cf9670260"),
    "alternate setting lookup": (0x01A6C322, "08324d01010cf967"),
    "endpoint descriptor lookup": (0x01A6C402, "0832c404010cf967"),
    "OUT request at DCD endpoint enable": (0x01A6B4FA, "00e37b0b"),
    "OUT request creation": (0x01A6CBF0, "00e80000ec052132"),
    "OUT completion dispatcher": (0x01A6C19C, "00e80000fb052032"),
    "Disk resource teardown call": (0x01A70260, "09e198ac49e1a0ff6100"),
    "build USB descriptors": (0x01A6DB30, "00e81400e305866f"),
    "switch to Disk": (0x01A713FA, "ffe309edffe365ec"),
    "restore normal USB": (0x01A71464, "ffe3b6ecffe376ec"),
    "DCD enable": (0x01A6B6F0, "00e80000ec050ce150e04ce1"),
    "DCD disable": (0x01A6B75C, "00e80000fd05a66f07600de1"),
    "DCD bus detach clears SOFT_CONN": (0x01A6A6B4, "29e1043849e1c0ff04cc004049950000314c498a1000"),
    "DCD normal stop dispatch and destroy": (0x01A6C03A, "29ad753049ac6100073000e3a006"),
    "DCD normal start reconnects pull-up": (0x01A6A88C, "29e1043849e1c0ff4995314c498a4995294a498a4995314a498a"),
    "logical endpoint mapping": (0x01A6A6F4, "796048543849013039640107"),
    "DCD endpoint setup": (0x01A6B404, "00e80000e305313079602a30"),
    "EP0 448-byte buffer allocation": (0x01A6C7AA, "20e1c00169b2e8b128b200e3f011"),
    "request allocation": (0x01A6C7C8, "00e80000ec0528300d32a66f"),
    "request queue": (0x01A6C134, "00e80000f40528323830a66f"),
    "request release": (0x01A6C89C, "00e80400000c82ce00cef7b0"),
    "completion dispatcher": (0x01A6C8F0, "00e80000fb051832a66f430c"),
    "endpoint teardown path": (0x01A6BDCA, "0314f32d000004cc364c50a1"),
    "native MIDI TX request allocation A": (0x01A6A072, "00e3ab13"),
    "native MIDI TX request allocation B": (0x01A6A086, "00e3a113"),
    "native MIDI OUT event two": (0x01A69532, "80a1116088b0d32f"),
    "native MIDI USB callbacks": (0x018FF33C, "809ea601c893a601a694a6013c95a601"),
    "native USB MIDI endpoint templates": (0x018FF2BC, "04028000000000008302800000800000"),
    "native interface event": (0x01A69E80, "00e80000f3053830"),
    "native MIDI IN completion": (0x01A693C8, "00e80000fd05666f"),
    "native MIDI OUT completion": (0x01A694A6, "003200e800007005"),
    "queue cleanup": (0x01A6CA7C, "00e80000eb052832a66f01e1"),
}


def plain_blocks(path):
    package = path.read_bytes()
    if len(package) < 4 or struct.unpack_from("<I", package)[0] != binascii.crc32(package[4:]):
        raise ValueError("invalid OP-1 package checksum")

    with tarfile.open(
        fileobj=io.BytesIO(lzma.decompress(package[4:], format=lzma.FORMAT_ALONE))
    ) as archive:
        stream = archive.extractfile("OP1_vdk.ldr")
        if stream is None:
            raise ValueError("missing OP1_vdk.ldr")
        ldr = stream.read()

    cursor = 0
    while cursor < len(ldr):
        if cursor + 16 > len(ldr):
            raise ValueError("truncated LDR header")
        flags, address, size, _ = struct.unpack_from("<IIII", ldr, cursor)
        start = cursor + 16
        cursor = start + (0 if flags & 0x100 else size)
        if cursor > len(ldr):
            raise ValueError("truncated LDR block")
        if not flags & 0x1500:
            yield (address, ldr[start:cursor])


def check(path):
    blocks = list(plain_blocks(path))
    for label, (address, expected_hex) in SIGNATURES.items():
        expected = bytes.fromhex(expected_hex)
        actual = next(
            (data[address - start : address - start + len(expected)]
             for start, data in blocks
             if start <= address and address + len(expected) <= start + len(data)),
            None,
        )
        if actual != expected:
            raise ValueError(f"{label} differs at 0x{address:08x}")
    print(f"{path.name}: PASS ({len(SIGNATURES)} USB signatures)")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("images", nargs="+", type=Path)
    for image in parser.parse_args().images:
        try:
            check(image)
        except (OSError, ValueError, tarfile.TarError, lzma.LZMAError) as error:
            parser.exit(1, f"{image}: {error}\n")


if __name__ == "__main__":
    main()
