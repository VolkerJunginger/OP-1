/* SPDX-License-Identifier: GPL-3.0-or-later */
#ifndef ESC_R246_USB_REQUESTS_H
#define ESC_R246_USB_REQUESTS_H

#include "ecm_graph.h"

/* R246 allocates both objects, including its DMA buffer. Use only the
 * original allocator, queue and free functions from the same firmware. */
struct r246_usb_request {
    struct r246_usb_request *queue_previous;
    struct r246_usb_request *queue_next;
    void *endpoint;
    struct r246_usb_device *device;
    uint8_t setup[8];
    uint8_t *buffer;
    uint32_t capacity;
    uint32_t length;
    uint32_t transferred;
    uint32_t status;
    uint32_t reserved;
};

enum r246_usb_request_status {
    R246_IN_DONE = 1,
    R246_CANCELED = 2,
    R246_OUT_DONE = 5,
};

struct r246_usb_request_ops {
    struct r246_usb_request *(*allocate)(struct r246_usb_device *, unsigned endpoint,
                                          unsigned capacity);
    int (*submit)(struct r246_usb_request *);
    void (*release)(struct r246_usb_request *);
};

/* One reusable request per endpoint. USB thread only. A queued request
 * belongs to smxUSBD until the completion callback returns it. */
struct r246_usb_pipe {
    struct r246_usb_request *request;
    bool queued;
    bool transmitting;
};

bool r246_usb_pipe_open(struct r246_usb_pipe *pipe, const struct r246_usb_request_ops *ops,
                        struct r246_usb_device *device, unsigned endpoint, unsigned capacity);
bool r246_usb_pipe_submit(struct r246_usb_pipe *pipe, const struct r246_usb_request_ops *ops,
                          const uint8_t *source, unsigned length);
/* Call for the matching request only. Return this result unchanged from the
 * smxUSBD callback. On completed transfers the caller may read buffer/length
 * until the next submit. A canceled request is released by smxUSBD. */
int r246_usb_pipe_complete(struct r246_usb_pipe *pipe, struct r246_usb_request *request);
/* Call after the DCD has quiesced and smxUSBD has drained this endpoint. The
 * stack can free a pending OUT request without dispatching a callback. */
void r246_usb_pipe_retire(struct r246_usb_pipe *pipe, const struct r246_usb_request_ops *ops);

enum { R246_MIDI_TX_PACKETS = 256 };
struct r246_midi_tx {
    volatile unsigned read, write;
    uint32_t packets[R246_MIDI_TX_PACKETS];
};
bool r246_midi_tx_push(struct r246_midi_tx *queue, const unsigned *packets, unsigned count);
unsigned r246_midi_tx_peek(const struct r246_midi_tx *queue, unsigned limit,
                          const uint8_t **bytes);
void r246_midi_tx_sent(struct r246_midi_tx *queue, unsigned bytes);

/* Feed native MIDI in bounded chunks of complete USB-MIDI event packets. */
void r246_midi_chunks(const uint8_t *bytes, unsigned length,
                     void (*receive)(const uint8_t *, unsigned));
void r246_midi_route_clock(const uint8_t *bytes, unsigned length,
                          void (*receive)(const uint8_t *, unsigned),
                          void (*clock_event)(unsigned));

#if defined(__bfin__)
void r246_midi_receive(const uint8_t *bytes, unsigned length, void (*clock_event)(unsigned));
/* Only use after checking the running firmware ABI and owning the USB pipe. */
extern const struct r246_usb_request_ops r246_usb_request_ops;
#endif

#endif
