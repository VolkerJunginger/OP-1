/* SPDX-License-Identifier: GPL-3.0-or-later */
#include "tape_render.h"
#include <string.h>

static bool before(struct tape_clip a, struct tape_clip b)
{
    return a.track < b.track || (a.track == b.track && a.start < b.start);
}

void tape_clips_sort(struct tape_clips *list)
{
    for (unsigned gap = list->count / 2; gap; gap /= 2) {
        for (unsigned i = gap; i < list->count; ++i) {
            struct tape_clip clip = list->clips[i];
            unsigned j = i;
            while (j >= gap && before(clip, list->clips[j - gap])) {
                list->clips[j] = list->clips[j - gap];
                j -= gap;
            }
            list->clips[j] = clip;
        }
    }
    unsigned count = 0;
    for (unsigned i = 0; i < list->count; ++i) {
        struct tape_clip clip = list->clips[i];
        struct tape_clip *last = count ? &list->clips[count - 1] : NULL;
        if (last && clip.track == last->track && clip.start <= last->end) {
            if (clip.end > last->end)
                last->end = clip.end;
        } else {
            list->clips[count++] = clip;
        }
    }
    list->count = count;
}

struct coverage { int32_t start, end; bool has_clip; };

static bool covered(const struct tape_clips *list, int32_t track, int32_t sample,
                    struct coverage *range)
{
    if (sample < 0 || sample >= TAPE_SAMPLES)
        return false;
    if (sample >= range->start && sample < range->end)
        return range->has_clip;

    unsigned lo = 0, hi = list->count;
    while (lo < hi) {
        unsigned mid = lo + (hi - lo) / 2;
        const struct tape_clip *clip = &list->clips[mid];
        if (clip->track < track || (clip->track == track && clip->start <= sample))
            lo = mid + 1;
        else
            hi = mid;
    }

    const struct tape_clip *prev = lo ? &list->clips[lo - 1] : NULL;
    if (prev && prev->track == track && sample < prev->end) {
        *range = (struct coverage){ prev->start, prev->end, true };
    } else {
        const struct tape_clip *next = lo < list->count ? &list->clips[lo] : NULL;
        *range = (struct coverage){
            prev && prev->track == track ? prev->end : 0,
            next && next->track == track ? next->start : TAPE_SAMPLES,
            false
        };
    }
    return range->has_clip;
}

struct chunk_cache {
    int32_t index[2];
    const int16_t *pcm[2];
    unsigned replace;
};

static const int16_t *get_chunk(struct chunk_cache *cache, tape_chunk_fn load,
                                void *context, int32_t index)
{
    unsigned slot;
    if (cache->index[0] == index)
        slot = 0;
    else if (cache->index[1] == index)
        slot = 1;
    else {
        slot = cache->replace;
        cache->replace ^= 1;
        cache->index[slot] = index;
        cache->pcm[slot] = load(context, (unsigned)index);
    }
    return cache->pcm[slot];
}

static int32_t read_sample(const struct tape_clips *list, struct coverage *range,
                           struct chunk_cache *cache, tape_chunk_fn load, void *context,
                           int32_t track, int32_t sample)
{
    if (!covered(list, track, sample, range))
        return 0;
    const int16_t *pcm = get_chunk(cache, load, context, sample >> TAPE_CHUNK_SHIFT);
    return pcm ? pcm[track * TAPE_CHUNK + (sample & (TAPE_CHUNK - 1))] : 0;
}

static void render_forward(const struct tape_clips *list, struct chunk_cache *cache,
                           tape_chunk_fn load, void *context, int32_t track, int32_t sample,
                           int32_t loop_start, int32_t loop_end, int16_t *dst)
{
    struct coverage range = {0};
    unsigned remaining = TAPE_BLOCK;
    while (remaining) {
        int32_t end = sample + (int32_t)remaining;
        const int16_t *pcm = NULL;
        if (sample < 0) {
            if (end > 0) end = 0;
        } else if (sample < TAPE_SAMPLES) {
            bool has_clip = covered(list, track, sample, &range);
            if (end > range.end) end = range.end;
            if (has_clip) {
                int32_t chunk = sample >> TAPE_CHUNK_SHIFT;
                int32_t chunk_end = (chunk + 1) * TAPE_CHUNK;
                if (end > chunk_end) end = chunk_end;
                pcm = get_chunk(cache, load, context, chunk);
            }
        }
        if (loop_end && end > loop_end)
            end = loop_end;

        unsigned count = (unsigned)(end - sample);
        if (pcm)
            memcpy(dst, pcm + track * TAPE_CHUNK + (sample & (TAPE_CHUNK - 1)),
                   count * sizeof *dst);
        else
            memset(dst, 0, count * sizeof *dst);
        remaining -= count;
        dst += count;
        sample = end == loop_end && loop_end ? loop_start : end;
    }
}

void tape_render(const struct tape_clips *list, const struct tape_transport *transport,
                 tape_chunk_fn load, void *context, unsigned mask, int16_t *dst)
{
    int32_t step = transport->step_q6;
    int32_t head = transport->head_q6;
    bool playing = list && list->count && transport->playing && step &&
        step >= -8 * 64 && step <= 8 * 64 && head >= 0 && head <= TAPE_SAMPLES * 64;
    int32_t loop_start = 0, loop_end = 0, loop_length = 0;
    if (playing && transport->loop_start >= 0 && transport->loop_end <= TAPE_SAMPLES &&
        transport->loop_start < transport->loop_end) {
        loop_start = transport->loop_start * 64;
        loop_end = transport->loop_end * 64;
        if (head >= loop_start && head < loop_end)
            loop_length = loop_end - loop_start;
    }
    int32_t start = playing ? head - TAPE_BLOCK * step : 0;
    if (loop_length && (start < loop_start || start >= loop_end)) {
        int32_t offset = (start - loop_start) % loop_length;
        start = loop_start + (offset < 0 ? offset + loop_length : offset);
    }
    const bool fast_loop = loop_length && loop_length >= (step > 0 ? step : -step);
    struct chunk_cache cache = { .index = { -1, -1 } };
    for (unsigned track = 0; track < TAPE_TRACKS; ++track, dst += TAPE_BLOCK) {
        if (!(mask & (1u << track)))
            continue;
        if (!playing) {
            memset(dst, 0, TAPE_BLOCK * sizeof *dst);
            continue;
        }
        if (step == 64 && !(start & 63)) {
            render_forward(list, &cache, load, context, (int32_t)track, start >> 6,
                           loop_start >> 6, loop_length ? loop_end >> 6 : 0, dst);
            continue;
        }
        struct coverage range = {0}, next_range = {0};
        int32_t pos = start;
        for (unsigned i = 0; i < TAPE_BLOCK; ++i) {
            int32_t sample = pos >> 6;
            int32_t value = read_sample(list, &range, &cache, load, context, (int32_t)track, sample);
            int32_t fraction = pos & 63;
            if (fraction) {
                int32_t next = sample + 1;
                if (loop_length && next == transport->loop_end)
                    next = transport->loop_start;
                int32_t after = read_sample(list, &next_range, &cache, load, context,
                                            (int32_t)track, next);
                value += ((after - value) * fraction) >> 6;
            }
            dst[i] = (int16_t)value;
            pos += step;
            if (loop_length && (pos < loop_start || pos >= loop_end)) {
                if (fast_loop)
                    pos += pos < loop_start ? loop_length : -loop_length;
                else {
                    int32_t offset = (pos - loop_start) % loop_length;
                    pos = loop_start + (offset < 0 ? offset + loop_length : offset);
                }
            }
        }
    }
}
