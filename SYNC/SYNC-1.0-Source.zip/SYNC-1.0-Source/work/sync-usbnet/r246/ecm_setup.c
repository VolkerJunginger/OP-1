/* SPDX-License-Identifier: GPL-3.0-or-later */
#include "ecm_setup.h"

static int descriptor_reply(struct r246_usb_request *ep0, const uint8_t *bytes,
                            unsigned length)
{
    unsigned requested = ep0->setup[6] | ((unsigned)ep0->setup[7] << 8);
    if (length > requested)
        length = requested;
    if (!ep0->buffer || length > ep0->capacity)
        return -1;
    for (unsigned i = 0; i < length; ++i)
        ep0->buffer[i] = bytes[i];
    ep0->length = length;
    ep0->transferred = 0;
    ep0->reserved = 0;
    return 0;
}

int r246_ecm_setup(struct r246_ecm_graph *graph, struct ecm_state *control,
                   struct r246_usb_request *ep0,
                   int (*native_setup)(struct r246_usb_request *))
{
    if (!graph->attached_device || graph->attached_device != ep0->device ||
        ep0->device->function != &graph->function)
        return native_setup(ep0);

    const uint8_t *setup = ep0->setup;
    const uint8_t mac_index = graph->class_descriptors[2][3];
    if (setup[0] == 0x80 && setup[1] == 6) {
        if (setup[2] == mac_index && setup[3] == 3)
            return descriptor_reply(ep0, graph->mac_string, sizeof graph->mac_string);
        if (!setup[2] && !setup[4] && !setup[5] && (setup[3] == 2 || setup[3] == 7)) {
            unsigned length;
            const uint8_t *wire = r246_ecm_graph_wire(graph, setup[3] == 7, &length);
            if (wire)
                return descriptor_reply(ep0, wire, length);
        }
    }

    if ((setup[0] & 0x60u) == 0)
        return native_setup(ep0);
    if (!ecm_class_setup(control, setup))
        return -1;

    ep0->length = 0;
    ep0->transferred = 0;
    ep0->reserved = 0;
    return 0;
}
