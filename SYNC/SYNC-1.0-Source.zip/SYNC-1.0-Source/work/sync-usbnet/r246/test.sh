#!/bin/sh
set -eu
here=$(CDPATH='' cd -- "$(dirname -- "$0")" && pwd)
tmp=$(mktemp -d)
trap 'rm -rf "$tmp"' EXIT
"${CC:-clang}" -std=c11 -Wall -Wextra -Werror -O1 -g \
    -fsanitize=address,undefined -fno-sanitize-recover=all \
    "$here/ecm_graph.c" "$here/ecm_setup.c" "$here/../ecm.c" "$here/test_ecm_graph.c" -o "$tmp/test"
"$tmp/test"
"${CC:-clang}" -std=c11 -Wall -Wextra -Werror -O1 -g \
    -fsanitize=address,undefined -fno-sanitize-recover=all \
    "$here/usb_requests.c" "$here/test_usb_requests.c" -o "$tmp/requests"
"$tmp/requests"
"${CC:-clang}" -std=c11 -Wall -Wextra -Werror -O1 -g \
    -fsanitize=address,undefined -fno-sanitize-recover=all \
    "$here/tape_render.c" "$here/tests/test_tape_render.c" -o "$tmp/tape"
"$tmp/tape"
