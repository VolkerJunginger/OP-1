/* SPDX-License-Identifier: GPL-3.0-or-later */
#include "ecm_graph.h"
#include <stddef.h>
#include <string.h>

/* See R246 0x01a6c078, 0x01a6c322, 0x01a6c388, 0x01a6c402,
 * 0x01a6c9ec and 0x01a6d67a. Host tests use native pointers. */
#if UINTPTR_MAX == UINT32_MAX
_Static_assert(offsetof(struct r246_usb_device, function) == 4, "device function");
_Static_assert(sizeof(struct r246_usb_function) == 32, "function size");
_Static_assert(offsetof(struct r246_usb_function, callbacks) == 4, "callback table");
_Static_assert(offsetof(struct r246_usb_function, device_descriptor) == 16, "device descriptor");
_Static_assert(offsetof(struct r246_usb_function, configurations) == 20, "config table");
_Static_assert(offsetof(struct r246_usb_function, configuration_count) == 24, "config count");
_Static_assert(offsetof(struct r246_usb_function, qualifier) == 28, "device qualifier");
_Static_assert(sizeof(struct r246_usb_configuration) == 16, "config stride");
_Static_assert(offsetof(struct r246_usb_configuration, interfaces) == 8, "interface table");
_Static_assert(sizeof(struct r246_usb_interface) == 8, "interface stride");
_Static_assert(sizeof(struct r246_usb_alternate) == 20, "alternate stride");
_Static_assert(offsetof(struct r246_usb_alternate, class_descriptors) == 8, "class descriptors");
_Static_assert(offsetof(struct r246_usb_alternate, endpoints) == 16, "endpoint table");
_Static_assert(offsetof(struct r246_usb_callbacks, setup) == 12, "setup callback");
#endif

static bool endpoint_numbers_supported(struct ecm_endpoints ep)
{
    /* R246 maps OUT n to n and IN n to n + 7 in its 15-slot table. */
    return ep.bulk_out <= 7 && ep.bulk_in <= 0x87 && ep.interrupt_in <= 0x87;
}

static bool bulk_fifos_support(unsigned out, unsigned in, unsigned packet_bytes)
{
    /* BF524 endpoints 1–4 have 128-byte FIFOs. Only endpoints 5–7
     * can carry a 512-byte high-speed bulk packet. */
    return packet_bytes != ECM_BULK_HIGH_SPEED ||
           ((out & 7u) >= 5 && (in & 7u) >= 5);
}

static bool mac_is_unicast(const uint8_t mac[6])
{
    uint8_t combined = 0;
    for (unsigned i = 0; i < 6; ++i)
        combined |= mac[i];
    return combined != 0 && !(mac[0] & 1);
}

bool r246_ecm_graph_prepare(struct r246_ecm_graph *graph,
                            struct r246_usb_function *stock,
                            const struct r246_usb_callbacks *callbacks,
                            struct ecm_endpoints endpoints, unsigned packet_bytes,
                            uint8_t mac_index, const uint8_t mac[6])
{
    if (!graph || graph->attached_device || !stock || !callbacks ||
        !stock->device_descriptor || stock->device_descriptor[0] != 18 ||
        stock->device_descriptor[1] != 1 || !stock->qualifier ||
        stock->qualifier[0] != 10 || stock->qualifier[1] != 6 ||
        !mac || !mac_is_unicast(mac) ||
        !endpoint_numbers_supported(endpoints) ||
        !bulk_fifos_support(endpoints.bulk_out, endpoints.bulk_in, packet_bytes) ||
        !ecm_configuration_at_speed(graph->descriptors, endpoints, mac_index, packet_bytes, 0))
        return false;

    /* The stock serializer emits configuration, then interface entries
     * and their children. A standalone ECM device needs no IAD. */
    uint8_t *wire = graph->descriptors;
    uint8_t *iad = wire + wire[0];
    uint8_t *control = iad + iad[0];
    wire[2] = ECM_CONFIG_BYTES - iad[0];
    uint8_t *descriptor = control + control[0];
    for (unsigned i = 0; i < 3; ++i) {
        graph->class_descriptors[i] = descriptor;
        descriptor += descriptor[0];
    }
    graph->control_endpoints[0] = descriptor;
    uint8_t *data_idle = descriptor + descriptor[0];
    uint8_t *data_active = data_idle + data_idle[0];
    descriptor = data_active + data_active[0];
    graph->data_endpoints[0] = descriptor;
    graph->data_endpoints[1] = descriptor + descriptor[0];
    graph->control = (struct r246_usb_alternate){control, 3, graph->class_descriptors,
                                                 1, graph->control_endpoints};
    graph->data[0] = (struct r246_usb_alternate){.descriptor = data_idle};
    graph->data[1] = (struct r246_usb_alternate){.descriptor = data_active,
                                                 .endpoint_count = 2,
                                                 .endpoints = graph->data_endpoints};
    graph->interfaces[0] = (struct r246_usb_interface){1, &graph->control};
    graph->interfaces[1] = (struct r246_usb_interface){2, graph->data};
    graph->configuration = (struct r246_usb_configuration){2, wire, graph->interfaces, 0};

    for (unsigned i = 0; i < sizeof graph->device_descriptor; ++i)
        graph->device_descriptor[i] = stock->device_descriptor[i];
    for (unsigned i = 0; i < sizeof graph->qualifier; ++i)
        graph->qualifier[i] = stock->qualifier[i];
    graph->device_descriptor[4] = 2; /* Communications Device Class */
    graph->device_descriptor[5] = 0;
    graph->device_descriptor[6] = 0;
    graph->device_descriptor[17] = 1;
    graph->qualifier[4] = 2;
    graph->qualifier[5] = 0;
    graph->qualifier[6] = 0;
    graph->qualifier[8] = 1;

    const char hex[] = "0123456789ABCDEF";
    graph->mac_string[0] = R246_ECM_MAC_STRING_BYTES;
    graph->mac_string[1] = 3;
    for (unsigned i = 0; i < 6; ++i) {
        graph->mac_string[2 + i * 4] = (uint8_t)hex[mac[i] >> 4];
        graph->mac_string[3 + i * 4] = 0;
        graph->mac_string[4 + i * 4] = (uint8_t)hex[mac[i] & 15u];
        graph->mac_string[5 + i * 4] = 0;
    }
    graph->function = (struct r246_usb_function){.callbacks = callbacks,
                                                 .device_descriptor = graph->device_descriptor,
                                                 .configurations = &graph->configuration,
                                                 .configuration_count = 1,
                                                 .qualifier = graph->qualifier};
    graph->stock_function = stock;
    graph->composite_size = 0;
    graph->composite_bulk_bytes = packet_bytes;
    return true;
}

/* USB-MIDI associates host OUT with embedded IN jacks and vice versa. */
static unsigned midi_endpoint_slot(const struct r246_usb_alternate *alt, const uint8_t *desc)
{
    if (desc[0] < 5 || desc[2] != 1 || desc[0] != 4u + desc[3] || desc[3] > 16)
        return 2;
    unsigned subtype = 0;
    for (unsigned i = 0; i < desc[3]; ++i) {
        unsigned kind = 0;
        for (unsigned j = 0; j < alt->class_count; ++j) {
            const uint8_t *jack = alt->class_descriptors[j];
            if (jack[0] >= 6 && jack[1] == 0x24 && (jack[2] == 2 || jack[2] == 3) &&
                jack[3] == 1 && jack[4] == desc[4 + i]) {
                kind = jack[2];
                break;
            }
        }
        if (!kind || (subtype && subtype != kind))
            return 2;
        subtype = kind;
    }
    return subtype - 2;
}

static uint8_t *append(uint8_t *out, const uint8_t *desc)
{
    memcpy(out, desc, desc[0]);
    return out + desc[0];
}

const uint8_t *r246_ecm_graph_wire(struct r246_ecm_graph *graph, bool other,
                                  unsigned *size)
{
    if (!graph->composite_size)
        return NULL;
    const uint8_t ethernet_iad[] = {8, 11, 0, 2, 2, 6, 0, 0};
    const uint8_t midi_iad[] = {8, 11, 2, 2, 1, 1, 0, 0};
    uint8_t *wire = graph->composite_wire;
    uint8_t *out = append(wire, graph->descriptors);
    wire[1] = other ? 7 : 2;
    wire[2] = (uint8_t)graph->composite_size;
    wire[3] = (uint8_t)(graph->composite_size >> 8);
    out = append(out, ethernet_iad);
    bool high = (graph->composite_bulk_bytes == ECM_BULK_HIGH_SPEED) != other;
    unsigned bulk_bytes = high ? ECM_BULK_HIGH_SPEED : ECM_BULK_PACKET;

    for (unsigned i = 0; i < graph->configuration.interface_count; ++i) {
        if (i == 2)
            out = append(out, midi_iad);
        const struct r246_usb_interface *iface = &graph->interfaces[i];
        for (unsigned j = 0; j < iface->alternate_count; ++j) {
            const struct r246_usb_alternate *alt = &iface->alternates[j];
            out = append(out, alt->descriptor);
            uint8_t *midi_start = out;
            for (unsigned k = 0; k < alt->class_count; ++k)
                if (alt->class_descriptors[k][1] != 0x25)
                    out = append(out, alt->class_descriptors[k]);
            for (unsigned k = 0; k < alt->endpoint_count; ++k) {
                const uint8_t *ep = alt->endpoints[k];
                uint8_t *end = append(out, ep);
                if (i == 0) {
                    out[6] = high ? 8 : 16;
                } else if (i == 1 || i == R246_MIDI_INTERFACE) {
                    out[4] = (uint8_t)bulk_bytes;
                    out[5] = (uint8_t)(bulk_bytes >> 8);
                }
                if (i == R246_MIDI_INTERFACE) {
                    end = append(end, graph->midi_jacks[ep[2] == R246_MIDI_IN]);
                }
                out = end;
            }
            if (i == R246_MIDI_INTERFACE) {
                /* USB-MIDI 1.0 Appendix B's complete MS descriptor length. */
                unsigned length = (unsigned)(out - midi_start);
                midi_start[5] = (uint8_t)length;
                midi_start[6] = (uint8_t)(length >> 8);
            }
        }
    }
    *size = (unsigned)(out - wire);
    return wire;
}

bool r246_ecm_graph_add_midi(struct r246_ecm_graph *graph)
{
    if (!graph || graph->attached_device || !graph->stock_function ||
        graph->configuration.interface_count != 2 ||
        graph->control_endpoints[0][2] == R246_MIDI_IN ||
        graph->data_endpoints[0][2] == R246_MIDI_OUT ||
        graph->data_endpoints[1][2] == R246_MIDI_IN)
        return false;

    const struct r246_usb_function *stock = graph->stock_function;
    if (!stock->configuration_count || !stock->configurations || !stock->callbacks ||
        !stock->callbacks->event || !stock->callbacks->in_done || !stock->callbacks->out_done)
        return false;
    const struct r246_usb_configuration *config = &stock->configurations[0];
    if (config->interface_count != 4 || !config->interfaces)
        return false;
    const struct r246_usb_interface *midi = &config->interfaces[R246_MIDI_INTERFACE];
    if (midi->alternate_count != 1 || !midi->alternates)
        return false;
    const struct r246_usb_alternate *alt = midi->alternates;
    const uint8_t *interface = alt->descriptor;
    if (!interface || interface[0] != 9 || interface[1] != 4 ||
        interface[2] != R246_MIDI_INTERFACE || interface[3] != 0 || interface[4] != 2 ||
        interface[5] != 1 || interface[6] != 3 ||
        alt->endpoint_count != 2 || !alt->endpoints ||
        !alt->class_count || alt->class_count > 16 || !alt->class_descriptors)
        return false;

    unsigned bytes = graph->descriptors[2] + sizeof graph->midi_control_descriptor +
        sizeof graph->midi_control_header + interface[0];
    unsigned endpoint_mask = 0;
    for (unsigned i = 0; i < alt->endpoint_count; ++i) {
        const uint8_t *ep = alt->endpoints[i];
        if (!ep || (ep[0] != 7 && ep[0] != 9) || ep[1] != 5 ||
            ep[3] != 2 || !ep[4] || ep[4] > R246_NATIVE_MIDI_BUFFER || ep[5])
            return false;
        if (ep[2] == R246_NATIVE_MIDI_OUT) endpoint_mask |= 1u;
        if (ep[2] == R246_NATIVE_MIDI_IN) endpoint_mask |= 2u;
        bytes += ep[0];
    }
    if (endpoint_mask != 3)
        return false;
    for (unsigned i = 0; i < alt->class_count; ++i) {
        const uint8_t *desc = alt->class_descriptors[i];
        if (!desc || desc[0] < 3 || (desc[1] != 0x24 && desc[1] != 0x25))
            return false;
        bytes += desc[0];
    }
    const uint8_t *midi_header = alt->class_descriptors[0];
    if (midi_header[0] != 7 || midi_header[1] != 0x24 || midi_header[2] != 1 ||
        bytes + 16 > R246_COMPOSITE_MAX_BYTES)
        return false;
    const uint8_t *jacks[2] = {NULL, NULL};
    for (unsigned i = 0; i < alt->class_count; ++i) {
        const uint8_t *desc = alt->class_descriptors[i];
        if (desc[1] != 0x25)
            continue;
        unsigned slot = midi_endpoint_slot(alt, desc);
        if (slot >= 2 || jacks[slot])
            return false;
        jacks[slot] = desc;
    }
    if (!jacks[0] || !jacks[1])
        return false;
    graph->midi_jacks[0] = jacks[0];
    graph->midi_jacks[1] = jacks[1];
    graph->composite_size = bytes + 16;

    /* AudioControl class-specific header points only to native MIDIStreaming. */
    const uint8_t control[] = {9, 4, 2, 0, 0, 1, 1, 0, 0};
    const uint8_t header[] = {9, 0x24, 1, 0, 1, 9, 0, 1, R246_MIDI_INTERFACE};
    memcpy(graph->midi_control_descriptor, control, sizeof control);
    memcpy(graph->midi_control_header, header, sizeof header);
    graph->midi_control_classes[0] = graph->midi_control_header;
    graph->midi_control = (struct r246_usb_alternate){graph->midi_control_descriptor,
                                                     1, graph->midi_control_classes, 0, NULL};
    graph->interfaces[2] = (struct r246_usb_interface){1, &graph->midi_control};
    for (unsigned i = 0; i < 2; ++i) {
        const uint8_t *source = alt->endpoints[i];
        uint8_t *ep = graph->midi_endpoint_desc[i];
        memcpy(ep, source, source[0]);
        ep[2] = (source[2] & 0x80) ? R246_MIDI_IN : R246_MIDI_OUT;
        ep[4] = (uint8_t)graph->composite_bulk_bytes;
        ep[5] = (uint8_t)(graph->composite_bulk_bytes >> 8);
        graph->midi_endpoints[i] = ep;
    }
    graph->midi_streaming = *alt;
    graph->midi_streaming.endpoints = graph->midi_endpoints;
    graph->interfaces[R246_MIDI_INTERFACE] =
        (struct r246_usb_interface){1, &graph->midi_streaming};
    graph->configuration.interface_count = 4;
    graph->descriptors[2] = (uint8_t)bytes;
    graph->descriptors[3] = (uint8_t)(bytes >> 8);
    graph->descriptors[4] = 4;
    /* Interface Association Descriptor device-class triplet. */
    graph->device_descriptor[4] = graph->qualifier[4] = 0xef;
    graph->device_descriptor[5] = graph->qualifier[5] = 2;
    graph->device_descriptor[6] = graph->qualifier[6] = 1;
    return true;
}

bool r246_ecm_graph_attach(struct r246_ecm_graph *graph, struct r246_usb_device *device)
{
    if (!graph || !device || graph->attached_device || !graph->stock_function ||
        device->function != graph->stock_function)
        return false;
    device->function = &graph->function;
    graph->attached_device = device;
    return true;
}

bool r246_ecm_graph_detach(struct r246_ecm_graph *graph, struct r246_usb_device *device)
{
    if (!graph || !device || graph->attached_device != device ||
        device->function != &graph->function)
        return false;
    device->function = graph->stock_function;
    graph->attached_device = NULL;
    graph->stock_function = NULL;
    return true;
}

bool r246_ecm_graph_set_speed(struct r246_ecm_graph *graph, struct r246_usb_device *dev,
                             unsigned packet_bytes)
{
    if (!dev || graph->attached_device != dev || dev->function != &graph->function ||
        (packet_bytes != ECM_BULK_PACKET && packet_bytes != ECM_BULK_HIGH_SPEED) ||
        !bulk_fifos_support(graph->data_endpoints[0][2], graph->data_endpoints[1][2],
                            packet_bytes))
        return false;

    for (unsigned i = 0; i < 2; ++i) {
        uint8_t *endpoint = graph->data_endpoints[i];
        endpoint[4] = (uint8_t)packet_bytes;
        endpoint[5] = (uint8_t)(packet_bytes >> 8);
    }
    if (graph->composite_size)
        for (unsigned i = 0; i < 2; ++i) {
            uint8_t *ep = graph->midi_endpoints[i];
            ep[4] = (uint8_t)packet_bytes;
            ep[5] = (uint8_t)(packet_bytes >> 8);
        }
    graph->composite_bulk_bytes = packet_bytes;
    graph->control_endpoints[0][6] = packet_bytes == ECM_BULK_HIGH_SPEED ? 8 : 16;
    return true;
}
