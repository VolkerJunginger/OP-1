/* SPDX-License-Identifier: GPL-3.0-or-later */
#include "usb_requests.h"
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static unsigned allocations;
static unsigned frees;
static bool reject_submit;
static bool reject_allocate;

static struct r246_usb_request *allocate(struct r246_usb_device *device, unsigned endpoint,
                                          unsigned capacity)
{
    assert(endpoint == R246_ECM_BULK_IN || endpoint == R246_ECM_BULK_OUT ||
           endpoint == R246_ECM_INTERRUPT_IN);
    if (reject_allocate)
        return NULL;
    struct r246_usb_request *request = calloc(1, sizeof *request);
    assert(request);
    request->device = device;
    request->buffer = calloc(1, capacity);
    assert(request->buffer);
    request->capacity = capacity;
    ++allocations;
    return request;
}

static int submit(struct r246_usb_request *request)
{
    assert(request->transferred == 0);
    assert(request->length <= request->capacity);
    return reject_submit ? -1 : 0;
}

static void release(struct r246_usb_request *request)
{
    free(request->buffer);
    free(request);
    ++frees;
}

static const struct r246_usb_request_ops ops = {allocate, submit, release};

static unsigned midi_received;
static uint8_t midi_packet[512];

static void consume_midi(const uint8_t *bytes, unsigned length)
{
    assert(length <= R246_NATIVE_MIDI_BUFFER && length % 4 == 0);
    assert(bytes == midi_packet + midi_received);
    midi_received += length;
}

static void test_midi_chunks(void)
{
    r246_midi_chunks(midi_packet, 0, consume_midi);
    assert(midi_received == 0);
    r246_midi_chunks(midi_packet, sizeof midi_packet, consume_midi);
    assert(midi_received == sizeof midi_packet);
    midi_received = 0;
    r246_midi_chunks(midi_packet, 135, consume_midi);
    assert(midi_received == 132);
}

static unsigned routed_order;

static void consume_clock(unsigned status)
{
    assert((routed_order == 1 && status == 0xf8u) ||
           (routed_order == 3 && status == 0xfbu));
    ++routed_order;
}

static void consume_other_midi(const uint8_t *bytes, unsigned length)
{
    assert(length == 4);
    assert((routed_order == 0 && bytes[0] == 9 && bytes[1] == 0x90u) ||
           (routed_order == 2 && bytes[0] == 0x1fu && bytes[1] == 0xf8u));
    ++routed_order;
}

static void test_midi_clock_route(void)
{
    const uint8_t events[] = {
        9, 0x90, 60, 100,
        0x0f, 0xf8, 0, 0,
        0x1f, 0xf8, 0, 0,
        0x0f, 0xfb, 0, 0,
        0x0f, 0xfc, /* an incomplete event must never generate a stop */
    };
    r246_midi_route_clock(events, sizeof events, consume_other_midi, consume_clock);
    assert(routed_order == 4);
}

static void test_midi_tx(void)
{
    struct r246_midi_tx queue = {.read = UINT32_MAX - 1, .write = UINT32_MAX - 1};
    const uint8_t *bytes;
    const unsigned notes[] = {0x00643c09, 0x007f4009, 0x00003c08, 0x00004008};
    assert(r246_midi_tx_push(&queue, notes, 4));
    assert(r246_midi_tx_peek(&queue, 60, &bytes) == 8);
    assert(!memcmp(bytes, notes, 8));
    /* Submission failed: the same bytes remain queued. */
    assert(r246_midi_tx_peek(&queue, 60, &bytes) == 8);
    assert(!memcmp(bytes, notes, 8));
    r246_midi_tx_sent(&queue, 4);
    assert(r246_midi_tx_peek(&queue, 60, &bytes) == 4 && !memcmp(bytes, notes + 1, 4));
    r246_midi_tx_sent(&queue, 4);
    assert(r246_midi_tx_peek(&queue, 128, &bytes) == 8 && !memcmp(bytes, notes + 2, 8));
    assert(!r246_midi_tx_push(&queue, notes, R246_MIDI_TX_PACKETS));
    r246_midi_tx_sent(&queue, 8);
    assert(r246_midi_tx_peek(&queue, 128, &bytes) == 0);
}

int main(void)
{
    test_midi_chunks();
    test_midi_clock_route();
    test_midi_tx();
    struct r246_usb_device dev = {0};
    struct r246_usb_pipe tx = {0}, notify = {0};
    assert(!r246_usb_pipe_open(&tx, &ops, &dev, 0x88, 8));
    reject_allocate = true;
    assert(!r246_usb_pipe_open(&tx, &ops, &dev, R246_ECM_BULK_IN, ECM_MAX_FRAME));
    reject_allocate = false;
    assert(r246_usb_pipe_open(&tx, &ops, &dev, R246_ECM_BULK_IN, ECM_MAX_FRAME));
    assert(!r246_usb_pipe_open(&tx, &ops, &dev, R246_ECM_BULK_IN, 1));
    assert(!r246_usb_pipe_submit(&tx, &ops, NULL, ECM_MAX_FRAME + 1));
    assert(!r246_usb_pipe_submit(&tx, &ops, NULL, 1));
    const uint8_t payload[64] = {1, 2, 3, 4};
    reject_submit = true;
    assert(!r246_usb_pipe_submit(&tx, &ops, payload, sizeof payload));
    reject_submit = false;
    assert(r246_usb_pipe_submit(&tx, &ops, payload, sizeof payload));
    assert(!memcmp(tx.request->buffer, payload, sizeof payload));
    assert(!r246_usb_pipe_submit(&tx, &ops, NULL, 0));

    tx.request->status = R246_IN_DONE;
    tx.request->transferred = sizeof payload;
    assert(r246_usb_pipe_complete(&tx, tx.request) == 0);
    assert(r246_usb_pipe_submit(&tx, &ops, NULL, 0));
    assert(tx.request->length == 0 && tx.request->transferred == 0);
    tx.request->status = R246_IN_DONE;
    assert(r246_usb_pipe_complete(&tx, tx.request) == 0);

    assert(r246_usb_pipe_open(&notify, &ops, &dev, R246_ECM_INTERRUPT_IN,
                              ECM_SPEED_NOTIFICATION_BYTES));
    assert(r246_usb_pipe_submit(&notify, &ops, payload, ECM_NOTIFICATION_BYTES));
    assert(allocations == 2 && frees == 0);
    struct r246_usb_request *reset_pending_in = notify.request;
    reset_pending_in->status = R246_CANCELED;
    assert(r246_usb_pipe_complete(&notify, reset_pending_in) == -1);
    release(reset_pending_in); /* IN cancellation dispatch returns ownership to the stack */
    r246_usb_pipe_retire(&notify, &ops);
    r246_usb_pipe_retire(&tx, &ops);
    r246_usb_pipe_retire(&tx, &ops);
    assert(allocations == frees && frees == 2);
    puts("R246 USB request lifecycle: PASS (reuse, failed submission, ZLP, IN cleanup)");
    return 0;
}
