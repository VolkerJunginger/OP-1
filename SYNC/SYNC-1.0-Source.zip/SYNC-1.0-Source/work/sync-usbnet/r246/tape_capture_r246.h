/* SPDX-License-Identifier: GPL-3.0-or-later */
#ifndef SYNC_TAPE_CAPTURE_R246_H
#define SYNC_TAPE_CAPTURE_R246_H

#include "tape_render.h"

bool tape_capture_supported(void);
void tape_capture_refresh(bool active, int ran, unsigned cycles);
void tape_capture_pcm(unsigned mask, int16_t *dst);

#endif
