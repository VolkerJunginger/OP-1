/* SPDX-License-Identifier: GPL-3.0-or-later */
#ifndef SYNC_TAPE_RENDER_H
#define SYNC_TAPE_RENDER_H

#include <stdbool.h>
#include <stdint.h>

enum {
    TAPE_TRACKS = 4, TAPE_BLOCK = 64, TAPE_CLIP_CAPACITY = 512,
    TAPE_CHUNK_SHIFT = 15, TAPE_CHUNK = 1 << TAPE_CHUNK_SHIFT,
    TAPE_CHUNKS = 485, TAPE_SAMPLES = TAPE_CHUNKS * TAPE_CHUNK,
    TAPE_TRACK_MASK = (1u << TAPE_TRACKS) - 1
};

struct tape_clip { int32_t track, start, end; };
struct tape_clips {
    unsigned count;
    struct tape_clip clips[TAPE_CLIP_CAPACITY];
};
struct tape_transport {
    bool playing;
    int32_t head_q6, step_q6;
    int32_t loop_start, loop_end;
};
typedef const int16_t *(*tape_chunk_fn)(void *, unsigned);

void tape_clips_sort(struct tape_clips *);
void tape_render(const struct tape_clips *, const struct tape_transport *,
                 tape_chunk_fn, void *, unsigned mask, int16_t *dst);

#endif
