/* SPDX-License-Identifier: GPL-3.0-or-later */
#include "tape_capture_r246.h"
#include <stddef.h>

#define NATIVE_CLIPS ((const volatile struct tape_clip *)0x01aa8d70u)
#define CLIP_USED ((const volatile uint8_t *)0x01aaa570u)
#define CACHE_INDEX (*(const uint8_t *const *volatile *)0x01b4ef48u)
#define TAPE_MODE (*(const volatile int32_t *)0xff802960u)
#define TAPE_SPEED (*(const volatile int32_t *)0xff802968u)
#define TAPE_HEAD (*(const volatile int32_t *)0xff802974u)
#define TAPE_LOOP (*(const volatile uint8_t *)0xff8029c5u)
#define LOOP_START (*(const volatile int32_t *)0x01b4ef34u)
#define LOOP_END (*(const volatile int32_t *)0x01b4ef38u)

static struct tape_clips clips[2];
/* Main publishes these snapshots. The master callback reads them in the audio ISR. */
static volatile unsigned snapshot;
static unsigned last_refresh;

bool tape_capture_supported(void)
{
    static const struct { uintptr_t address; uint8_t bytes[8]; } checks[] = {
        {0x01a54cecu, {0x0d,0xe1,0x48,0xef,0x4d,0xe1,0xb4,0x01}},
        {0x01a54780u, {0x29,0xa1,0x04,0xcc,0x0d,0x02,0x20,0x91}},
        {0x01a54c40u, {0x09,0xe1,0x74,0x29,0x49,0xe1,0x80,0xff}},
        {0x0195bbc8u, {0x07,0xe1,0x70,0x8d,0x47,0xe1,0xaa,0x01}},
        {0x019643f8u, {0x09,0xe1,0x60,0x29,0x49,0xe1,0x80,0xff}},
        {0x019677e8u, {0x09,0xe1,0xc5,0x29,0x49,0xe1,0x80,0xff}},
    };
    for (unsigned i = 0; i < sizeof checks / sizeof *checks; ++i) {
        const volatile uint8_t *src = (const volatile uint8_t *)checks[i].address;
        for (unsigned j = 0; j < sizeof checks[i].bytes; ++j)
            if (src[j] != checks[i].bytes[j])
                return false;
    }
    return true;
}

void tape_capture_refresh(bool active, int ran, unsigned cycles)
{
    if (!active) {
        snapshot = 0;
        return;
    }
    if (snapshot && !ran && cycles - last_refresh < 50000000u)
        return;

    unsigned index = snapshot == 1 ? 1 : 0;
    struct tape_clips *list = &clips[index];
    list->count = 0;
    for (unsigned i = 0; i < TAPE_CLIP_CAPACITY; ++i) {
        if (!CLIP_USED[i])
            continue;
        struct tape_clip clip = NATIVE_CLIPS[i];
        if ((unsigned)clip.track < TAPE_TRACKS && clip.start >= 0 &&
            clip.start < clip.end && clip.end <= TAPE_SAMPLES)
            list->clips[list->count++] = clip;
    }
    tape_clips_sort(list);
    last_refresh = cycles;
    __asm__ volatile("ssync;" : : : "memory");
    snapshot = index + 1;
}

static bool in_sdram(const volatile void *p, unsigned bytes, unsigned align)
{
    uintptr_t addr = (uintptr_t)p;
    return addr >= 0x1000u && addr <= 0x04000000u - bytes && !(addr & (align - 1));
}

static const int16_t *cached_chunk(void *unused, unsigned chunk)
{
    (void)unused;
    const uint8_t *const volatile *index = CACHE_INDEX;
    if (in_sdram(index, TAPE_CHUNKS * sizeof *index, 4)) {
        const volatile uint8_t *entry = index[chunk];
        if (in_sdram(entry, 20, 4) && entry[0] == 1 &&
            *(const volatile int16_t *)(entry + 6) == (int16_t)chunk) {
            const int16_t *samples = *(const int16_t *const volatile *)(entry + 0x10);
            if (in_sdram(samples, TAPE_TRACKS * TAPE_CHUNK * sizeof *samples, 2))
                return samples;
        }
    }
    return NULL;
}

void tape_capture_pcm(unsigned mask, int16_t *dst)
{
    unsigned index = snapshot;
    __asm__ volatile("" : : : "memory");
    struct tape_transport transport = {
        .playing = TAPE_MODE == 2, .head_q6 = TAPE_HEAD, .step_q6 = TAPE_SPEED >> 21
    };
    if (TAPE_LOOP) {
        transport.loop_start = LOOP_START;
        transport.loop_end = LOOP_END;
    }
    tape_render(index ? &clips[index - 1] : NULL, &transport, cached_chunk, NULL, mask, dst);
}
