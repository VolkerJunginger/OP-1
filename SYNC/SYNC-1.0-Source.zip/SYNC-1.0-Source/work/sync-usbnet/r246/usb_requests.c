/* SPDX-License-Identifier: GPL-3.0-or-later */
#include "usb_requests.h"
#include <stddef.h>

#if UINTPTR_MAX == UINT32_MAX
_Static_assert(sizeof(struct r246_usb_request) == 48, "R246 USB request size");
_Static_assert(offsetof(struct r246_usb_request, endpoint) == 8, "endpoint");
_Static_assert(offsetof(struct r246_usb_request, device) == 12, "device");
_Static_assert(offsetof(struct r246_usb_request, setup) == 16, "EP0 setup");
_Static_assert(offsetof(struct r246_usb_request, buffer) == 24, "buffer");
_Static_assert(offsetof(struct r246_usb_request, capacity) == 28, "buffer capacity");
_Static_assert(offsetof(struct r246_usb_request, length) == 32, "requested bytes");
_Static_assert(offsetof(struct r246_usb_request, transferred) == 36, "transferred bytes");
_Static_assert(offsetof(struct r246_usb_request, status) == 40, "request status");
_Static_assert(offsetof(struct r246_usb_request, reserved) == 44, "EP0 setup state");
#endif

/* R246 completion values from 0x01a6c8f0 (IN), 0x01a6c19c (OUT) and
 * 0x01a6ca7c (endpoint cleanup). A successful OUT callback must return
 * zero to keep the request out of the firmware recycle queue. */
#if defined(__bfin__)
const struct r246_usb_request_ops r246_usb_request_ops = {
    .allocate = (struct r246_usb_request *(*)(struct r246_usb_device *, unsigned, unsigned))0x01a6c7c8u,
    .submit = (int (*)(struct r246_usb_request *))0x01a6c134u,
    .release = (void (*)(struct r246_usb_request *))0x01a6c89cu,
};
#endif

bool r246_usb_pipe_open(struct r246_usb_pipe *pipe, const struct r246_usb_request_ops *ops,
                        struct r246_usb_device *device, unsigned endpoint, unsigned capacity)
{
    if (pipe->request || !device || !capacity || capacity > ECM_MAX_FRAME ||
        !(endpoint & 7u) || (endpoint & ~0x87u))
        return false;
    pipe->transmitting = (endpoint & 0x80u) != 0;
    pipe->request = ops->allocate(device, endpoint, capacity);
    return pipe->request != NULL;
}

bool r246_usb_pipe_submit(struct r246_usb_pipe *pipe, const struct r246_usb_request_ops *ops,
                          const uint8_t *source, unsigned length)
{
    struct r246_usb_request *request = pipe->request;
    if (!request || pipe->queued || length > request->capacity)
        return false;
    if (pipe->transmitting ? (length != 0 && !source) : (!length || source))
        return false;

    if (source)
        for (unsigned i = 0; i < length; ++i)
            request->buffer[i] = source[i];
    request->length = length;
    request->transferred = 0;
    pipe->queued = true;
    if (ops->submit(request) == 0)
        return true;
    pipe->queued = false;
    return false;
}

int r246_usb_pipe_complete(struct r246_usb_pipe *pipe, struct r246_usb_request *request)
{
    if (!pipe->queued || request != pipe->request)
        return -1;

    pipe->queued = false;
    /* Cleanup callbacks are used for IN. smxUSBD frees the request when
     * the callback rejects it. OUT teardown can skip the callback. */
    if (request->status != R246_CANCELED)
        return 0;
    pipe->request = NULL;
    return -1;
}

void r246_usb_pipe_retire(struct r246_usb_pipe *pipe, const struct r246_usb_request_ops *ops)
{
    if (pipe->request && !pipe->queued)
        ops->release(pipe->request);
    pipe->request = NULL;
    pipe->queued = false;
}

bool r246_midi_tx_push(struct r246_midi_tx *queue, const unsigned *packets, unsigned count)
{
    unsigned write = queue->write;
    if (count > R246_MIDI_TX_PACKETS - (write - queue->read))
        return false;
    for (unsigned i = 0; i < count; ++i)
        queue->packets[(write + i) % R246_MIDI_TX_PACKETS] = packets[i];
#if defined(__bfin__)
    __asm__ volatile("ssync;" : : : "memory");
#endif
    queue->write = write + count;
    return true;
}

unsigned r246_midi_tx_peek(const struct r246_midi_tx *queue, unsigned limit,
                          const uint8_t **bytes)
{
    unsigned read = queue->read;
    unsigned count = queue->write - read;
#if defined(__bfin__)
    __asm__ volatile("" : : : "memory");
#endif
    unsigned index = read % R246_MIDI_TX_PACKETS;
    unsigned contiguous = R246_MIDI_TX_PACKETS - index;
    if (contiguous > limit / 4)
        contiguous = limit / 4;
    *bytes = (const uint8_t *)&queue->packets[index];
    return (count < contiguous ? count : contiguous) * 4;
}

void r246_midi_tx_sent(struct r246_midi_tx *queue, unsigned bytes)
{
    queue->read += bytes / 4;
}

void r246_midi_chunks(const uint8_t *bytes, unsigned length,
                     void (*receive)(const uint8_t *, unsigned))
{
    length &= ~3u;
    while (length) {
        unsigned count = length > R246_NATIVE_MIDI_BUFFER ? R246_NATIVE_MIDI_BUFFER : length;
        receive(bytes, count);
        bytes += count;
        length -= count;
    }
}

void r246_midi_route_clock(const uint8_t *bytes, unsigned length,
                          void (*receive)(const uint8_t *, unsigned),
                          void (*clock_event)(unsigned))
{
    length &= ~3u;
    unsigned begin = 0;
    for (unsigned offset = 0; offset < length; offset += 4) {
        unsigned status = bytes[offset + 1];
        /* Cable zero is the OP-1 port. The OPUS cable stays with R246. */
        if (bytes[offset] != 0x0fu ||
            (status != 0xf8u && status != 0xfau && status != 0xfbu && status != 0xfcu))
            continue;
        r246_midi_chunks(bytes + begin, offset - begin, receive);
        clock_event(status);
        begin = offset + 4;
    }
    r246_midi_chunks(bytes + begin, length - begin, receive);
}

#if defined(__bfin__)
typedef void (*midi_event_fn)(unsigned unused, unsigned event, unsigned length,
                              unsigned extra0, unsigned extra1);
struct r246_midi_context {
    uint32_t unused[2];
    const uint8_t *input;
    uint8_t padding[0xc0 - 12];
    midi_event_fn event;
};
_Static_assert(offsetof(struct r246_midi_context, event) == 0xc0, "native MIDI event");

static void native_midi_input(const uint8_t *bytes, unsigned length)
{
    /* The same event and arguments as R246 OUT completion at 0x01a69526.
     * The payload is consumed synchronously before the request is recycled. */
    struct r246_midi_context *context =
        *(struct r246_midi_context *volatile *)0x01dfe038u;
    const volatile unsigned *extra = (const volatile unsigned *)0x01dfe080u;
    if (context && context->event) {
        context->input = bytes;
        context->event(0, 2, length, extra[0], extra[1]);
    }
}

void r246_midi_receive(const uint8_t *bytes, unsigned length, void (*clock_event)(unsigned))
{
    if (clock_event)
        r246_midi_route_clock(bytes, length, native_midi_input, clock_event);
    else
        r246_midi_chunks(bytes, length, native_midi_input);
}
#endif
