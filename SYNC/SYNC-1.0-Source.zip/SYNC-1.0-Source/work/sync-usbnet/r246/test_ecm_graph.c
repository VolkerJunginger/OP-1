/* SPDX-License-Identifier: GPL-3.0-or-later */
#include "ecm_setup.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>

/* R246 emits the configuration followed by each interface's alternates
 * and their class and endpoint descriptors. */
static void append(uint8_t **dest, const uint8_t *descriptor)
{
    memcpy(*dest, descriptor, descriptor[0]);
    *dest += descriptor[0];
}

static size_t serialize(const struct r246_usb_configuration *config, uint8_t *bytes)
{
    uint8_t *dest = bytes;
    append(&dest, config->descriptor);
    for (uint32_t i = 0; i < config->interface_count; ++i) {
        const struct r246_usb_interface *iface = &config->interfaces[i];
        for (uint32_t j = 0; j < iface->alternate_count; ++j) {
            const struct r246_usb_alternate *alt = &iface->alternates[j];
            append(&dest, alt->descriptor);
            for (uint32_t k = 0; k < alt->class_count; ++k)
                append(&dest, alt->class_descriptors[k]);
            for (uint32_t k = 0; k < alt->endpoint_count; ++k)
                append(&dest, alt->endpoints[k]);
        }
    }
    return (size_t)(dest - bytes);
}

static int native_setup(struct r246_usb_request *request)
{
    assert(request);
    return -7;
}

static void test_setup(struct r246_ecm_graph *graph, struct r246_usb_device *dev,
                       const uint8_t expected_mac[26])
{
    uint8_t response[64];
    struct r246_usb_request ep0 = {.device = dev, .buffer = response,
                                  .capacity = sizeof response,
                                  .setup = {0x80, 6, 4, 3, 9, 4, 255, 0},
                                  .length = 64, .transferred = 3, .reserved = 1};
    struct ecm_state control = {0};
    assert(r246_ecm_setup(graph, &control, &ep0, native_setup) == 0);
    assert(ep0.length == 26 && ep0.transferred == 0 && ep0.reserved == 0);
    assert(!memcmp(response, expected_mac, ep0.length));
    ep0.setup[6] = 2;
    memset(response, 255, sizeof response);
    assert(r246_ecm_setup(graph, &control, &ep0, native_setup) == 0);
    assert(ep0.length == 2 && response[2] == 255);
    ep0.capacity = 1;
    assert(r246_ecm_setup(graph, &control, &ep0, native_setup) == -1);
    ep0.setup[2] = 3;
    assert(r246_ecm_setup(graph, &control, &ep0, native_setup) == -7);
    const uint8_t filter[] = {0x21, 0x43, 0x0e, 0, 0, 0, 0, 0};
    memcpy(ep0.setup, filter, sizeof filter);
    assert(r246_ecm_setup(graph, &control, &ep0, native_setup) == -1);
    ecm_configured(&control, 1);
    assert(r246_ecm_setup(graph, &control, &ep0, native_setup) == 0);
    assert(control.packet_filter == 0x0e && ep0.length == 0);
    ep0.setup[4] = 1;
    assert(r246_ecm_setup(graph, &control, &ep0, native_setup) == -1);
    assert(control.packet_filter == 0x0e);
    struct r246_usb_device disk = {0};
    ep0.device = &disk;
    assert(r246_ecm_setup(graph, &control, &ep0, native_setup) == -7);
}

static void test_graph(unsigned packet_bytes)
{
    uint8_t device_descriptor[18] = {18, 1, 0, 2, 0, 0, 0, 64, 0x34, 0x12,
                                      0x78, 0x56, 0, 1, 1, 2, 3, 1};
    uint8_t qualifier[10] = {10, 6, 0, 2, 0, 0, 0, 64, 1, 0};
    struct r246_usb_function stock = {.device_descriptor = device_descriptor,
                                      .qualifier = qualifier};
    struct r246_usb_function storage = {0};
    const struct r246_usb_callbacks callbacks = {0};
    struct r246_usb_device device = {.function = &stock};
    struct r246_usb_device disk = {.function = &storage};
    struct r246_ecm_graph graph = {0};
    const uint8_t mac[6] = {0x02, 0x42, 0xda, 0, 0x11, 0xb8};
    const uint8_t broadcast[6] = {255, 255, 255, 255, 255, 255};
    const uint8_t mac_wire[] = {26, 3, '0', 0, '2', 0, '4', 0, '2', 0, 'D', 0,
                                'A', 0, '0', 0, '0', 0, '1', 0, '1', 0, 'B', 0, '8', 0};
    const struct ecm_endpoints endpoints = {
        R246_ECM_INTERRUPT_IN, R246_ECM_BULK_OUT, R246_ECM_BULK_IN
    };
    const struct ecm_endpoints invalid = {0x88, R246_ECM_BULK_OUT, R246_ECM_BULK_IN};
    const struct ecm_endpoints small_out = {R246_ECM_INTERRUPT_IN, 2, R246_ECM_BULK_IN};
    const struct ecm_endpoints small_in = {R246_ECM_INTERRUPT_IN, R246_ECM_BULK_OUT, 0x82};
    assert(!r246_ecm_graph_prepare(&graph, &stock, &callbacks, small_out,
                                  ECM_BULK_HIGH_SPEED, 4, mac));
    assert(!r246_ecm_graph_prepare(&graph, &stock, &callbacks, small_in,
                                  ECM_BULK_HIGH_SPEED, 4, mac));
    assert(r246_ecm_graph_prepare(&graph, &stock, &callbacks, small_in,
                                 ECM_BULK_PACKET, 4, mac));
    assert(r246_ecm_graph_attach(&graph, &device));
    assert(!r246_ecm_graph_set_speed(&graph, &device, ECM_BULK_HIGH_SPEED));
    assert(graph.data_endpoints[1][4] == ECM_BULK_PACKET && graph.data_endpoints[1][5] == 0);
    assert(r246_ecm_graph_detach(&graph, &device));
    assert(!r246_ecm_graph_attach(&graph, &device));
    assert(!r246_ecm_graph_prepare(&graph, &stock, &callbacks, invalid, packet_bytes, 4, mac));
    assert(!r246_ecm_graph_prepare(&graph, &stock, &callbacks, endpoints, packet_bytes, 4, broadcast));
    assert(!r246_ecm_graph_prepare(&graph, &stock, &callbacks, endpoints, packet_bytes, 0, mac));
    assert(r246_ecm_graph_prepare(&graph, &stock, &callbacks, endpoints, packet_bytes, 4, mac));
    assert(!r246_ecm_graph_attach(&graph, &disk));
    assert(r246_ecm_graph_attach(&graph, &device));
    assert(!r246_ecm_graph_attach(&graph, &device));
    assert(!r246_ecm_graph_prepare(&graph, &stock, &callbacks, endpoints, packet_bytes, 4, mac));
    assert(device.function->callbacks == &callbacks);
    assert(device.function->configuration_count == 1);
    assert(device.function->device_descriptor[4] == 2 && device_descriptor[4] == 0);
    assert(device.function->qualifier[4] == 2 && qualifier[4] == 0);
    assert(!memcmp(graph.mac_string, mac_wire, sizeof mac_wire));
    test_setup(&graph, &device, mac_wire);

    uint8_t wire[ECM_CONFIG_BYTES];
    assert(serialize(device.function->configurations, wire) == 80);
    uint8_t expected[ECM_CONFIG_BYTES];
    assert(ecm_configuration_at_speed(expected, endpoints, 4, packet_bytes, 0));
    expected[2] -= 8;
    assert(!memcmp(wire, expected, 9));
    assert(!memcmp(wire + 9, expected + 17, sizeof expected - 17));
    const struct r246_usb_interface *iface = device.function->configurations->interfaces;
    assert(iface[0].alternates[0].endpoints[0][2] == endpoints.interrupt_in);
    assert(iface[1].alternates[0].endpoint_count == 0);
    const struct r246_usb_alternate *active = &iface[1].alternates[1];
    assert(active->endpoint_count == 2);
    assert(active->endpoints[0][2] == endpoints.bulk_out && active->endpoints[1][2] == endpoints.bulk_in);
    for (unsigned i = 0; i < active->endpoint_count; ++i) {
        const uint8_t *ep = active->endpoints[i];
        assert((unsigned)(ep[4] | (ep[5] << 8)) == packet_bytes);
    }

    /* Reset switches speeds in-place before smxUSBD reads endpoint sizes. */
    unsigned alternate_speed = packet_bytes == ECM_BULK_PACKET ?
                               ECM_BULK_HIGH_SPEED : ECM_BULK_PACKET;
    assert(!r246_ecm_graph_set_speed(&graph, &disk, alternate_speed));
    assert(!r246_ecm_graph_set_speed(&graph, &device, 128));
    assert(!memcmp(wire, device.function->configurations->descriptor, 9));
    assert(r246_ecm_graph_set_speed(&graph, &device, alternate_speed));
    assert(serialize(device.function->configurations, wire) == 80);
    assert(ecm_configuration_at_speed(expected, endpoints, 4, alternate_speed, 0));
    expected[2] -= 8;
    assert(!memcmp(wire, expected, 9));
    assert(!memcmp(wire + 9, expected + 17, sizeof expected - 17));
    assert(r246_ecm_graph_set_speed(&graph, &device, packet_bytes));
    assert((unsigned)(active->endpoints[0][4] | (active->endpoints[0][5] << 8)) == packet_bytes);

    assert(!r246_ecm_graph_detach(&graph, &disk));
    assert(r246_ecm_graph_detach(&graph, &device));
    assert(device.function == &stock && disk.function == &storage);
    assert(!r246_ecm_graph_set_speed(&graph, &device, alternate_speed));
    assert(!r246_ecm_graph_detach(&graph, &device));
    assert(r246_ecm_graph_prepare(&graph, &stock, &callbacks, endpoints, packet_bytes, 4, mac));
    assert(r246_ecm_graph_attach(&graph, &device));
    assert(r246_ecm_graph_detach(&graph, &device));
}

static int midi_event(struct r246_usb_device *device, int event)
{
    assert(device);
    return event;
}

static void test_composite(void)
{
    uint8_t device[18] = {18, 1};
    uint8_t qualifier[10] = {10, 6};
    uint8_t midi_descriptor[] = {9, 4, 3, 0, 2, 1, 3, 0, 0};
    uint8_t midi_header[] = {7, 0x24, 1, 0, 1, 7, 0};
    /* Same class endpoint and jack ordering as the R246 + OPUS template. */
    uint8_t jack_in1[] = {6, 0x24, 2, 1, 0x15, 0};
    uint8_t jack_in2[] = {6, 0x24, 2, 1, 0x19, 0};
    uint8_t jack_out1[] = {9, 0x24, 3, 1, 0x17, 1, 0x15, 1, 0};
    uint8_t jack_out2[] = {9, 0x24, 3, 1, 0x1b, 1, 0x19, 1, 0};
    uint8_t assoc_out[] = {6, 0x25, 1, 2, 0x15, 0x19};
    uint8_t assoc_in[] = {6, 0x25, 1, 2, 0x17, 0x1b};
    uint8_t *classes[] = {midi_header, jack_in1, jack_out1,
                          assoc_out, assoc_in, jack_in2, jack_out2};
    uint8_t midi_out[] = {9, 5, R246_NATIVE_MIDI_OUT, 2, 128, 0, 0, 0, 0};
    uint8_t midi_in[] = {9, 5, R246_NATIVE_MIDI_IN, 2, 128, 0, 0, 0, 0};
    uint8_t *endpoints[] = {midi_out, midi_in};
    struct r246_usb_alternate midi = {midi_descriptor, sizeof classes / sizeof classes[0], classes, 2, endpoints};
    struct r246_usb_interface native_interfaces[4] = {0};
    native_interfaces[3] = (struct r246_usb_interface){1, &midi};
    struct r246_usb_configuration native_config = {4, NULL, native_interfaces, 0};
    const struct r246_usb_callbacks native = {midi_event, native_setup, native_setup, NULL};
    struct r246_usb_function stock = {.device_descriptor = device, .qualifier = qualifier,
        .configuration_count = 1, .configurations = &native_config, .callbacks = &native};
    struct r246_usb_device dev = {.function = &stock};
    struct r246_ecm_graph graph = {0};
    const uint8_t mac[] = {2, 1, 2, 3, 4, 5};
    struct ecm_endpoints ep = {R246_MIDI_IN, R246_ECM_BULK_OUT, R246_ECM_BULK_IN};

    assert(r246_ecm_graph_prepare(&graph, &stock, &native, ep, ECM_BULK_HIGH_SPEED, 64, mac));
    assert(!r246_ecm_graph_add_midi(&graph)); /* Ethernet notification would collide. */
    ep.interrupt_in = R246_ECM_INTERRUPT_IN;
    assert(r246_ecm_graph_prepare(&graph, &stock, &native, ep, ECM_BULK_HIGH_SPEED, 64, mac));
    midi_out[4] = 0;
    assert(!r246_ecm_graph_add_midi(&graph));
    midi_out[4] = 128;
    assoc_in[5] = 0x15;
    assert(!r246_ecm_graph_add_midi(&graph)); /* Reject mixed jack directions. */
    assoc_in[5] = 0x1b;
    assert(r246_ecm_graph_add_midi(&graph));
    assert(!r246_ecm_graph_add_midi(&graph));
    assert(r246_ecm_graph_attach(&graph, &dev));

    uint8_t wire[R246_COMPOSITE_MAX_BYTES];
    struct r246_usb_request req = {.device = &dev, .buffer = wire,
        .capacity = sizeof wire, .setup = {0x80, 6, 0, 2, 0, 0, 0xff, 0xff}};
    struct ecm_state control = {0};
    assert(!r246_ecm_setup(&graph, &control, &req, native_setup));
    const size_t size = req.length;
    const size_t endpoints_start = size - sizeof midi_out - sizeof assoc_out -
                                  sizeof midi_in - sizeof assoc_in;
    assert(size == (size_t)(wire[2] | wire[3] << 8) && wire[4] == 4);
    assert(wire[1] == 2);
    assert(dev.function->device_descriptor[4] == 0xef && dev.function->qualifier[4] == 0xef);
    const uint8_t ethernet_iad[] = {8, 11, 0, 2, 2, 6, 0, 0};
    const uint8_t midi_iad[] = {8, 11, 2, 2, 1, 1, 0, 0};
    const uint8_t audio_control[] = {9, 4, 2, 0, 0, 1, 1, 0, 0, 9, 0x24, 1, 0, 1, 9, 0, 1, 3};
    assert(!memcmp(wire + 9, ethernet_iad, sizeof ethernet_iad));
    assert(!memcmp(wire + 88, midi_iad, sizeof midi_iad));
    assert(!memcmp(wire + 96, audio_control, sizeof audio_control));
    assert(!memcmp(wire + 114, midi_descriptor, sizeof midi_descriptor));
    assert(wire[128] == size - 123 && wire[129] == 0);
    const uint8_t expected_out[] = {9, 5, R246_MIDI_OUT, 2, 0, 2, 0, 0, 0};
    const uint8_t expected_in[] = {9, 5, R246_MIDI_IN, 2, 0, 2, 0, 0, 0};
    assert(!memcmp(wire + endpoints_start, expected_out, sizeof expected_out));
    assert(!memcmp(wire + endpoints_start + sizeof midi_out, assoc_out, sizeof assoc_out));
    assert(!memcmp(wire + size - sizeof midi_in - sizeof assoc_in, expected_in, sizeof expected_in));
    assert(!memcmp(wire + size - sizeof assoc_in, assoc_in, sizeof assoc_in));

    req.setup[6] = 9;
    req.setup[7] = 0;
    assert(!r246_ecm_setup(&graph, &control, &req, native_setup) && req.length == 9);
    assert(wire[2] == size);
    req.setup[6] = 255;
    req.capacity = 9;
    assert(r246_ecm_setup(&graph, &control, &req, native_setup) == -1);
    req.capacity = sizeof wire;
    req.setup[3] = 7;
    assert(!r246_ecm_setup(&graph, &control, &req, native_setup));
    assert(req.length == size && wire[1] == 7 && wire[78] == 64 && wire[79] == 0);
    assert(wire[endpoints_start + 4] == 64 && wire[endpoints_start + 5] == 0);
    assert(graph.midi_endpoints[0][4] == 0 && graph.midi_endpoints[0][5] == 2);
    assert(r246_ecm_graph_set_speed(&graph, &dev, ECM_BULK_PACKET));
    assert(graph.midi_endpoints[0][4] == 64 && graph.midi_endpoints[0][5] == 0);
    assert(!r246_ecm_setup(&graph, &control, &req, native_setup));
    assert(wire[78] == 0 && wire[79] == 2);
    assert(wire[endpoints_start + 4] == 0 && wire[endpoints_start + 5] == 2);
    assert(midi_out[2] == R246_NATIVE_MIDI_OUT && midi_out[4] == 128);
    assert(midi_in[2] == R246_NATIVE_MIDI_IN && midi_in[4] == 128);
    assert(r246_ecm_graph_detach(&graph, &dev) && dev.function == &stock);
    assert(stock.configurations->interfaces[3].alternates == &midi);
    puts("R246 ECM + native MIDI composite configuration: PASS");
}

int main(void)
{
    test_composite();
    test_graph(ECM_BULK_PACKET);
    test_graph(ECM_BULK_HIGH_SPEED);
    puts("R246 ECM configuration graph: PASS (FS/HS, EP0 MAC/filter, attach/restore)");
    return 0;
}
