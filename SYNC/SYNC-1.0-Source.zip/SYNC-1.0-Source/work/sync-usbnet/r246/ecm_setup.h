/* SPDX-License-Identifier: GPL-3.0-or-later */
#ifndef ESC_R246_ECM_SETUP_H
#define ESC_R246_ECM_SETUP_H

#include "usb_requests.h"

/* USB thread only. Publish the accepted filter to the NO_SYS worker after
 * handling SETUP. The native dispatcher handles all standard requests
 * other than our MAC string. Its return value is preserved. */
int r246_ecm_setup(struct r246_ecm_graph *graph, struct ecm_state *control,
                   struct r246_usb_request *ep0,
                   int (*native_setup)(struct r246_usb_request *));

#endif
