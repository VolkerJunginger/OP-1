/* SPDX-License-Identifier: GPL-3.0-or-later */
#include "../tape_render.h"
#include <assert.h>
#include <stddef.h>
#include <stdio.h>

static int16_t chunks[2][TAPE_TRACKS * TAPE_CHUNK];
static struct tape_clips clips;
static unsigned loads;
static bool missing;
static int16_t out[TAPE_TRACKS * TAPE_BLOCK];
#define SAMPLE(track, frame) out[(track) * TAPE_BLOCK + (frame)]

static const int16_t *load(void *context, unsigned chunk)
{
    (void)context;
    ++loads;
    return chunk < 2 && !(chunk == 1 && missing) ? chunks[chunk] : NULL;
}

static void render(struct tape_transport transport, unsigned mask)
{
    loads = 0;
    for (unsigned t = 0; t < TAPE_TRACKS; ++t)
        for (unsigned i = 0; i < TAPE_BLOCK; ++i)
            SAMPLE(t, i) = -123;
    tape_render(&clips, &transport, load, NULL, mask, out);
}

int main(void)
{
    for (unsigned c = 0; c < 2; ++c)
        for (unsigned t = 0; t < TAPE_TRACKS; ++t)
            for (unsigned i = 0; i < TAPE_CHUNK; ++i)
                chunks[c][t * TAPE_CHUNK + i] = (int16_t)(100 + 1000 * t + 200 * c + 2 * (i % 100));

    clips.count = 7;
    clips.clips[0] = (struct tape_clip){3, 0, TAPE_CHUNK + 100};
    clips.clips[1] = (struct tape_clip){0, 70, 99};
    clips.clips[2] = (struct tape_clip){2, 0, TAPE_CHUNK + 40};
    clips.clips[3] = (struct tape_clip){0, 0, 49};
    clips.clips[4] = (struct tape_clip){1, 0, TAPE_CHUNK + 40};
    clips.clips[5] = (struct tape_clip){1, TAPE_CHUNK + 20, TAPE_CHUNK + 88};
    clips.clips[6] = (struct tape_clip){1, TAPE_CHUNK + 88, TAPE_CHUNK + 100};
    tape_clips_sort(&clips);
    assert(clips.count == 5);

    render((struct tape_transport){true, 100 * 64, 64, 0, 0}, TAPE_TRACK_MASK);
    assert(loads == 1);
    for (unsigned i = 0; i < TAPE_BLOCK; ++i) {
        unsigned sample = i + 36;
        for (unsigned t = 0; t < TAPE_TRACKS; ++t)
            assert(SAMPLE(t, i) == (!t && ((sample >= 49 && sample < 70) || sample == 99)
                   ? 0 : (int16_t)(100 + 1000 * t + 2 * sample)));
    }

    render((struct tape_transport){true, (TAPE_CHUNK + 32) * 64, 64, 0, 0}, 1u << 3);
    assert(loads == 2);
    assert(SAMPLE(0, 0) == -123);
    assert(SAMPLE(3, 31) == chunks[0][4 * TAPE_CHUNK - 1]);
    assert(SAMPLE(3, 32) == chunks[1][3 * TAPE_CHUNK]);
    missing = true;
    render((struct tape_transport){true, (TAPE_CHUNK + 32) * 64, 64, 0, 0}, 1u << 3);
    assert(loads == 2 && SAMPLE(3, 31) != 0 && SAMPLE(3, 32) == 0);

    render((struct tape_transport){true, 25 * 64 + 32, 32, 0, 0}, 1u << 2);
    assert(SAMPLE(2, 0) == 0 && SAMPLE(2, 13) == 2100 && SAMPLE(2, 14) == 2101);
    render((struct tape_transport){true, 25 * 64, 64, 20, 40}, 1u << 1);
    assert(SAMPLE(1, 0) == 1142 && SAMPLE(1, 18) == 1178 && SAMPLE(1, 19) == 1140);
    render((struct tape_transport){true, 25 * 64, -64, 20, 40}, 1u << 1);
    assert(SAMPLE(1, 0) == 1158 && SAMPLE(1, 9) == 1140 && SAMPLE(1, 10) == 1178);
    render((struct tape_transport){false, 100 * 64, 64, 0, 0}, TAPE_TRACK_MASK);
    assert(!loads);
    for (unsigned t = 0; t < TAPE_TRACKS; ++t)
        for (unsigned i = 0; i < TAPE_BLOCK; ++i)
            assert(SAMPLE(t, i) == 0);

    puts("Tape renderer PASS");
}
