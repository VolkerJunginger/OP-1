#!/bin/sh
set -eu
src=${1:?Pass the src directory of lwIP STABLE-2_2_1_RELEASE}
output=${2:?Pass the absolute destination path for the .opmod}
here=$(CDPATH='' cd -- "$(dirname -- "$0")" && pwd)
root=$(CDPATH='' cd -- "$here/../../.." && pwd)
kit="$root/Opus Plugin Kit"
pulse="$kit/plugins/esc.sync"
net="$here/../lwip-port"
core="$root/work/sync-link-core"
audio="$root/work/sync-link-audio"
stage=$(mktemp -d)
trap 'rm -rf "$stage"' EXIT
cp -R "$src/include/lwip" "$src/include/netif" "$net/arch" "$stage"
cp "$net/bf524/include/"*.h "$net/bf524/runtime.c" "$net/lwipopts.h" "$stage"
cp "$pulse/"*.h "$pulse/"*.c "$pulse/"*.S "$stage"
cp "$here/"ecm_*.c "$here/"ecm_*.h "$here/"usb_requests.* "$here/sync_device.c" "$stage"
cp "$here/"tape_*.c "$here/"tape_*.h "$stage"
cp "$here/../"ecm*.c "$here/../"ecm*.h "$stage"
cp "$net/link_net.c" "$net/link_audio_net.c" "$net/ecm_link.c" "$stage"
cp "$core/link_"*.c "$core/link_"*.h "$stage"
cp "$audio/link_audio"*.c "$audio/link_audio"*.h "$stage"
cp "$root/work/sync-clock/link_midi_clock.c" "$stage"
sed 's|../sync-link-core/||' "$root/work/sync-clock/link_midi_clock.h" > "$stage/link_midi_clock.h"
sed 's|../ecm.h|ecm.h|' "$here/ecm_graph.h" > "$stage/ecm_graph.h"
sed 's|../ecm_port.h|ecm_port.h|' "$net/ecm_link.h" > "$stage/ecm_link.h"
sed 's|../../sync-link-core/||' "$net/link_net.h" > "$stage/link_net.h"
# The normal local PULSE development build remains independently buildable.
printf '#define SYNC_LINK_DEVICE 1\n' > "$stage/pulsesync.c"
cat "$pulse/pulsesync.c" >> "$stage/pulsesync.c"
printf '#define SYNC_LINK_DEVICE 1\n' > "$stage/sync_filter.S"
cat "$pulse/sync_filter.S" >> "$stage/sync_filter.S"
awk '
    /^version / { print "version   0.3.17"; next }
    /^core / { print "core      2.68"; next }
    /^adds / { print "adds      pulse, midi and ableton link"; next }
    /^setting   enabled / {
        print "setting clock off,midi,link,pulse midi \"clock\""
        next
    }
    /^setting   priority / { next }
    /^setting / { print $0 " if clock=pulse"; next }
    { print }
' "$pulse/manifest.txt" > "$stage/manifest.txt"
cat >> "$stage/manifest.txt" <<'MANIFEST'
setting link_transport off,on off "link start stop" if clock=link
setting link_audio off,on off "link audio"
setting link_audio_tx off,on,tape,both off "link audio master/tape" if link_audio=on
setting link_synth_tx off,on off "link audio synth tx" if link_audio=on
setting link_drum_tx off,on off "link audio drum tx" if link_audio=on
place call 0x01a6bfb0 sync_usb_construct expect 00e3bc06 as sync_usb_construct
place call 0x01a6cd90 sync_usb_destroy expect 00e33e0c as sync_usb_destroy
place call 0x01a6afac sync_usb_setup expect 00e36713 as sync_usb_setup_a
place call 0x01a6b0d6 sync_usb_setup expect 00e3d212 as sync_usb_setup_b
place call 0x01a6b37c sync_usb_dispatch expect ffe318fc as sync_usb_dispatch
place call 0x01a6b2d4 sync_usb_high_speed expect 00e3500a as sync_usb_high_speed
place call 0x01a6b2dc sync_usb_full_speed expect 00e3560a as sync_usb_full_speed
place jump 0x019e0d18 sync_midi_send expect 00e80000 as sync_midi_tx
place call 0x01a6a072 sync_midi_allocate expect 00e3ab13 as sync_midi_alloc_a
place call 0x01a6a086 sync_midi_allocate expect 00e3a113 as sync_midi_alloc_b
place call 0x01a6ee30 sync_usb_stop expect ffe3eae8 as sync_usb_stop
MANIFEST
for f in core/def.c core/init.c core/inet_chksum.c core/ip.c core/mem.c core/memp.c \
    core/netif.c core/pbuf.c core/stats.c core/sys.c core/timeouts.c core/udp.c \
    core/ipv4/acd.c core/ipv4/autoip.c core/ipv4/etharp.c core/ipv4/icmp.c \
    core/ipv4/igmp.c core/ipv4/ip4.c core/ipv4/ip4_addr.c netif/ethernet.c
do
    cp "$src/$f" "$stage"
done
cd "$kit"
python3 plugin_tool.py doctor
python3 plugin_tool.py build "$stage" --out "$output"
python3 plugin_tool.py show "$output"
