/* SPDX-License-Identifier: GPL-3.0-or-later */
#ifndef ESC_ECM_H
#define ESC_ECM_H

#include <stdint.h>

enum { ECM_CONFIG_BYTES = 88, ECM_MAX_FRAME = 1514 };

struct ecm_endpoints {
    uint8_t interrupt_in;
    uint8_t bulk_out;
    uint8_t bulk_in;
};

/* Standalone, bus-powered, full-speed configuration with one CDC-ECM
 * function. mac_string names the caller's 12-digit hex MAC descriptor. */
int ecm_configuration(uint8_t out[ECM_CONFIG_BYTES],
                      struct ecm_endpoints ep, uint8_t mac_string);

enum {
    ECM_NOTIFICATION_BYTES = 8,
    ECM_SPEED_NOTIFICATION_BYTES = 16,
    ECM_BULK_PACKET = 64,
    ECM_BULK_HIGH_SPEED = 512
};
int ecm_configuration_at_speed(uint8_t out[ECM_CONFIG_BYTES],
                               struct ecm_endpoints ep, uint8_t mac_string,
                               unsigned bulk_packet_bytes, int other_speed);
int ecm_frame_termination_at_speed(unsigned bytes, unsigned bulk_packet_bytes);

struct ecm_state {
    uint16_t packet_filter;
    uint8_t configured;
    uint8_t data_alt;
};

/* Call after the controller commits a configuration, or with 0 on reset. */
void ecm_configured(struct ecm_state *state, int configured);
int ecm_data_alt(struct ecm_state *state, unsigned alternate);
int ecm_link_up(const struct ecm_state *state);
/* Returns 1 for an accepted SET_ETHERNET_PACKET_FILTER, 0 otherwise.
 * The USB adapter is responsible for EP0 status and stalling. */
int ecm_class_setup(struct ecm_state *state, const uint8_t setup[8]);
void ecm_connection(const struct ecm_state *state,
                    uint8_t notification[ECM_NOTIFICATION_BYTES]);
void ecm_connection_speed(const struct ecm_state *state, unsigned bulk_packet_bytes,
                          uint8_t notification[ECM_SPEED_NOTIFICATION_BYTES]);
/* Returns -1 for a bad length, 1 for an extra zero-length USB packet,
 * otherwise 0. For the full-speed bulk IN endpoint. */
int ecm_frame_termination(unsigned bytes);

#endif
