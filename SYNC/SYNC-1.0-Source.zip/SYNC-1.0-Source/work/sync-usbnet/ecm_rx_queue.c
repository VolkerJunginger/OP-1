/* SPDX-License-Identifier: GPL-3.0-or-later */
#include "ecm_rx_queue.h"

static void fence(void)
{
#ifdef __bfin__
    __asm__ volatile("ssync;" : : : "memory");
#endif
}

static void enqueue(void *context, const uint8_t *frame, unsigned length)
{
    struct ecm_rx_queue *queue = context;
    unsigned write = queue->write;
    if (write - queue->read >= ECM_RX_QUEUE_SIZE) {
        ++queue->dropped;
        return;
    }
    struct ecm_rx_entry *entry = &queue->entries[write % ECM_RX_QUEUE_SIZE];
    entry->generation = queue->generation;
    entry->length = length;
    for (unsigned i = 0; i < length; ++i)
        entry->frame[i] = frame[i];
    fence();
    queue->write = write + 1;
}

void ecm_rx_queue_packet(struct ecm_rx_queue *queue, const struct ecm_state *state,
                         unsigned packet_size, const uint8_t *data, unsigned length,
                         unsigned generation)
{
    if (generation != queue->generation) {
        queue->generation = generation;
        ecm_rx_reset(&queue->receiver);
    }
    ecm_rx_packet_at_speed(&queue->receiver, state, packet_size, data, length, enqueue, queue);
}

void ecm_rx_queue_drain(struct ecm_rx_queue *queue, unsigned generation,
                        ecm_receive_fn receive, void *context)
{
    unsigned write = queue->write;
    fence();
    for (unsigned read = queue->read; read != write; ++read) {
        const struct ecm_rx_entry *entry = &queue->entries[read % ECM_RX_QUEUE_SIZE];
        if (receive && entry->generation == generation)
            receive(context, entry->frame, entry->length);
        fence();
        queue->read = read + 1;
    }
}
