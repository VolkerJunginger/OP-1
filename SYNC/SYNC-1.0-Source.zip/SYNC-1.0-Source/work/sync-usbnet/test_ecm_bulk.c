#include <assert.h>
#include "ecm_port.h"

static void frame_received(void *context, const uint8_t *frame, unsigned length)
{
    assert(frame[0] == 2);
    *(unsigned *)context = length;
}

int main(void)
{
    struct ecm_state state = {0};
    struct ecm_rx rx = {0};
    uint8_t packet[64] = {2};
    const uint8_t mac[6] = {2};
    unsigned got = 0;
    ecm_configured(&state, 1);
    assert(ecm_data_alt(&state, 1));

    ecm_rx_packet(&rx, &state, packet, 64, frame_received, &got);
    assert(!got);
    ecm_rx_packet(&rx, &state, 0, 0, frame_received, &got);
    assert(got == 64 && !rx.length);

    got = 0;
    for (unsigned i = 0; i < 24; ++i)
        ecm_rx_packet(&rx, &state, packet, 64, frame_received, &got);
    ecm_rx_packet(&rx, &state, packet, 20, frame_received, &got);
    assert(!got && !rx.length && !rx.discard);
    ecm_rx_packet(&rx, &state, packet, 20, frame_received, &got);
    assert(got == 20);

    uint8_t high_packet[512] = {2};
    got = 0;
    ecm_rx_packet_at_speed(&rx, &state, 512, high_packet, 512, frame_received, &got);
    assert(!got);
    ecm_rx_packet_at_speed(&rx, &state, 512, 0, 0, frame_received, &got);
    assert(got == 512);

    state.packet_filter = 4;
    assert(ecm_tx_allowed(&state, mac, packet, 64));
    packet[0] = 4;
    assert(!ecm_tx_allowed(&state, mac, packet, 64));
    packet[0] = 1;
    assert(!ecm_tx_allowed(&state, mac, packet, 64));
    state.packet_filter = 2;
    assert(ecm_tx_allowed(&state, mac, packet, 64));
    for (unsigned i = 0; i < 6; ++i) packet[i] = 255;
    assert(!ecm_tx_allowed(&state, mac, packet, 64));
    state.packet_filter = 8;
    assert(ecm_tx_allowed(&state, mac, packet, 64));
    assert(!ecm_tx_allowed(&state, mac, packet, 13));
    ecm_configured(&state, 0);
    assert(!ecm_tx_allowed(&state, mac, packet, 64));

    struct ecm_port port;
    assert(ecm_port_configure(&port, 512));
    assert(ecm_port_set_alt(&port, 1));
    got = 0;
    ecm_port_receive(&port, high_packet, 512, frame_received, &got);
    assert(!got && port.receive.length == 512);
    assert(ecm_port_set_alt(&port, 0));
    assert(ecm_port_set_alt(&port, 1));
    ecm_port_receive(&port, 0, 0, frame_received, &got);
    assert(!got);

    ecm_port_receive(&port, high_packet, 512, frame_received, &got);
    ecm_port_reset(&port);
    assert(!ecm_port_set_alt(&port, 1));
    assert(ecm_port_configure(&port, 64));
    assert(ecm_port_set_alt(&port, 1));
    ecm_port_receive(&port, high_packet, 20, frame_received, &got);
    assert(got == 20);
}
