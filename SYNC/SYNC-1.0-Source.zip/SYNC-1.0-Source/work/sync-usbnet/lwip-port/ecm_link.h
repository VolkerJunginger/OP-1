/* SPDX-License-Identifier: GPL-3.0-or-later */
#ifndef ESC_ECM_LINK_H
#define ESC_ECM_LINK_H

#include "link_net.h"
#include "lwip/autoip.h"
#include "../ecm_port.h"

/* USB adapter must copy the buffer before returning. The callback is called
 * from the NO_SYS worker, never from the DCD interrupt or audio callback. */
typedef err_t (*ecm_link_send_fn)(void *context, const uint8_t *frame,
                                 unsigned length, bool zlp);

struct ecm_link {
    struct ecm_port port;
    struct netif iface;
    struct autoip autoip;
    struct link_net net;
    ip4_addr_t session_address;
    uint8_t tx_frame[ECM_MAX_FRAME];
    uint8_t host_mac[6];
    ecm_link_send_fn send;
    void *context;
    uint64_t next_node;
    int64_t beat_period;
    bool registered;
    bool autoip_running;
};

/* Zero-initialize the object once. Call all functions in one NO_SYS
 * worker after lwip_init(). The device and host MACs must be distinct.
 * The DCD owns endpoint activation and must discard completions from
 * cancelled transfers before passing packets to a new configuration. */
err_t ecm_link_open(struct ecm_link *link, unsigned packet_bytes,
                    const uint8_t device_mac[6], const uint8_t host_mac[6],
                    uint64_t node, int64_t beat_period, ecm_link_send_fn send,
                    void *context);
err_t ecm_link_alt(struct ecm_link *link, unsigned alternate);
void ecm_link_poll(struct ecm_link *link, int64_t now_us);
void ecm_link_receive(struct ecm_link *link, const uint8_t *packet, unsigned bytes);
void ecm_link_close(struct ecm_link *link);

#endif
