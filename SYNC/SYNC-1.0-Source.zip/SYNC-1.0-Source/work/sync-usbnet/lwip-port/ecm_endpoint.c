/* SPDX-License-Identifier: GPL-3.0-or-later */
#include "ecm_endpoint.h"

static err_t submit_in(void *handle, const uint8_t *frame, unsigned bytes, bool zlp)
{
    struct ecm_endpoint *ep = handle;
    if (!ep->active || ep->in_pending)
        return ERR_WOULDBLOCK;
    for (unsigned i = 0; i < bytes; ++i)
        ep->in_frame[i] = frame[i];
    err_t result = ep->ops->bulk_in(ep->controller, ep->epoch, ep->in_frame, bytes, zlp);
    ep->in_pending = result == ERR_OK;
    return result;
}

static void cancel_transfers(struct ecm_endpoint *ep)
{
    ep->active = false;
    ep->announce = false;
    ep->ops->cancel(ep->controller);
    ++ep->epoch;
    ep->in_pending = false;
    ep->out_pending = false;
}

err_t ecm_endpoint_open(struct ecm_endpoint *ep, const struct ecm_endpoint_ops *ops,
                        void *controller, unsigned packet_bytes, const uint8_t device_mac[6],
                        const uint8_t host_mac[6], uint64_t node, int64_t beat_period)
{
    if (ep->ops || !ops || !ops->bulk_in || !ops->bulk_out ||
        !ops->interrupt_in || !ops->cancel)
        return ERR_ARG;
    err_t result = ecm_link_open(&ep->link, packet_bytes, device_mac, host_mac, node,
                                beat_period, submit_in, ep);
    if (result == ERR_OK) {
        ep->ops = ops;
        ep->controller = controller;
        ++ep->epoch;
    }
    return result;
}

err_t ecm_endpoint_alt(struct ecm_endpoint *ep, unsigned alternate)
{
    if (!ep->ops)
        return ERR_ARG;
    if (alternate == ep->link.port.control.data_alt)
        return ERR_OK;
    if (!alternate)
        cancel_transfers(ep);
    err_t result = ecm_link_alt(&ep->link, alternate);
    if (result == ERR_OK) {
        ep->active = alternate != 0;
        ep->announce = true;
    }
    return result;
}

void ecm_endpoint_poll(struct ecm_endpoint *ep, int64_t now_us)
{
    if (!ep->ops)
        return;
    if (ep->announce) {
        ecm_connection(&ep->link.port.control, ep->notification);
        if (ep->ops->interrupt_in(ep->controller, ep->epoch, ep->notification,
                                  sizeof ep->notification) == ERR_OK)
            ep->announce = false;
    }
    if (!ep->active)
        return;
    if (!ep->out_pending)
        ep->out_pending = ep->ops->bulk_out(ep->controller, ep->epoch, ep->out_packet,
                                           ep->link.port.packet_bytes) == ERR_OK;
    ecm_link_poll(&ep->link, now_us);
}

void ecm_endpoint_in_done(struct ecm_endpoint *ep, uint32_t epoch)
{
    if (ep->ops && epoch == ep->epoch)
        ep->in_pending = false;
}

void ecm_endpoint_out_done(struct ecm_endpoint *ep, uint32_t epoch, err_t status,
                           unsigned bytes)
{
    if (!ep->ops || epoch != ep->epoch || !ep->out_pending)
        return;
    ep->out_pending = false;
    if (status == ERR_OK && bytes <= ep->link.port.packet_bytes)
        ecm_link_receive(&ep->link, ep->out_packet, bytes);
    else
        ecm_rx_reset(&ep->link.port.receive);
}

void ecm_endpoint_close(struct ecm_endpoint *ep)
{
    if (!ep->ops)
        return;
    cancel_transfers(ep);
    ecm_link_close(&ep->link);
    ep->ops = NULL;
}
