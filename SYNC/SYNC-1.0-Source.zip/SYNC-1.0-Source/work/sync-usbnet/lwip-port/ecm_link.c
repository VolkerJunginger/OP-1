/* SPDX-License-Identifier: GPL-3.0-or-later */
#include "ecm_link.h"
#include "lwip/acd.h"
#include "lwip/etharp.h"
#include "lwip/timeouts.h"
#include "netif/ethernet.h"

static err_t send_frame(struct netif *iface, struct pbuf *p)
{
    struct ecm_link *link = iface->state;
    unsigned bytes = p->tot_len;
    int zlp = ecm_frame_termination_at_speed(bytes, link->port.packet_bytes);
    if (zlp < 0 || pbuf_copy_partial(p, link->tx_frame, p->tot_len, 0) != bytes)
        return ERR_BUF;
    if (!ecm_tx_allowed(&link->port.control, link->host_mac, link->tx_frame, bytes))
        return ERR_OK;
    return link->send(link->context, link->tx_frame, bytes, zlp != 0);
}

static err_t initialize_iface(struct netif *iface)
{
    iface->name[0] = 'e';
    iface->name[1] = 'c';
    iface->hwaddr_len = 6;
    iface->mtu = 1500;
    iface->flags = NETIF_FLAG_BROADCAST | NETIF_FLAG_ETHARP | NETIF_FLAG_IGMP;
    iface->output = etharp_output;
    iface->linkoutput = send_frame;
    return ERR_OK;
}

err_t ecm_link_open(struct ecm_link *link, unsigned packet_bytes,
                    const uint8_t device_mac[6], const uint8_t host_mac[6],
                    uint64_t node, int64_t beat_period, ecm_link_send_fn send,
                    void *context)
{
    if (link->registered || !device_mac || !host_mac || !send || !node ||
        !ecm_port_configure(&link->port, packet_bytes))
        return ERR_ARG;

    link->send = send;
    link->context = context;
    link->next_node = node;
    link->beat_period = beat_period;
    if (!netif_add(&link->iface, IP4_ADDR_ANY4, IP4_ADDR_ANY4, IP4_ADDR_ANY4,
                   link, initialize_iface, ethernet_input)) {
        ecm_port_reset(&link->port);
        return ERR_IF;
    }
    for (unsigned i = 0; i < 6; ++i) {
        link->iface.hwaddr[i] = device_mac[i];
        link->host_mac[i] = host_mac[i];
    }
    autoip_set_struct(&link->iface, &link->autoip);
    link->registered = true;
    return ERR_OK;
}

static void stop_autoip(struct ecm_link *link)
{
    link_net_close(&link->net);
    if (link->autoip_running) {
        (void)acd_stop(&link->autoip.acd);
        acd_remove(&link->iface, &link->autoip.acd);
        autoip_stop(&link->iface);
        link->autoip_running = false;
    }
}

static void stop_link(struct ecm_link *link)
{
    stop_autoip(link);
    netif_set_link_down(&link->iface);
    netif_set_down(&link->iface);
}

err_t ecm_link_alt(struct ecm_link *link, unsigned alternate)
{
    if (!link->registered || alternate > 1)
        return ERR_ARG;
    if (link->port.control.data_alt == alternate)
        return ERR_OK;
    if (!alternate)
        stop_link(link);
    if (!ecm_port_set_alt(&link->port, alternate))
        return ERR_IF;
    if (!alternate)
        return ERR_OK;

    netif_set_up(&link->iface);
    netif_set_link_up(&link->iface);
    return ERR_OK;
}

void ecm_link_poll(struct ecm_link *link, int64_t now_us)
{
    if (!link->registered)
        return;
    /* AutoIP probes are broadcast. Wait for the host filter to allow them. */
    const unsigned promiscuous_or_broadcast = 1u | 8u;
    bool can_probe = ecm_link_up(&link->port.control) &&
                     (link->port.control.packet_filter & promiscuous_or_broadcast);
    if (can_probe && !link->autoip_running)
        link->autoip_running = autoip_start(&link->iface) == ERR_OK;
    else if (!can_probe && link->autoip_running)
        stop_autoip(link);
    sys_check_timeouts();
    const ip4_addr_t *address = netif_ip4_addr(&link->iface);
    bool ready = ecm_link_up(&link->port.control) && autoip_supplied_address(&link->iface);
    if (link->net.iface && (!ready || !ip4_addr_cmp(&link->session_address, address)))
        link_net_close(&link->net);
    if (ready && !link->net.iface &&
        link_net_open(&link->net, &link->iface, link->next_node,
                      now_us, link->beat_period) == ERR_OK) {
        ip4_addr_copy(link->session_address, *address);
        if (!++link->next_node)
            ++link->next_node;
    }
    link_net_poll(&link->net, now_us);
}

static void receive_frame(void *context, const uint8_t *frame, unsigned length)
{
    struct ecm_link *link = context;
    (void)link_net_rx_frame(&link->iface, frame, (uint16_t)length);
}

void ecm_link_receive(struct ecm_link *link, const uint8_t *packet, unsigned bytes)
{
    if (link->registered)
        ecm_port_receive(&link->port, packet, bytes, receive_frame, link);
}

void ecm_link_close(struct ecm_link *link)
{
    if (!link->registered)
        return;
    stop_link(link);
    autoip_remove_struct(&link->iface);
    netif_remove(&link->iface);
    ecm_port_reset(&link->port);
    link->registered = false;
}
