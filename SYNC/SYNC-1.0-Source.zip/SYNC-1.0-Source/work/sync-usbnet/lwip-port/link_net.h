/* SPDX-License-Identifier: GPL-3.0-or-later */
#ifndef ESC_LINK_NET_H
#define ESC_LINK_NET_H

#include "../../sync-link-core/link_session.h"
#include "link_audio_control.h"
#include "lwip/netif.h"

struct link_audio_subscription {
    uint64_t node;
    link_endpoint endpoint;
    int64_t expires;
};

struct link_net {
    struct netif *iface;
    struct udp_pcb *multicast, *discovery, *measurement;
    link_session session;
    int64_t now_us;
    unsigned discovery_rx;
    struct udp_pcb *audio;
    struct link_audio_subscription listeners[LINK_AUDIO_CHANNELS][LINK_MAX_PEERS];
    unsigned audio_channels;
    uint64_t audio_session;
    int64_t audio_announce_at[LINK_MAX_PEERS];
    uint64_t audio_announced_to[LINK_MAX_PEERS];
};

void link_net_audio_configure(struct link_net *net, unsigned channels);
void link_net_audio_poll(struct link_net *net);
unsigned link_net_audio_subscribers(const struct link_net *net, unsigned channel);
unsigned link_net_audio_send(struct link_net *net, unsigned channel, const uint8_t *bytes, uint16_t size);

/* Single NO_SYS worker context. The caller initializes lwIP, maintains
 * IPv4/AutoIP and link state, and calls poll before processing RX frames.
 * Close before changing the interface's address or taking it down. */
err_t link_net_open(struct link_net *net, struct netif *iface, uint64_t node,
                    int64_t now_us, int64_t us_per_beat);
void link_net_close(struct link_net *net);
void link_net_poll(struct link_net *net, int64_t now_us);
/* Inspect an Ethernet frame for the IPv4 Link discovery multicast destination. */
bool link_net_is_discovery_frame(const uint8_t *frame, unsigned length);
/* Feed a complete Ethernet frame into the established lwIP interface. */
err_t link_net_rx_frame(struct netif *iface, const uint8_t *data, uint16_t length);

#endif
