#include "../ecm_rx_queue.h"
#include "ecm_endpoint.h"
#include "../ecm_port.h"

#include "lwip/autoip.h"
#include "lwip/etharp.h"
#include "lwip/init.h"
#include "lwip/inet_chksum.h"
#include "lwip/timeouts.h"
#include "link_audio_control.h"
#include "netif/ethernet.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>

static unsigned discovery_packets;
static uint8_t outbound[1514];
static unsigned outbound_size;
static unsigned audio_counts[LINK_AUDIO_PCM + 1];

static uint32_t test_ms;
uint32_t sys_now(void) { return test_ms; }
uint32_t sync_net_random(void) { return 1; }

static err_t output(struct netif *iface, struct pbuf *p)
{
    (void)iface;
    uint8_t packet[1514];
    assert(p->tot_len <= sizeof packet);
    assert(pbuf_copy_partial(p, packet, p->tot_len, 0) == p->tot_len);
    if (p->tot_len >= 62 && packet[12] == 8 && packet[13] == 0 &&
        packet[23] == 17 && !memcmp(packet + 42, "chnnlsv\1", 8) &&
        packet[50] <= LINK_AUDIO_PCM)
    {
        ++audio_counts[packet[50]];
        if (packet[50] == LINK_AUDIO_PCM) {
            LinkAudioView audio;
            assert(link_audio_decode(&audio, packet + 42, p->tot_len - 42));
            assert(audio.timing.sample_rate == 44100);
            if (audio.timing.channels == 2)
                assert(p->tot_len > ECM_BULK_HIGH_SPEED && audio.sample_count == 250);
            else
                assert(audio.timing.channels == 1 && audio.sample_count == 125);
        }
    }
    if (p->tot_len >= 42 && packet[12] == 8 && packet[13] == 0 &&
        packet[23] == 17 && packet[36] == (LINK_DISCOVERY_PORT >> 8) &&
        packet[37] == (LINK_DISCOVERY_PORT & 255)) {
        link_discovery decoded;
        assert(link_discovery_decode(&decoded, packet + 42, p->tot_len - 42));
        if (decoded.type == LINK_ALIVE) {
            ++discovery_packets;
            outbound_size = p->tot_len;
            memcpy(outbound, packet, outbound_size);
        }
    }
    return ERR_OK;
}

static void inject_audio(struct link_net *net, link_endpoint from,
                         const uint8_t *payload, unsigned length)
{
    uint8_t packet[42 + LINK_AUDIO_CONTROL_CAPACITY] = {0};
    const uint8_t mac[] = {2, 0, 0, 0, 0, 3};
    memcpy(packet, net->iface->hwaddr, 6);
    memcpy(packet + 6, mac, 6);
    packet[12] = 8;
    packet[14] = 0x45;
    packet[17] = (uint8_t)(28 + length);
    packet[22] = 64;
    packet[23] = 17;
    uint32_t source = lwip_htonl(from.ipv4);
    memcpy(packet + 26, &source, sizeof source);
    uint32_t destination = ip4_addr_get_u32(netif_ip4_addr(net->iface));
    memcpy(packet + 30, &destination, sizeof destination);
    uint16_t checksum = inet_chksum(packet + 14, 20);
    memcpy(packet + 24, &checksum, sizeof checksum);
    packet[34] = (uint8_t)(from.port >> 8);
    packet[35] = (uint8_t)from.port;
    packet[36] = (uint8_t)(net->session.state.audio.port >> 8);
    packet[37] = (uint8_t)net->session.state.audio.port;
    packet[39] = (uint8_t)(8 + length);
    memcpy(packet + 42, payload, length);
    assert(link_net_rx_frame(net->iface, packet, (uint16_t)(42 + length)) == ERR_OK);
}

static void test_audio_subscriptions(struct link_net *net)
{
    link_net_audio_configure(net, LINK_AUDIO_ALL);
    assert(net->audio && net->session.state.audio.port);
    const uint64_t master = link_audio_channel_id(net->session.state.node, LINK_AUDIO_MASTER);
    const uint64_t synth = link_audio_channel_id(net->session.state.node, LINK_AUDIO_SYNTH);
    link_endpoint endpoint = {UINT32_C(0xa9fe5805), 30000};
    link_peer *peer = &net->session.peers[0];
    peer->state.node = 5;
    peer->state.audio = endpoint;
    peer->state.measurement.ipv4 = endpoint.ipv4;
    peer->state.session = net->session.state.session;
    peer->expires = net->now_us + 10000000;

    /* Populate the ARP cache through an Ethernet ARP reply. */
    uint8_t arp[42] = {0};
    uint8_t mac[6] = {2, 0, 0, 0, 0, 3};
    memcpy(arp, net->iface->hwaddr, 6);
    memcpy(arp + 6, mac, 6);
    memcpy(arp + 12, "\x08\x06\x00\x01\x08\x00\x06\x04\x00\x02", 10);
    memcpy(arp + 22, mac, 6);
    uint32_t source = lwip_htonl(endpoint.ipv4);
    memcpy(arp + 28, &source, 4);
    memcpy(arp + 32, net->iface->hwaddr, 6);
    uint32_t ip = ip4_addr_get_u32(netif_ip4_addr(net->iface));
    memcpy(arp + 38, &ip, 4);
    assert(link_net_rx_frame(net->iface, arp, sizeof arp) == ERR_OK);
    link_net_audio_poll(net);
    assert(audio_counts[LINK_AUDIO_ANNOUNCEMENT] == 1);

    uint8_t packet[LINK_AUDIO_CONTROL_CAPACITY];
    size_t size = link_audio_control_encode(packet, LINK_AUDIO_REQUEST, 5, master);
    for (unsigned n = 0; n < size; ++n) {
        inject_audio(net, endpoint, packet, n);
        assert(link_net_audio_subscribers(net, LINK_AUDIO_MASTER) == 0);
    }
    inject_audio(net, (link_endpoint){endpoint.ipv4, (uint16_t)(endpoint.port + 1)},
                 packet, (unsigned)size);
    assert(link_net_audio_subscribers(net, LINK_AUDIO_MASTER) == 0);
    inject_audio(net, endpoint, packet, (unsigned)size);
    assert(link_net_audio_subscribers(net, LINK_AUDIO_MASTER) == 1);
    uint8_t audio[LINK_AUDIO_TX_MAX_PACKET];
    int16_t samples[250] = {0};
    LinkAudioTiming timing = {
        .sample_rate = 44100, .channels = 2, .chunk_count = 1,
        .chunks = {{.count = 1, .micros_per_beat = 500000, .frames = 125}}
    };
    link_audio_id(timing.node_id, net->session.state.node);
    link_audio_id(timing.channel_id, master);
    link_audio_id(timing.session_id, net->session.state.session);
    uint16_t audio_size = (uint16_t)link_audio_encode(audio, sizeof audio, &timing, samples, 250);
    assert(audio_size == 574);
    assert(link_net_audio_send(net, LINK_AUDIO_MASTER, audio, audio_size) == 1);
    assert(audio_counts[LINK_AUDIO_PCM] == 1);
    net->now_us += 5000000;
    assert(link_net_audio_subscribers(net, LINK_AUDIO_MASTER) == 0);
    assert(link_net_audio_send(net, LINK_AUDIO_MASTER, audio, audio_size) == 0);
    inject_audio(net, endpoint, packet, (unsigned)size);
    assert(link_net_audio_subscribers(net, LINK_AUDIO_MASTER) == 1);

    size = link_audio_control_encode(packet, LINK_AUDIO_REQUEST, 5, synth);
    inject_audio(net, endpoint, packet, (unsigned)size);
    assert(link_net_audio_subscribers(net, LINK_AUDIO_MASTER) == 1);
    assert(link_net_audio_subscribers(net, LINK_AUDIO_SYNTH) == 1);
    assert(link_net_audio_subscribers(net, LINK_AUDIO_DRUM) == 0);
    timing.channels = 1;
    link_audio_id(timing.channel_id, synth);
    uint16_t mono_size = (uint16_t)link_audio_encode(audio, sizeof audio, &timing, samples, 125);
    assert(mono_size == 324);
    assert(link_net_audio_send(net, LINK_AUDIO_SYNTH, audio, mono_size) == 1);
    assert(link_net_audio_send(net, LINK_AUDIO_DRUM, audio, mono_size) == 0);
    assert(audio_counts[LINK_AUDIO_PCM] == 2);
    for (unsigned channel = LINK_AUDIO_TAPE_1; channel <= LINK_AUDIO_TAPE_4; ++channel) {
        const uint64_t tape = link_audio_channel_id(net->session.state.node, channel);
        assert(link_net_audio_subscribers(net, channel) == 0);
        size = link_audio_control_encode(packet, LINK_AUDIO_REQUEST, 5, tape);
        inject_audio(net, endpoint, packet, (unsigned)size);
        assert(link_net_audio_subscribers(net, channel) == 1);
        link_audio_id(timing.channel_id, tape);
        mono_size = (uint16_t)link_audio_encode(audio, sizeof audio, &timing, samples, 125);
        assert(link_net_audio_send(net, channel, audio, mono_size) == 1);
        size = link_audio_control_encode(packet, LINK_AUDIO_STOP, 5, tape);
        inject_audio(net, endpoint, packet, (unsigned)size);
        assert(link_net_audio_subscribers(net, channel) == 0);
    }
    assert(audio_counts[LINK_AUDIO_PCM] == 6);
    size = link_audio_control_encode(packet, LINK_AUDIO_REQUEST, 5, synth);
    link_net_audio_configure(net, 1u << LINK_AUDIO_MASTER);
    assert(link_net_audio_subscribers(net, LINK_AUDIO_MASTER) == 1);
    assert(link_net_audio_subscribers(net, LINK_AUDIO_SYNTH) == 0);
    inject_audio(net, endpoint, packet, (unsigned)size);
    assert(link_net_audio_subscribers(net, LINK_AUDIO_SYNTH) == 0);

    size = link_audio_control_encode(packet, LINK_AUDIO_STOP, 5, master);
    inject_audio(net, endpoint, packet, (unsigned)size);
    assert(link_net_audio_subscribers(net, LINK_AUDIO_MASTER) == 0);
    link_net_audio_configure(net, false);
    assert(!net->audio && !net->session.state.audio.port);
    assert(audio_counts[LINK_AUDIO_BYE] == 2);
}

static err_t init_iface(struct netif *iface)
{
    iface->name[0] = 'e'; iface->name[1] = 'c';
    iface->hwaddr_len = 6;
    iface->hwaddr[0] = 2;
    iface->mtu = 1500;
    iface->flags = NETIF_FLAG_BROADCAST | NETIF_FLAG_ETHARP | NETIF_FLAG_IGMP;
    iface->output = etharp_output;
    iface->linkoutput = output;
    return ERR_OK;
}

static void from_ecm(void *context, const uint8_t *frame, unsigned length)
{
    assert(link_net_rx_frame(context, frame, length) == ERR_OK);
}

static err_t capture_ecm(void *context, const uint8_t *frame, unsigned length, bool zlp)
{
    unsigned *sent = context;
    assert(zlp == !(length % 512));
    if (length >= 42 && frame[12] == 8 && frame[13] == 0 && frame[23] == 17 &&
        frame[36] == (LINK_DISCOVERY_PORT >> 8) && frame[37] == (LINK_DISCOVERY_PORT & 255)) {
        link_discovery decoded;
        assert(link_discovery_decode(&decoded, frame + 42, length - 42));
        if (decoded.type == LINK_ALIVE)
            ++*sent;
    }
    return ERR_OK;
}

static void test_ecm_link(void)
{
    struct ecm_link link = {0};
    const uint8_t device[6] = {2, 0, 0, 0, 0, 1};
    const uint8_t host[6] = {2, 0, 0, 0, 0, 2};
    const uint8_t filter[8] = {0x21, 0x43, 0x0e, 0, 0, 0, 0, 0};
    unsigned sent = 0;
    assert(ecm_link_open(&link, 512, device, host, 4, 500000, capture_ecm, &sent) == ERR_OK);
    assert(ecm_link_alt(&link, 1) == ERR_OK);
    ecm_link_poll(&link, (int64_t)test_ms * 1000);
    assert(!link.autoip_running);
    assert(ecm_class_setup(&link.port.control, filter));
    int64_t deadline = test_ms + 30000;
    while ((int64_t)test_ms < deadline && !sent) {
        test_ms += 100;
        ecm_link_poll(&link, (int64_t)test_ms * 1000);
    }
    assert(sent == 1 && link.net.session.state.node == 4);
    assert(ecm_link_alt(&link, 0) == ERR_OK);
    assert(!link.net.iface && !netif_is_link_up(&link.iface));
    assert(ecm_link_alt(&link, 1) == ERR_OK);
    deadline = test_ms + 30000;
    while ((int64_t)test_ms < deadline && sent < 2) {
        test_ms += 100;
        ecm_link_poll(&link, (int64_t)test_ms * 1000);
    }
    assert(sent == 2 && link.net.session.state.node == 5);
    ecm_link_close(&link);
    assert(!link.registered && !link.port.control.configured && !link.net.iface);
    assert(ecm_link_open(&link, 512, device, host, 6, 500000, capture_ecm, &sent) == ERR_OK);
    ecm_link_close(&link);
}

struct fake_controller {
    const uint8_t *in;
    uint8_t *out;
    uint32_t epoch;
    unsigned cancelled, notifications, last_link;
};

static err_t queue_in(void *context, uint32_t epoch, const uint8_t *frame,
                      unsigned length, bool zlp)
{
    struct fake_controller *usb = context;
    assert(epoch == usb->epoch && length >= 14 && !zlp && !usb->in);
    usb->in = frame;
    return ERR_OK;
}

static err_t queue_out(void *context, uint32_t epoch, uint8_t *packet, unsigned capacity)
{
    struct fake_controller *usb = context;
    assert(!usb->out && capacity == 512);
    usb->epoch = epoch;
    usb->out = packet;
    return ERR_OK;
}

static err_t queue_notification(void *context, uint32_t epoch,
                                const uint8_t *message, unsigned length)
{
    struct fake_controller *usb = context;
    (void)epoch;
    assert(length == ECM_NOTIFICATION_BYTES && message[0] == 0xa1 && message[2] <= 1);
    usb->last_link = message[2];
    ++usb->notifications;
    return ERR_OK;
}

static void cancel_usb(void *context)
{
    struct fake_controller *usb = context;
    usb->in = NULL;
    usb->out = NULL;
    ++usb->cancelled;
}

static void test_endpoints(void)
{
    static const struct ecm_endpoint_ops ops = {queue_in, queue_out, queue_notification, cancel_usb};
    static const uint8_t device[6] = {2, 0, 0, 0, 0, 1};
    static const uint8_t host[6] = {2, 0, 0, 0, 0, 2};
    static const uint8_t filter[8] = {0x21, 0x43, 0x0e, 0, 0, 0, 0, 0};
    struct fake_controller usb = {0};
    struct ecm_endpoint ep = {0};
    assert(ecm_endpoint_open(&ep, &ops, &usb, 512, device, host, 10, 500000) == ERR_OK);
    ecm_endpoint_poll(&ep, (int64_t)test_ms * 1000);
    assert(!usb.out);
    assert(ecm_endpoint_alt(&ep, 1) == ERR_OK);
    ecm_endpoint_poll(&ep, (int64_t)test_ms * 1000);
    assert(ep.out_pending && usb.out);
    uint32_t previous = usb.epoch;
    assert(ecm_endpoint_alt(&ep, 0) == ERR_OK && usb.cancelled == 1);
    ecm_endpoint_poll(&ep, (int64_t)test_ms * 1000);
    assert(!usb.out && usb.last_link == 0);
    assert(ecm_endpoint_alt(&ep, 1) == ERR_OK);
    ecm_endpoint_poll(&ep, (int64_t)test_ms * 1000);
    assert(ep.out_pending && usb.epoch != previous);
    ecm_endpoint_out_done(&ep, previous, ERR_OK, 64);
    assert(ep.out_pending);
    usb.out = NULL;
    ecm_endpoint_out_done(&ep, usb.epoch, ERR_IF, 0);
    assert(!ep.out_pending && !ep.link.port.receive.length);

    assert(ecm_class_setup(&ep.link.port.control, filter));
    for (unsigned i = 0; i < 300 && !usb.in; ++i) {
        test_ms += 100;
        ecm_endpoint_poll(&ep, (int64_t)test_ms * 1000);
    }
    assert(ep.in_pending && usb.in == ep.in_frame);
    ecm_endpoint_in_done(&ep, previous);
    assert(ep.in_pending);
    usb.in = NULL;
    ecm_endpoint_in_done(&ep, usb.epoch);
    assert(!ep.in_pending);
    ecm_endpoint_close(&ep);
    assert(!ep.ops && !usb.in && !usb.out && usb.cancelled == 2 && usb.notifications == 3 && usb.last_link == 1);
}

int main(void)
{
    lwip_init();
    struct netif iface;
    struct link_net net;
    ip4_addr_t local, mask, gateway;
    ip4_addr_set_zero(&local);
    ip4_addr_set_zero(&mask);
    ip4_addr_set_zero(&gateway);
    assert(netif_add(&iface, &local, &mask, &gateway, NULL, init_iface, ethernet_input));
    assert(link_net_open(&net, &iface, 1, 0, 500000) == ERR_IF);
    netif_set_up(&iface);
    netif_set_link_up(&iface);
    assert(link_net_open(&net, &iface, 1, 0, 500000) == ERR_IF);
    struct autoip autoip;
    autoip_set_struct(&iface, &autoip);
    assert(autoip_start(&iface) == ERR_OK);
    for (test_ms = 100; test_ms <= 30000 && !autoip_supplied_address(&iface);
         test_ms += 100)
        sys_check_timeouts();
    assert(autoip_supplied_address(&iface));
    /* Failure after joining must release membership and all three UDP PCBs. */
    assert(link_net_open(&net, &iface, 0, 0, 500000) == ERR_ARG);
    assert(link_net_open(&net, &iface, 1, 0, 500000) == ERR_OK);
    link_net_poll(&net, 0);
    assert(discovery_packets == 1 && outbound_size > 42);
    assert(link_net_is_discovery_frame(outbound, outbound_size));
    assert(!link_net_is_discovery_frame(outbound, 41));
    uint8_t wrong_port[42];
    memcpy(wrong_port, outbound, sizeof wrong_port);
    wrong_port[37] ^= 1;
    assert(!link_net_is_discovery_frame(wrong_port, sizeof wrong_port));
    wrong_port[37] ^= 1;
    wrong_port[14] = 0x46; /* IP options move the UDP header beyond this buffer. */
    assert(!link_net_is_discovery_frame(wrong_port, sizeof wrong_port));
    struct ecm_rx_queue receive_queue = {0};
    struct ecm_state control = {0};
    ecm_configured(&control, 1);
    assert(ecm_data_alt(&control, 1));
    unsigned received_size = outbound_size;
    for (unsigned frame = 0; frame < ECM_RX_QUEUE_SIZE + 2; ++frame) {
        for (unsigned at = 0; at < received_size; at += 64) {
            unsigned bytes = received_size - at;
            ecm_rx_queue_packet(&receive_queue, &control, 64, outbound + at,
                                bytes > 64 ? 64 : bytes, 1);
        }
        if (!(received_size % 64))
            ecm_rx_queue_packet(&receive_queue, &control, 64, NULL, 0, 1);
    }
    assert(net.discovery_rx == 0);
    ecm_rx_queue_drain(&receive_queue, 1, from_ecm, &iface);
    assert(net.discovery_rx == ECM_RX_QUEUE_SIZE);
    assert(receive_queue.dropped == 2);
    /* Discard a stale frame, and a partial frame across reset. The first
     * complete high-speed frame after re-enumeration survives. */
    ecm_rx_queue_packet(&receive_queue, &control, 512, outbound, received_size, 1);
    ecm_rx_queue_packet(&receive_queue, &control, 64, outbound, 64, 1);
    ecm_rx_queue_packet(&receive_queue, &control, 512, outbound, received_size, 2);
    ecm_rx_queue_drain(&receive_queue, 2, from_ecm, &iface);
    assert(net.discovery_rx == ECM_RX_QUEUE_SIZE + 1);
    assert(link_session_peer_count(&net.session) == 0); /* own announcement */
    link_net_close(&net);
    assert(link_net_open(&net, &iface, 3, 1000, 500000) == ERR_OK);
    /* The saved ALIVE now comes from a different node. Verify RX dispatch. */
    assert(link_net_rx_frame(&iface, outbound, outbound_size) == ERR_OK);
    bool found = false;
    for (unsigned i = 0; i < LINK_MAX_PEERS; ++i)
        found |= net.session.peers[i].expires && net.session.peers[i].state.node == 1;
    assert(found && net.discovery_rx == 1);
    link_net_poll(&net, 1000);
    assert(discovery_packets == 2);
    test_audio_subscriptions(&net);
    link_net_close(&net);
    autoip_stop(&iface);
    autoip_remove_struct(&iface);
    netif_remove(&iface);
    test_ecm_link();
    test_endpoints();
    puts("PASS lwIP AutoIP, Link discovery, Audio announce/subscribe/PCM/stop, ECM receive, close and reopen");
}
