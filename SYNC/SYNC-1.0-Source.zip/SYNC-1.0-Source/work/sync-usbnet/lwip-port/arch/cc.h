/* SPDX-License-Identifier: GPL-3.0-or-later */
#ifndef ESC_LWIP_CC_H
#define ESC_LWIP_CC_H
#include <stdint.h>
#define BYTE_ORDER LITTLE_ENDIAN
#ifdef __bfin__
#define LWIP_NO_INTTYPES_H 1
#define LWIP_NO_CTYPE_H 1
#define LWIP_PLATFORM_DIAG(args) do { } while (0)
void sync_net_assert(const char *message) __attribute__((noreturn));
#define LWIP_PLATFORM_ASSERT(message) sync_net_assert(message)
#endif
uint32_t sync_net_random(void);
#define LWIP_RAND() sync_net_random()
#endif
