/* SPDX-License-Identifier: GPL-3.0-or-later */
#include <stddef.h>
#include <stdint.h>

void *memcpy(void *dst, const void *src, size_t length)
{
    unsigned char *out = dst;
    const unsigned char *in = src;
    for (size_t i = 0; i < length; ++i)
        out[i] = in[i];
    return dst;
}

void *memset(void *dst, int byte, size_t length)
{
    unsigned char *out = dst;
    for (size_t i = 0; i < length; ++i)
        out[i] = (unsigned char)byte;
    return dst;
}

void *memmove(void *dst, const void *src, size_t length)
{
    if ((uintptr_t)dst <= (uintptr_t)src)
        return memcpy(dst, src, length);

    unsigned char *out = dst;
    const unsigned char *in = src;
    while (length) {
        --length;
        out[length] = in[length];
    }
    return dst;
}

int memcmp(const void *a, const void *b, size_t length)
{
    const unsigned char *left = a;
    const unsigned char *right = b;
    for (size_t i = 0; i < length; ++i)
        if (left[i] != right[i])
            return (int)left[i] - right[i];
    return 0;
}

size_t strlen(const char *s)
{
    size_t length = 0;
    while (s[length])
        ++length;
    return length;
}

/* lwIP uses atoi for the numeric suffix of a netif name. */
int atoi(const char *s)
{
    unsigned value = 0;
    while (*s >= '0' && *s <= '9' && value <= 255u)
        value = value * 10u + (unsigned)(*s++ - '0');
    return (int)value;
}

int strncmp(const char *a, const char *b, size_t length)
{
    for (size_t i = 0; i < length; ++i) {
        unsigned char left = (unsigned char)a[i];
        unsigned char right = (unsigned char)b[i];
        if (left != right || !left)
            return (int)left - right;
    }
    return 0;
}
