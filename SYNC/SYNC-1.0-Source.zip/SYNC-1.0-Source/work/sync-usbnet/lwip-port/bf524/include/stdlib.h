#ifndef SYNC_LWIP_STDLIB_H
#define SYNC_LWIP_STDLIB_H
int atoi(const char *s);
#endif
