/* Freestanding declarations used by the pinned lwIP sources. */
#ifndef SYNC_LWIP_STRING_H
#define SYNC_LWIP_STRING_H
#include <stddef.h>
void *memcpy(void *dst, const void *src, size_t length);
void *memset(void *dst, int byte, size_t length);
void *memmove(void *dst, const void *src, size_t length);
int memcmp(const void *a, const void *b, size_t length);
int strncmp(const char *a, const char *b, size_t length);
size_t strlen(const char *s);
#endif
