/* lwIP includes this header with memory overflow diagnostics disabled. */
#ifndef SYNC_LWIP_STDIO_H
#define SYNC_LWIP_STDIO_H
#endif
