#!/bin/sh
set -eu
src=${1:?Pass the src directory of lwIP STABLE-2_2_1_RELEASE}
output=${2:?Pass the absolute destination path for the .opmod}
here=$(CDPATH='' cd -- "$(dirname -- "$0")" && pwd)
root=$(CDPATH='' cd -- "$here/../../../.." && pwd)
kit="$root/Opus Plugin Kit"
core="$root/work/sync-link-core"
audio="$root/work/sync-link-audio"
stage=$(mktemp -d)
trap 'rm -rf "$stage"' EXIT
cp -R "$src/include/lwip" "$src/include/netif" "$stage"
cp -R "$here/../arch" "$stage"
cp "$here/include/"*.h "$here/runtime.c" "$here/netcheck.c" "$here/manifest.txt" "$stage"
cp "$here/../lwipopts.h" "$here/../ecm_link.c" "$here/../link_net.c" "$here/../link_audio_net.c" "$stage"
cp "$here/../../ecm"*.c "$here/../../ecm"*.h "$stage"
cp "$core/link_"*.c "$core/link_"*.h "$stage"
cp "$audio/link_audio_control.c" "$audio/link_audio_control.h" "$audio/link_audio.h" "$stage"
sed -e 's|../ecm_port.h|ecm_port.h|' "$here/../ecm_link.h" > "$stage/ecm_link.h"
sed -e 's|../../sync-link-core/link_session.h|link_session.h|' "$here/../link_net.h" > "$stage/link_net.h"
for f in core/def.c core/init.c core/inet_chksum.c core/ip.c core/mem.c core/memp.c \
    core/netif.c core/pbuf.c core/stats.c core/sys.c core/timeouts.c core/udp.c \
    core/ipv4/acd.c core/ipv4/autoip.c core/ipv4/etharp.c core/ipv4/icmp.c \
    core/ipv4/igmp.c core/ipv4/ip4.c core/ipv4/ip4_addr.c netif/ethernet.c
do
    cp "$src/$f" "$stage"
done
cd "$kit"
python3 plugin_tool.py doctor
python3 plugin_tool.py build "$stage" --out "$output"
python3 plugin_tool.py show "$output"
