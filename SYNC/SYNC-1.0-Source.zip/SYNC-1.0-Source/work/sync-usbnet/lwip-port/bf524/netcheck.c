/* SPDX-License-Identifier: GPL-3.0-or-later */
#include "opus_plugin.h"
#include "op1fw.h"
#include "ecm_link.h"
#include "lwip/init.h"

static struct ecm_link connection;
static uint32_t milliseconds;
static unsigned announcements;
static unsigned result;
static uint8_t first_announcement[256];
static unsigned first_announcement_bytes;

uint32_t sys_now(void) { return milliseconds; }
uint32_t sync_net_random(void) { return 1; }
void sync_net_assert(const char *message)
{
    (void)message;
    __builtin_trap();
}

static err_t simulated_usb_in(void *context, const uint8_t *frame,
                              unsigned length, bool zlp)
{
    (void)context;
    if (zlp != (length % connection.port.packet_bytes == 0))
        return ERR_VAL;
    if (length >= 42 && frame[12] == 8 && frame[13] == 0 && frame[23] == 17 &&
        frame[36] == (LINK_DISCOVERY_PORT >> 8) &&
        frame[37] == (LINK_DISCOVERY_PORT & 255)) {
        link_discovery decoded;
        if (!link_discovery_decode(&decoded, frame + 42, length - 42))
            return ERR_VAL;
        if (decoded.type == LINK_ALIVE) {
            if (!announcements && length <= sizeof first_announcement) {
                for (unsigned i = 0; i < length; ++i)
                    first_announcement[i] = frame[i];
                first_announcement_bytes = length;
            }
            ++announcements;
        }
    }
    return ERR_OK;
}

static int wait_for_announcement(unsigned expected)
{
    for (unsigned i = 0; i < 300 && announcements < expected; ++i) {
        milliseconds += 100;
        ecm_link_poll(&connection, (int64_t)milliseconds * 1000);
    }
    return announcements == expected;
}

static unsigned network_selftest(void)
{
    static const uint8_t device[6] = {2, 0, 0, 0, 0, 1};
    static const uint8_t host[6] = {2, 0, 0, 0, 0, 2};
    static const uint8_t filter[8] = {0x21, 0x43, 0x0e, 0, 0, 0, 0, 0};
    lwip_init();
    if (ecm_link_open(&connection, ECM_BULK_HIGH_SPEED, device, host, 1, 500000,
                      simulated_usb_in, NULL) != ERR_OK)
        return 1;
    if (!ecm_class_setup(&connection.port.control, filter) ||
        ecm_link_alt(&connection, 1) != ERR_OK || !wait_for_announcement(1))
        return 2;
    if (ecm_link_alt(&connection, 0) != ERR_OK || connection.net.iface)
        return 3;
    if (ecm_link_alt(&connection, 1) != ERR_OK || !wait_for_announcement(2) ||
        connection.net.session.state.node != 2)
        return 4;
    ecm_link_close(&connection);
    if (ecm_link_open(&connection, ECM_BULK_PACKET, device, host, 3, 500000,
                      simulated_usb_in, NULL) != ERR_OK ||
        !ecm_class_setup(&connection.port.control, filter) ||
        ecm_link_alt(&connection, 1) != ERR_OK || !wait_for_announcement(3))
        return 5;

    if (!first_announcement_bytes)
        return 6;
    for (unsigned i = 0; i < first_announcement_bytes; i += ECM_BULK_PACKET) {
        unsigned left = first_announcement_bytes - i;
        ecm_link_receive(&connection, first_announcement + i,
                         left < ECM_BULK_PACKET ? left : ECM_BULK_PACKET);
    }
    if (first_announcement_bytes % ECM_BULK_PACKET == 0)
        ecm_link_receive(&connection, NULL, 0);

    for (unsigned i = 0; i < LINK_MAX_PEERS; ++i)
        if (connection.net.session.peers[i].expires &&
            connection.net.session.peers[i].state.node == 1)
            return 0;
    return 7;
}

static int rows(int index, const char **label, char *value)
{
    if (index != 0)
        return 0;
    *label = "lwip link selftest";
    if (result)
        fw_snprintf(value, 40, "fail %u", result);
    else
        fw_snprintf(value, 40, "pass");
    return 1;
}

int opl_init(struct opl_self *self)
{
    result = network_selftest();
    ecm_link_close(&connection);
    opus_on_settings_rows(self, rows);
    return 0;
}
