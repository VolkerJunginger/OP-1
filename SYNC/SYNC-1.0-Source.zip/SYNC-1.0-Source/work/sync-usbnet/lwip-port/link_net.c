/* SPDX-License-Identifier: GPL-3.0-or-later */
#include "link_net.h"
#include "lwip/igmp.h"
#include "lwip/pbuf.h"
#include "lwip/udp.h"
#include "netif/ethernet.h"

static void group_address(ip4_addr_t *group)
{
    ip4_addr_set_u32(group, lwip_htonl(LINK_DISCOVERY_GROUP));
}

static void transmit(struct link_net *net, const link_transmit *tx)
{
    if (!tx->size)
        return;
    struct pbuf *p = pbuf_alloc(PBUF_TRANSPORT, (u16_t)tx->size, PBUF_RAM);
    if (!p)
        return;
    ip_addr_t target;
    ip_addr_set_ip4_u32(&target, lwip_htonl(tx->target.ipv4));
    struct udp_pcb *source = tx->socket == LINK_SOCKET_MEASUREMENT ?
                            net->measurement : net->discovery;
    if (pbuf_take(p, tx->data, (u16_t)tx->size) == ERR_OK)
        (void)udp_sendto_if(source, p, &target, tx->target.port, net->iface);
    pbuf_free(p);
}

static void received(void *context, struct udp_pcb *pcb, struct pbuf *p,
                     const ip_addr_t *remote, u16_t port)
{
    struct link_net *net = context;
    if (pcb != net->measurement) ++net->discovery_rx;
    static uint8_t bytes[LINK_SYNC_MAX_PACKET];
    u16_t size = p->tot_len;
    if (size > sizeof bytes || pbuf_copy_partial(p, bytes, size, 0) != size) {
        pbuf_free(p);
        return;
    }
    link_endpoint from = {lwip_ntohl(ip_addr_get_ip4_u32(remote)), port};
    pbuf_free(p);
    link_transmit tx;
    link_session_receive(&net->session,
                         pcb == net->measurement ? LINK_SOCKET_MEASUREMENT : LINK_SOCKET_DISCOVERY,
                         from, bytes, size, net->now_us, &tx);
    transmit(net, &tx);
}

err_t link_net_open(struct link_net *net, struct netif *iface, uint64_t node,
                    int64_t now_us, int64_t us_per_beat)
{
    if (!iface || ip4_addr_isany(netif_ip4_addr(iface)) ||
        !netif_is_up(iface) || !netif_is_link_up(iface) ||
        !(iface->flags & NETIF_FLAG_IGMP))
        return ERR_IF;
    *net = (struct link_net){.iface = iface, .now_us = now_us};
    net->multicast = udp_new_ip_type(IPADDR_TYPE_V4);
    net->discovery = udp_new_ip_type(IPADDR_TYPE_V4);
    net->measurement = udp_new_ip_type(IPADDR_TYPE_V4);
    err_t error = ERR_MEM;
    if (!net->multicast || !net->discovery || !net->measurement)
        goto fail;

    udp_bind_netif(net->multicast, iface);
    udp_bind_netif(net->discovery, iface);
    udp_bind_netif(net->measurement, iface);
    error = udp_bind(net->multicast, IP_ADDR_ANY, LINK_DISCOVERY_PORT);
    if (!error) error = udp_bind(net->discovery, &iface->ip_addr, 0);
    if (!error) error = udp_bind(net->measurement, &iface->ip_addr, 0);
    if (error)
        goto fail;

    link_endpoint endpoint = {lwip_ntohl(ip4_addr_get_u32(netif_ip4_addr(iface))),
                              net->measurement->local_port};
    ip4_addr_t group;
    group_address(&group);
    error = igmp_joingroup_netif(iface, &group);
    if (error)
        goto fail;
    if (!link_session_open(&net->session, node, endpoint, now_us, us_per_beat)) {
        (void)igmp_leavegroup_netif(iface, &group);
        error = ERR_ARG;
        goto fail;
    }

    udp_recv(net->multicast, received, net);
    udp_recv(net->discovery, received, net);
    udp_recv(net->measurement, received, net);
    return ERR_OK;

fail:
    link_net_close(net);
    return error;
}

void link_net_close(struct link_net *net)
{
    link_net_audio_configure(net, false);
    if (net->session.state.node) {
        link_transmit tx;
        link_session_close(&net->session, &tx);
        transmit(net, &tx);
        ip4_addr_t group;
        group_address(&group);
        (void)igmp_leavegroup_netif(net->iface, &group);
    }
    if (net->measurement) udp_remove(net->measurement);
    if (net->discovery) udp_remove(net->discovery);
    if (net->multicast) udp_remove(net->multicast);
    *net = (struct link_net){0};
}

void link_net_poll(struct link_net *net, int64_t now_us)
{
    if (!net->session.state.node)
        return;
    net->now_us = now_us;
    link_transmit tx;
    link_session_poll(&net->session, now_us, &tx);
    transmit(net, &tx);
}

bool link_net_is_discovery_frame(const uint8_t *frame, unsigned length)
{
    if (!frame || length < 42 || frame[12] != 0x08 || frame[13] != 0 ||
        (frame[14] >> 4) != 4 || frame[23] != 17 ||
        (frame[20] & 0x1f) || frame[21])
        return false;

    unsigned header_bytes = (frame[14] & 0x0f) * 4u;
    if (header_bytes < 20 || length < 14u + header_bytes + 8u)
        return false;

    const uint8_t *dst = frame + 30;
    uint32_t group = ((uint32_t)dst[0] << 24) | ((uint32_t)dst[1] << 16) |
                     ((uint32_t)dst[2] << 8) | dst[3];
    const uint8_t *port = frame + 14u + header_bytes + 2u;
    return group == LINK_DISCOVERY_GROUP &&
           ((unsigned)port[0] << 8 | port[1]) == LINK_DISCOVERY_PORT;
}

err_t link_net_rx_frame(struct netif *iface, const uint8_t *data, uint16_t length)
{
    if (!iface || !data || length < 14 || length > 1514)
        return ERR_ARG;
    struct pbuf *p = pbuf_alloc(PBUF_RAW, length, PBUF_POOL);
    if (!p)
        return ERR_MEM;
    err_t error = pbuf_take(p, data, length);
    if (error) {
        pbuf_free(p);
        return error;
    }
    return ethernet_input(p, iface);
}
