#!/bin/sh
set -eu
src=${1:?Pass the src directory of lwIP STABLE-2_2_1_RELEASE}
here=$(CDPATH='' cd -- "$(dirname -- "$0")" && pwd)
core="$here/../../sync-link-core"
audio="$here/../../sync-link-audio"
tmp=$(mktemp -d)
trap 'rm -rf "$tmp"' EXIT
set -- "$src/core/def.c" "$src/core/init.c" "$src/core/inet_chksum.c" \
    "$src/core/ip.c" "$src/core/mem.c" "$src/core/memp.c" "$src/core/netif.c" \
    "$src/core/pbuf.c" "$src/core/stats.c" "$src/core/sys.c" "$src/core/timeouts.c" \
    "$src/core/udp.c" "$src/core/ipv4/acd.c" "$src/core/ipv4/autoip.c" \
    "$src/core/ipv4/etharp.c" "$src/core/ipv4/icmp.c" "$src/core/ipv4/igmp.c" \
    "$src/core/ipv4/ip4.c" "$src/core/ipv4/ip4_addr.c" "$src/netif/ethernet.c"
"${CC:-clang}" -O1 -g -fsanitize=address,undefined -fno-sanitize-recover=all \
    -I "$here" -I "$audio" -I "$src/include" "$here/test_link_net.c" "$here/link_net.c" "$here/link_audio_net.c" "$here/ecm_link.c" "$here/ecm_endpoint.c" \
    "$here/../ecm.c" "$here/../ecm_bulk.c" "$here/../ecm_port.c" "$here/../ecm_rx_queue.c" \
    "$core/link_session.c" "$core/link_wire.c" "$core/link_timeline.c" "$core/link_clock.c" \
    "$audio/link_audio.c" "$audio/link_audio_control.c" \
    "$@" -o "$tmp/test"
"$tmp/test"
