/* SPDX-License-Identifier: GPL-3.0-or-later */
#ifndef ESC_LWIPOPTS_H
#define ESC_LWIPOPTS_H

#define NO_SYS 1
#define LWIP_DONT_PROVIDE_BYTEORDER_FUNCTIONS 1
#define LWIP_SOCKET 0
#define LWIP_NETCONN 0
#define LWIP_TCP 0
#define LWIP_UDP 1
#define LWIP_RAW 0
#define LWIP_IPV4 1
#define LWIP_IPV6 0
#define LWIP_ARP 1
#define LWIP_AUTOIP 1
#define LWIP_IGMP 1
#define LWIP_DHCP 0
#define LWIP_DNS 0
#define IP_FORWARD 0
#define IP_REASSEMBLY 0
#define IP_FRAG 0
#define MEM_ALIGNMENT __SIZEOF_POINTER__
#define MEM_SIZE (12 * 1024)
#define PBUF_POOL_SIZE 8
#define MEMP_NUM_UDP_PCB 4
#define MEMP_NUM_IGMP_GROUP 4
#define SYS_LIGHTWEIGHT_PROT 0

#endif
