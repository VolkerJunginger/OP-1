/* SPDX-License-Identifier: GPL-3.0-or-later */
#include "link_net.h"
#include "link_audio_control.h"
#include "lwip/udp.h"

static bool same_endpoint(link_endpoint first, link_endpoint second)
{
    return first.ipv4 == second.ipv4 && first.port == second.port;
}

static bool audio_peer(const struct link_net *net, unsigned slot)
{
    const link_peer *peer = &net->session.peers[slot];
    return peer->expires > net->now_us && peer->state.audio.port &&
           peer->state.audio.ipv4 == peer->state.measurement.ipv4;
}

static bool subscribed(const struct link_net *net, unsigned channel, unsigned slot)
{
    const link_peer *peer = &net->session.peers[slot];
    const struct link_audio_subscription *sub = &net->listeners[channel][slot];
    return audio_peer(net, slot) && peer->state.session == net->session.state.session &&
           sub->expires > net->now_us && sub->node == peer->state.node &&
           same_endpoint(sub->endpoint, peer->state.audio);
}

static err_t send_audio(struct link_net *net, link_endpoint endpoint,
                       const uint8_t *bytes, uint16_t size)
{
    struct pbuf *p = pbuf_alloc(PBUF_TRANSPORT, size, PBUF_RAM);
    if (!p) return ERR_MEM;
    ip_addr_t target;
    ip_addr_set_ip4_u32(&target, lwip_htonl(endpoint.ipv4));
    err_t error = pbuf_take(p, bytes, size);
    if (!error) error = udp_sendto_if(net->audio, p, &target, endpoint.port, net->iface);
    pbuf_free(p);
    return error;
}

static void received(void *context, struct udp_pcb *pcb, struct pbuf *p,
                     const ip_addr_t *remote, u16_t port)
{
    struct link_net *net = context;
    (void)pcb;
    /* The network worker serializes reception, so one fixed buffer is enough. */
    static uint8_t bytes[LINK_AUDIO_RX_MAX_PACKET];
    const uint16_t size = p->tot_len;
    bool copied = size <= sizeof bytes && pbuf_copy_partial(p, bytes, size, 0) == size;
    pbuf_free(p);
    struct link_audio_control message;
    if (!copied || !link_audio_control_decode(&message, bytes, size) ||
        net->audio_session != net->session.state.session)
        return;

    const link_endpoint from = {lwip_ntohl(ip_addr_get_ip4_u32(remote)), port};
    for (unsigned i = 0; i < LINK_MAX_PEERS; ++i) {
        const link_peer *peer = &net->session.peers[i];
        if (!audio_peer(net, i) || peer->state.node != message.node ||
            !same_endpoint(peer->state.audio, from))
            continue;

        if (message.type == LINK_AUDIO_ANNOUNCEMENT && message.has_host_time) {
            uint8_t reply[LINK_AUDIO_CONTROL_CAPACITY];
            size_t length = link_audio_control_encode(reply, LINK_AUDIO_PONG,
                                                       net->session.state.node, message.host_time);
            (void)send_audio(net, from, reply, (uint16_t)length);
        } else if (peer->state.session == net->session.state.session) {
            for (unsigned channel = 0; channel < LINK_AUDIO_CHANNELS; ++channel) {
                if (!(net->audio_channels & (1u << channel)) ||
                    message.channel != link_audio_channel_id(net->session.state.node, channel))
                    continue;
                struct link_audio_subscription *sub = &net->listeners[channel][i];
                if (message.type == LINK_AUDIO_STOP) {
                    *sub = (struct link_audio_subscription){0};
                } else if (message.type == LINK_AUDIO_REQUEST && message.ttl) {
                    unsigned ttl = message.ttl > LINK_AUDIO_TTL ? LINK_AUDIO_TTL : message.ttl;
                    *sub = (struct link_audio_subscription){
                        message.node, from, net->now_us + (int64_t)ttl * 1000000
                    };
                }
                break;
            }
        }
        return;
    }
}

void link_net_audio_configure(struct link_net *net, unsigned channels)
{
    channels &= LINK_AUDIO_ALL;
    if (net->audio_channels == channels)
        return;
    unsigned removed = net->audio_channels & ~channels;
    if (removed) {
        uint8_t bye[LINK_AUDIO_CONTROL_CAPACITY];
        const size_t length = link_audio_bye(bye, net->session.state.node, removed);
        for (unsigned i = 0; i < LINK_MAX_PEERS; ++i) {
            if (audio_peer(net, i))
                (void)send_audio(net, net->session.peers[i].state.audio, bye, (uint16_t)length);
        }
        for (unsigned channel = 0; channel < LINK_AUDIO_CHANNELS; ++channel)
            if (removed & (1u << channel))
                for (unsigned i = 0; i < LINK_MAX_PEERS; ++i)
                    net->listeners[channel][i] = (struct link_audio_subscription){0};
    }
    if (!channels) {
        udp_remove(net->audio);
        net->audio = NULL;
        net->audio_channels = 0;
        net->session.state.audio = (link_endpoint){0};
        net->session.next_broadcast = 0;
        return;
    }
    if (!net->session.state.node)
        return;

    if (!net->audio) {
        struct udp_pcb *socket = udp_new_ip_type(IPADDR_TYPE_V4);
        if (!socket)
            return;
        udp_bind_netif(socket, net->iface);
        if (udp_bind(socket, &net->iface->ip_addr, 0) != ERR_OK) {
            udp_remove(socket);
            return;
        }
        net->audio = socket;
        net->audio_session = net->session.state.session;
        net->session.state.audio = (link_endpoint){
            lwip_ntohl(ip4_addr_get_u32(netif_ip4_addr(net->iface))), socket->local_port
        };
        net->session.next_broadcast = 0;
        udp_recv(socket, received, net);
    }
    net->audio_channels = channels;
    for (unsigned i = 0; i < LINK_MAX_PEERS; ++i)
        net->audio_announce_at[i] = 0;
}

void link_net_audio_poll(struct link_net *net)
{
    if (!net->audio)
        return;
    if (net->audio_session != net->session.state.session) {
        net->audio_session = net->session.state.session;
        for (unsigned i = 0; i < LINK_MAX_PEERS; ++i) {
            for (unsigned channel = 0; channel < LINK_AUDIO_CHANNELS; ++channel)
                net->listeners[channel][i].expires = 0;
            net->audio_announce_at[i] = 0;
        }
    }
    for (unsigned i = 0; i < LINK_MAX_PEERS; ++i) {
        if (!audio_peer(net, i)) {
            for (unsigned channel = 0; channel < LINK_AUDIO_CHANNELS; ++channel)
                net->listeners[channel][i].expires = 0;
            net->audio_announced_to[i] = 0;
            continue;
        }
        const link_peer *peer = &net->session.peers[i];
        if (net->audio_announced_to[i] == peer->state.node &&
            net->audio_announce_at[i] > net->now_us)
            continue;
        uint8_t packet[LINK_AUDIO_CONTROL_CAPACITY];
        size_t length = link_audio_announce(packet, net->session.state.node,
                                            net->audio_session, net->audio_channels);
        err_t error = send_audio(net, peer->state.audio, packet, (uint16_t)length);
        net->audio_announce_at[i] = net->now_us + (error ? 20000 : 250000);
        net->audio_announced_to[i] = peer->state.node;
        break;
    }
}

unsigned link_net_audio_subscribers(const struct link_net *net, unsigned channel)
{
    if (channel >= LINK_AUDIO_CHANNELS || !(net->audio_channels & (1u << channel)) ||
        net->audio_session != net->session.state.session)
        return 0;
    unsigned count = 0;
    for (unsigned i = 0; i < LINK_MAX_PEERS; ++i)
        count += subscribed(net, channel, i);
    return count;
}

unsigned link_net_audio_send(struct link_net *net, unsigned channel, const uint8_t *bytes, uint16_t size)
{
    if (channel >= LINK_AUDIO_CHANNELS || !(net->audio_channels & (1u << channel)) ||
        net->audio_session != net->session.state.session)
        return 0;
    unsigned count = 0;
    for (unsigned i = 0; i < LINK_MAX_PEERS; ++i) {
        if (subscribed(net, channel, i) && !send_audio(net, net->listeners[channel][i].endpoint, bytes, size))
            ++count;
    }
    return count;
}
