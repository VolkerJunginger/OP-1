# SYNC Link über lwIP

Der Port verbindet den C-Link-Core über lwIP 2.2.1 mit einem IPv4-netif.
Ein einzelner NO_SYS-Worker führt alle Aufrufe aus. `ecm_link.c` verwaltet
die lwIP-Schnittstelle, AutoIP, Timer und Link-Session. Der Firmwareadapter
aktiviert die USB-Endpunkte, leitet Änderungen des ECM-Paketfilters und
des Alternate Settings in den Worker und übergibt USB-OUT-Pakete.
Die TX-Funktion muss den angegebenen Frame kopieren, bevor sie zurückkehrt.
Sie erhält das ZLP-Flag zur Terminierung. Vor dem Abbau muss der
Firmwareadapter alte Transferabschlüsse vom neuen Empfang fernhalten.
Der Worker stoppt Link und AutoIP bei Alt 0. Bei Wiederaktivierung wird
die Session mit neuer Node-ID eröffnet.

Die drei UDP-PCBs empfangen Multicast-Discovery, unicast Discovery und
Clock-Measurement. Jeder Ausgangspuffer wird nach dem Versandversuch
freigegeben. Ausgabefehler werden als verlorene UDP-Datagramme behandelt.

## Hostprüfung

```sh
sh work/sync-usbnet/lwip-port/test.sh /pfad/zu/lwip/src
```

Verwende den Upstream-Tag `STABLE-2_2_1_RELEASE`. Der Test verwendet
echte lwIP-Ethernet-, IP-, IGMP- und UDP-Verarbeitung mit einer simulierten
Ethernet-Schnittstelle. Er prüft Link ALIVE, RX über fragmentierten
ECM-Bulk-OUT, den Empfang eines zweiten Nodes und das erneute Öffnen nach
einem Fehler oder regulären Abbau. lwIP bezieht die Testadresse mit
AutoIP über eine simulierte NIC. Adresskonflikte und UDP mit Ableton Live
bleiben separat zu prüfen.

Die Blackfin-Objektkompilierung beider Adapter ist geprüft. Für ein Geräte-
Linking fehlen Plattformfunktionen für Zeit, Zufall und den Assertion-Pfad
sowie die aktive R246-CDC-ECM-Anbindung.

[Upstream-Quelle](https://github.com/lwip-tcpip/lwip/tree/STABLE-2_2_1_RELEASE)

## Übergabe an den USB-Controller

`ecm_endpoint.c` hält getrennte IN-, OUT- und Notification-Puffer und
bindet den ECM-Worker an asynchrone Controller-Transfers. Es meldet den
Linkstatus beim Altsetting-Wechsel, behandelt OUT-Fehler und verhindert
durch einen Generationswert, dass ein verspäteter Abschluss einer alten
Konfiguration den neuen Empfang verändert. Der Backend-Abbruch muss vor
der Wiederverwendung die Puffer synchron freigeben. Die Laufzeitprüfung
verwendet einen simulierten Controller. Das OPUS SDK stellt die
Registrierung, die tatsächliche Transferübernahme und den synchronen
Abbruch für eigene R246-Endpunkte derzeit nicht bereit.
