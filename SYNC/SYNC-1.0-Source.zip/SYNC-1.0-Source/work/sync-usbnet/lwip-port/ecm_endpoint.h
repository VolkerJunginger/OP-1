/* SPDX-License-Identifier: GPL-3.0-or-later */
#ifndef ESC_ECM_ENDPOINT_H
#define ESC_ECM_ENDPOINT_H

#include "ecm_link.h"

/* Deferred completions and all bridge calls belong to the NO_SYS worker.
 * A submission borrows its buffer until completion or cancel. cancel must
 * synchronously release the buffers; no callbacks during these operations.
 * The backend passes the epoch of the submitted transfer to its completion. */
struct ecm_endpoint_ops {
    err_t (*bulk_in)(void *context, uint32_t epoch, const uint8_t *frame,
                     unsigned bytes, bool zlp);
    err_t (*bulk_out)(void *context, uint32_t epoch, uint8_t *packet, unsigned capacity);
    err_t (*interrupt_in)(void *context, uint32_t epoch, const uint8_t *message, unsigned bytes);
    void (*cancel)(void *context);
};

struct ecm_endpoint {
    struct ecm_link link;
    const struct ecm_endpoint_ops *ops;
    void *controller;
    uint32_t epoch;
    bool active, in_pending, out_pending, announce;
    uint8_t notification[ECM_NOTIFICATION_BYTES];
    uint8_t in_frame[ECM_MAX_FRAME];
    uint8_t out_packet[ECM_BULK_HIGH_SPEED];
};

/* Call after the backend has selected the ECM configuration and has an
 * interrupt endpoint and bulk pipe pair. Zero-initialize the object once. */
err_t ecm_endpoint_open(struct ecm_endpoint *ep, const struct ecm_endpoint_ops *ops,
                        void *controller, unsigned packet_bytes, const uint8_t device_mac[6],
                        const uint8_t host_mac[6], uint64_t node, int64_t beat_period);
/* Call after changing the data alternate setting on the controller. */
err_t ecm_endpoint_alt(struct ecm_endpoint *ep, unsigned alternate);
void ecm_endpoint_poll(struct ecm_endpoint *ep, int64_t now_us);
void ecm_endpoint_in_done(struct ecm_endpoint *ep, uint32_t epoch);
void ecm_endpoint_out_done(struct ecm_endpoint *ep, uint32_t epoch, err_t status,
                           unsigned bytes);
void ecm_endpoint_close(struct ecm_endpoint *ep);
#endif
