/* SPDX-License-Identifier: GPL-3.0-or-later */
#include "ecm_bulk.h"

void ecm_rx_reset(struct ecm_rx *rx)
{
    rx->length = 0;
    rx->discard = 0;
}

void ecm_rx_packet(struct ecm_rx *rx, const struct ecm_state *state,
                   const uint8_t *data, unsigned length,
                   ecm_receive_fn receive, void *context)
{
    ecm_rx_packet_at_speed(rx, state, ECM_BULK_PACKET, data, length, receive, context);
}

void ecm_rx_packet_at_speed(struct ecm_rx *rx, const struct ecm_state *state,
                            unsigned bulk_packet_bytes, const uint8_t *data,
                            unsigned length, ecm_receive_fn receive, void *context)
{
    if (!ecm_link_up(state) ||
        (bulk_packet_bytes != ECM_BULK_PACKET && bulk_packet_bytes != ECM_BULK_HIGH_SPEED)) {
        ecm_rx_reset(rx);
        return;
    }
    if (length > bulk_packet_bytes || length > ECM_MAX_FRAME - rx->length ||
        (length && !data))
        rx->discard = 1;

    if (!rx->discard) {
        for (unsigned i = 0; i < length; ++i)
            rx->frame[rx->length + i] = data[i];
        rx->length += length;
    }

    if (length < bulk_packet_bytes) {
        if (!rx->discard && rx->length >= 14 && receive)
            receive(context, rx->frame, rx->length);
        ecm_rx_reset(rx);
    }
}

int ecm_tx_allowed(const struct ecm_state *state, const uint8_t mac[6],
                   const uint8_t *frame, unsigned length)
{
    enum { PROMISCUOUS = 1, ALL_MULTICAST = 2, DIRECTED = 4, BROADCAST = 8 };
    if (!frame || !ecm_link_up(state) || ecm_frame_termination(length) < 0)
        return 0;
    unsigned filter = state->packet_filter;
    if (filter & PROMISCUOUS)
        return 1;
    if (frame[0] & 1u) {
        int broadcast = 1;
        for (unsigned i = 0; i < 6; ++i)
            broadcast &= frame[i] == 255;
        return (filter & (broadcast ? BROADCAST : ALL_MULTICAST)) != 0;
    }
    if (!(filter & DIRECTED))
        return 0;
    for (unsigned i = 0; i < 6; ++i)
        if (frame[i] != mac[i])
            return 0;
    return 1;
}
