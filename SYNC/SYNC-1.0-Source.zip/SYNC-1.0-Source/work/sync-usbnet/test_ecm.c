#include "ecm.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>

int main(void)
{
    uint8_t cfg[ECM_CONFIG_BYTES];
    struct ecm_endpoints endpoints = {0x81, 2, 0x82};
    assert(ecm_configuration(cfg, endpoints, 4) == sizeof cfg);
    assert(cfg[2] == sizeof cfg && cfg[4] == 2);
    unsigned interfaces = 0, endpoints_seen = 0;
    for (unsigned at = 0; at < sizeof cfg; at += cfg[at]) {
        assert(cfg[at] >= 2 && cfg[at] <= sizeof cfg - at);
        if (cfg[at + 1] == 4) {
            assert(cfg[at + 2] == (interfaces > 0));
            assert(cfg[at + 3] == (interfaces == 2));
            ++interfaces;
        }
        if (cfg[at + 1] == 5) {
            static const uint8_t expected[] = {0x81, 2, 0x82};
            assert(endpoints_seen < sizeof expected);
            assert(cfg[at + 2] == expected[endpoints_seen++]);
        }
    }
    assert(interfaces == 3 && endpoints_seen == 3);
    assert(ecm_configuration_at_speed(cfg, endpoints, 4, 512, 0) == sizeof cfg);
    assert(cfg[1] == 2 && cfg[78] == 0 && cfg[79] == 2);
    assert(cfg[86] == 2 && cfg[85] == 0);
    assert(ecm_configuration_at_speed(cfg, endpoints, 4, 64, 1) == sizeof cfg);
    assert(cfg[1] == 7 && cfg[85] == 64 && cfg[86] == 0);
    assert(!ecm_configuration_at_speed(cfg, endpoints, 4, 128, 0));
    assert(ecm_frame_termination_at_speed(512, 512) == 1);
    assert(ecm_frame_termination_at_speed(64, 512) == 0);
    assert(!ecm_configuration(cfg, endpoints, 0));
    endpoints.bulk_in = endpoints.interrupt_in;
    assert(!ecm_configuration(cfg, endpoints, 4));
    struct ecm_state state = {0};
    uint8_t filter[8] = {0x21, 0x43, 0x1c, 0, 0, 0, 0, 0};
    assert(!ecm_class_setup(&state, filter));
    assert(!ecm_data_alt(&state, 1));
    ecm_configured(&state, 1);
    assert(!ecm_link_up(&state) && !ecm_data_alt(&state, 2));
    for (unsigned i = 4; i < 8; ++i) {
        filter[i] = 1;
        assert(!ecm_class_setup(&state, filter) && !state.packet_filter);
        filter[i] = 0;
    }
    assert(ecm_class_setup(&state, filter) && state.packet_filter == 0x1c);
    assert(ecm_data_alt(&state, 1) && ecm_link_up(&state));
    uint8_t notification[ECM_NOTIFICATION_BYTES];
    ecm_connection(&state, notification);
    assert(notification[0] == 0xa1 && notification[1] == 0 && notification[2] == 1);
    for (unsigned i = 3; i < sizeof notification; ++i)
        assert(notification[i] == 0);
    uint8_t speed[ECM_SPEED_NOTIFICATION_BYTES];
    static const uint8_t high_speed[] = {
        0xa1, 0x2a, 0, 0, 0, 0, 8, 0, 0, 0, 0x64, 0x19, 0, 0, 0x64, 0x19
    };
    static const uint8_t full_speed[] = {
        0xa1, 0x2a, 0, 0, 0, 0, 8, 0, 0, 0x70, 0x94, 0, 0, 0x70, 0x94, 0
    };
    ecm_connection_speed(&state, ECM_BULK_HIGH_SPEED, speed);
    assert(!memcmp(speed, high_speed, sizeof speed));
    ecm_connection_speed(&state, ECM_BULK_PACKET, speed);
    assert(!memcmp(speed, full_speed, sizeof speed));
    assert(ecm_data_alt(&state, 0) && !ecm_link_up(&state));
    ecm_connection(&state, notification);
    assert(notification[2] == 0);
    ecm_connection_speed(&state, ECM_BULK_HIGH_SPEED, speed);
    assert(!memcmp(speed, high_speed, ECM_NOTIFICATION_BYTES));
    for (unsigned i = ECM_NOTIFICATION_BYTES; i < sizeof speed; ++i)
        assert(speed[i] == 0);
    ecm_configured(&state, 0);
    assert(!ecm_link_up(&state) && !state.packet_filter);
    ecm_configured(&state, 1);
    assert(!ecm_link_up(&state) && !state.packet_filter);
    assert(ecm_frame_termination(0) == -1 && ecm_frame_termination(1515) == -1);
    assert(ecm_frame_termination(64) == 1 && ecm_frame_termination(128) == 1);
    assert(ecm_frame_termination(65) == 0 && ecm_frame_termination(1514) == 0);
    puts("PASS ECM filter, reset, link notifications and bulk IN termination");
    puts("PASS full-speed ECM configuration, alternate settings and endpoint validation");
}
