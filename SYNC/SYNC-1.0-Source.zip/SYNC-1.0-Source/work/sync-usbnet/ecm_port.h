/* SPDX-License-Identifier: GPL-3.0-or-later */
#ifndef ESC_ECM_PORT_H
#define ESC_ECM_PORT_H
#include "ecm_bulk.h"

struct ecm_port {
    struct ecm_state control;
    struct ecm_rx receive;
    unsigned packet_bytes;
};

/* Invoke only after the controller cancels old transfers. A zero packet
 * size leaves the port disabled. Configuration starts at Data Alt 0. */
int ecm_port_configure(struct ecm_port *port, unsigned packet_bytes);
int ecm_port_set_alt(struct ecm_port *port, unsigned alternate);
void ecm_port_reset(struct ecm_port *port);
void ecm_port_receive(struct ecm_port *port, const uint8_t *data, unsigned length,
                      ecm_receive_fn receive, void *context);
#endif
