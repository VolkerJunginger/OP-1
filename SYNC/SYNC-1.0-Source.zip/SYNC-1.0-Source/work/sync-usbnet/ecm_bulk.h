/* SPDX-License-Identifier: GPL-3.0-or-later */
#ifndef ESC_ECM_BULK_H
#define ESC_ECM_BULK_H
#include "ecm.h"

struct ecm_rx {
    uint8_t frame[ECM_MAX_FRAME];
    unsigned length;
    int discard;
};

typedef void (*ecm_receive_fn)(void *context, const uint8_t *frame, unsigned length);
void ecm_rx_reset(struct ecm_rx *rx);
/* Supply one full-speed USB OUT packet per call (data may be null for ZLP).
 * Call reset on bus reset or endpoint reconfiguration. The callback consumes
 * the frame synchronously before the next packet can overwrite it. */
void ecm_rx_packet(struct ecm_rx *rx, const struct ecm_state *state,
                   const uint8_t *data, unsigned length,
                   ecm_receive_fn receive, void *context);

/* The caller uses the negotiated endpoint packet size and resets the
 * receive state before changing speed or reconfiguring the endpoint. */
void ecm_rx_packet_at_speed(struct ecm_rx *rx, const struct ecm_state *state,
                            unsigned bulk_packet_bytes, const uint8_t *data,
                            unsigned length, ecm_receive_fn receive, void *context);

/* Validate a device-to-host frame against the negotiated packet filter.
 * Individual multicast addresses require a filter list, which the current
 * descriptor does not advertise. */
int ecm_tx_allowed(const struct ecm_state *state, const uint8_t mac[6],
                   const uint8_t *frame, unsigned length);
#endif
