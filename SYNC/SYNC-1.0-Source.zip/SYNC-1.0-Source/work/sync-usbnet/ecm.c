/* SPDX-License-Identifier: GPL-3.0-or-later */
#include "ecm.h"

static int endpoint_valid(uint8_t endpoint, unsigned direction)
{
    return (endpoint & 0xf0u) == direction && (endpoint & 15u) != 0;
}

int ecm_configuration(uint8_t out[ECM_CONFIG_BYTES],
                      struct ecm_endpoints ep, uint8_t mac_string)
{
    return ecm_configuration_at_speed(out, ep, mac_string, ECM_BULK_PACKET, 0);
}

int ecm_configuration_at_speed(uint8_t out[ECM_CONFIG_BYTES],
                               struct ecm_endpoints ep, uint8_t mac_string,
                               unsigned bulk_packet_bytes, int other_speed)
{
    if (bulk_packet_bytes != ECM_BULK_PACKET && bulk_packet_bytes != ECM_BULK_HIGH_SPEED)
        return 0;
    uint8_t interval = bulk_packet_bytes == ECM_BULK_HIGH_SPEED ? 8 : 16;
    uint8_t bulk_lo = (uint8_t)bulk_packet_bytes;
    uint8_t bulk_hi = (uint8_t)(bulk_packet_bytes >> 8);
    if (!out || !mac_string || !endpoint_valid(ep.interrupt_in, 0x80) ||
        !endpoint_valid(ep.bulk_out, 0) || !endpoint_valid(ep.bulk_in, 0x80) ||
        ep.interrupt_in == ep.bulk_in)
        return 0;

    uint8_t const descriptor[] = {
        9, other_speed ? 7 : 2, ECM_CONFIG_BYTES, 0, 2, 1, 0, 0x80, 50,
        8, 11, 0, 2, 2, 6, 0, 0,
        9, 4, 0, 0, 1, 2, 6, 0, 0,
        5, 0x24, 0, 0x20, 0x01,
        5, 0x24, 6, 0, 1,
        13, 0x24, 0x0f, mac_string, 0, 0, 0, 0,
            ECM_MAX_FRAME & 255, ECM_MAX_FRAME >> 8, 0, 0, 0,
        7, 5, ep.interrupt_in, 3, ECM_SPEED_NOTIFICATION_BYTES, 0, interval,
        9, 4, 1, 0, 0, 0x0a, 0, 0, 0,
        9, 4, 1, 1, 2, 0x0a, 0, 0, 0,
        7, 5, ep.bulk_out, 2, bulk_lo, bulk_hi, 0,
        7, 5, ep.bulk_in, 2, bulk_lo, bulk_hi, 0,
    };
    _Static_assert(sizeof descriptor == ECM_CONFIG_BYTES, "ECM config length");
    for (unsigned i = 0; i < sizeof descriptor; ++i)
        out[i] = descriptor[i];
    return ECM_CONFIG_BYTES;
}

void ecm_configured(struct ecm_state *state, int configured)
{
    state->configured = configured != 0;
    state->data_alt = 0;
    state->packet_filter = 0;
}

int ecm_data_alt(struct ecm_state *state, unsigned alternate)
{
    if (!state->configured || alternate > 1)
        return 0;
    state->data_alt = (uint8_t)alternate;
    return 1;
}

int ecm_link_up(const struct ecm_state *state)
{
    return state->configured && state->data_alt;
}

int ecm_class_setup(struct ecm_state *state, const uint8_t setup[8])
{
    if (!state->configured || setup[0] != 0x21 || setup[1] != 0x43 ||
        setup[4] || setup[5] || setup[6] || setup[7])
        return 0;
    /* Store the bitmap as provided. Frame filtering is the adapter's job. */
    state->packet_filter = (uint16_t)(setup[2] | ((unsigned)setup[3] << 8));
    return 1;
}

void ecm_connection(const struct ecm_state *state,
                    uint8_t notification[ECM_NOTIFICATION_BYTES])
{
    notification[0] = 0xa1;
    notification[1] = 0; /* NETWORK_CONNECTION */
    notification[2] = (uint8_t)ecm_link_up(state);
    for (unsigned i = 3; i < ECM_NOTIFICATION_BYTES; ++i)
        notification[i] = 0; /* upper value byte, control interface 0, length 0 */
}

void ecm_connection_speed(const struct ecm_state *state, unsigned bulk_packet_bytes,
                          uint8_t notification[ECM_SPEED_NOTIFICATION_BYTES])
{
    /* The virtual Ethernet link reports the USB bulk payload ceiling in
     * bits/s, in both directions. USB wire overhead is excluded. */
    uint32_t bitrate = 0;
    if (ecm_link_up(state)) {
        if (bulk_packet_bytes == ECM_BULK_HIGH_SPEED)
            bitrate = UINT32_C(13) * ECM_BULK_HIGH_SPEED * 8 * 8000;
        else if (bulk_packet_bytes == ECM_BULK_PACKET)
            bitrate = UINT32_C(19) * ECM_BULK_PACKET * 8 * 1000;
    }

    notification[0] = 0xa1;
    notification[1] = 0x2a; /* CONNECTION_SPEED_CHANGE */
    for (unsigned i = 2; i < ECM_NOTIFICATION_BYTES; ++i)
        notification[i] = 0;
    notification[6] = 8;
    for (unsigned i = 0; i < 4; ++i) {
        uint8_t byte = (uint8_t)(bitrate >> (i * 8));
        notification[8 + i] = byte;  /* downstream */
        notification[12 + i] = byte; /* upstream */
    }
}

int ecm_frame_termination(unsigned bytes)
{
    return ecm_frame_termination_at_speed(bytes, ECM_BULK_PACKET);
}

int ecm_frame_termination_at_speed(unsigned bytes, unsigned bulk_packet_bytes)
{
    if ((bulk_packet_bytes != ECM_BULK_PACKET && bulk_packet_bytes != ECM_BULK_HIGH_SPEED) ||
        bytes < 14 || bytes > ECM_MAX_FRAME)
        return -1;
    return bytes % bulk_packet_bytes == 0;
}
