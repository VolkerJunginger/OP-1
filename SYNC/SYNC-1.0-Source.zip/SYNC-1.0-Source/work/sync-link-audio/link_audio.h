/* SPDX-License-Identifier: GPL-2.0-or-later
 * Based on Ableton Link 4.1.1 (original C++ code copyright 2025 Ableton AG, Berlin).
 */
#ifndef ESC_LINK_AUDIO_H
#define ESC_LINK_AUDIO_H

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

enum {
    LINK_AUDIO_ID_SIZE = 8,
    LINK_AUDIO_TX_MAX_PACKET = 576,
    LINK_AUDIO_RX_MAX_PACKET = 1200,
    LINK_AUDIO_MAX_CHUNKS = (LINK_AUDIO_RX_MAX_PACKET - 48) / 26,
    LINK_AUDIO_TX_MAX_SAMPLES = (LINK_AUDIO_TX_MAX_PACKET - 74) / 2,
    LINK_AUDIO_OP1_SAMPLE_RATE = 44100
};

typedef struct {
    uint64_t count;
    int64_t begin_microbeats;
    int64_t micros_per_beat;
    uint16_t frames;
} LinkAudioChunk;

typedef struct {
    uint8_t node_id[LINK_AUDIO_ID_SIZE];
    uint8_t channel_id[LINK_AUDIO_ID_SIZE];
    uint8_t session_id[LINK_AUDIO_ID_SIZE];
    uint32_t sample_rate;
    uint8_t channels;
    uint8_t chunk_count;
    LinkAudioChunk chunks[LINK_AUDIO_MAX_CHUNKS];
} LinkAudioTiming;

typedef struct {
    LinkAudioTiming timing;
    const uint8_t *pcm;
    size_t sample_count;
} LinkAudioView;

/* Returns the datagram length or 0. Inputs must not overlap the output. */
size_t link_audio_encode(uint8_t *output, size_t capacity,
                         const LinkAudioTiming *timing, const int16_t *samples,
                         size_t sample_count);

/* Returns 1 on success. The view borrows the immutable datagram for PCM. */
int link_audio_decode(LinkAudioView *view, const uint8_t *packet, size_t length);

/* Returns 1 on success. The output must not overlap the datagram. */
int link_audio_copy_pcm(const LinkAudioView *view, int16_t *output, size_t capacity);

#ifdef __cplusplus
}
#endif

#endif
