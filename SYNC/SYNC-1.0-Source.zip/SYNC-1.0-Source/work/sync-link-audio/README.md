# SYNC Link Audio v1

Der Host-Port erzeugt und liest Link-Audio-v1-PCM16-Datagramme mit einem
oder zwei Kanälen. `link_audio.c` arbeitet mit statischem Speicher oder
vom Aufrufer bereitgestellten Puffern. Der Decoder referenziert PCM-Daten
direkt im Eingabepaket. `link_audio_packetizer.c` bündelt Audio-Frames für
den Netzwerk-Worker. Der Sendecallback konsumiert das Paket synchron.
Bei Aufhebung des letzten Abonnements ruft der R246-Adapter
`link_audio_packetizer_discard` auf und stoppt die Übergabe weiterer Samples.

## Referenz und Format

`Link-4.1.1` wurde gegen den vollständigen Commit
`5ba907ae027a8c2ec8824463e37296dcefc5e9be` aufgelöst. Die zwölf im Auftrag
genannten Header wurden direkt an diesem Commit gelesen.

| Referenz | Relevanter Befund |
| --- | --- |
| `v1/Messages.hpp`, `AudioBuffer.hpp` | `chnnlsv\x01`, Nachrichtentyp 6. Der tatsächliche Nachrichtenkopf ist 20 Byte. PCM16 beginnt nach 48 Byte fester Felder plus je 26 Byte Timing pro Chunk. |
| `PCMCodec.hpp` | Signierte, interleavte PCM16-Samples in Network Byte Order. Abtastrate als uint32. OP-1-Quellen können 44.100 Hz direkt melden. |
| `Encoder.hpp`, `Resizer.hpp` | 576 Byte für das erzeugte UDP-Nutzpaket. Die Konstanten 24 und 50 budgetieren zusammen die tatsächlichen 74 Byte bei einem Chunk. Maximal 251 Mono- oder 125 Stereo-Frames bei einem Chunk. Jeder zusätzliche Chunk reduziert das PCM-Budget um 26 Byte. Der Header-Kommentar verweist zwar auf RFC 791, aber der Code zieht den IP- und UDP-Overhead nicht von 576 Byte ab. Der offizielle Decoder akzeptiert bis zu 1200 Byte. |
| `AudioBuffer.hpp`, `Resizer.hpp` | Chunks enthalten laufende uint64-Zähler, uint16-Framezahl sowie signierte 64-Bit-Microbeats und Mikrosekunden pro Beat. Tempoänderungen und Beat-Sprünge von mehr als einem Microbeat beginnen einen neuen Chunk. Format- oder Sessionwechsel senden zunächst das bisherige Paket. |
| `PeerAnnouncement.hpp`, `Channels.hpp` | Audio-Ankündigungen verknüpfen Peer, Link-Session, Peer-Info und Kanal-ID. Die Kanalliste wird nach Session gefiltert, der Versand nutzt den je Peer bekannten Audio-Endpunkt. |
| `ChannelRequests.hpp`, `SinkProcessor.hpp`, `SourceProcessor.hpp` | Der Empfänger erneuert Requests mit TTL 5 s und sendet bei Beendigung einen Stop-Request. Der Sender encodiert nur mit aktiven Empfängern. |
| `SessionController.hpp`, `BeatTimeMapping.hpp` | Die Audio-Sitzungsverwaltung hängt am Link-Controller. Zu übertragende Beats beziehen sich auf die gemeinsame Timeline. Die Umrechnung zwischen globalen und lokalen Beats benutzt den phasenkodierten Beat am Timeline-Zeitursprung. |

Der Codec erhält die Session-ID und `begin_microbeats` vom Aufrufer. Der
R246-Adapter verwendet dafür die Timeline von Link Sync. Ein künftiger
RX-Pfad muss Session-ID und Identität des abonnierten Peers vor dem Routing
prüfen. Jitter Buffer, Resampling, adaptive Sample-Clock-Korrektur und der
Gerätenachweis für das Streaming sind offen.

## Prüfung

```sh
# Unveränderten Link-Checkout mit ausgechecktem Asio-Submodul verwenden.
tests/run-upstream.sh /pfad/zu/link
```

ASan/UBSan bestanden auf dem Mac. 7 Mono- und 12 Stereo-Datagramme stimmen
bytegenau mit `Encoder` → `Resizer` → `PCMEncoder` → `audioBufferMessage`
überein. Die Tests umfassen 44,1 und 48 kHz, negative Beats, mehrere Chunks,
Tempo- und Sessionwechsel, Paketaufteilung, alle abgeschnittenen Präfixe
und eine gültige 1200-Byte-Nachricht. Die geprüften Ableton-Header wurden
unverändert von GitHub geholt. Für den lokalen Test ohne Asio-Installation
wurden ausschließlich die unbenutzten Asio-Typen vom Compiler aufgelöst.
Die Tests instanziieren keinen Asio-Transport. Live- und OP-1-Interoperabilität
bleiben offen.

Freestanding-Kompilierung mit bfin-elf-gcc 13.3.0 für BF524 erfolgreich.
Die vorbereiteten Einzelobjekte wiesen 1004 und 1172 Text-Bytes aus. OPUS
bindet benötigte Rechenhelfer aus `libgcc` beim Linken ein. Objektgrößen sind
keine Schätzung für Flashverbrauch oder Laufzeit. Hardware- und CPU-Messungen
stehen aus.

## Lizenz

C-Port und Tests sind unter GPL-2.0-or-later gekennzeichnet. Die Portierung
folgt den Formaten und der Paketierungslogik von Ableton Link 4.1.1.
Ableton Link wird unter GPL-2.0-or-later und einer proprietären Lizenz
angeboten. Die GPL-Alternative lässt sich bei einem abgeleiteten Werk unter
GPLv3 mit GPLv3-Kit-Code kombinieren. Für eine spätere Auslieferung sind die
Lizenzdateien, Copyright-Hinweise und der entsprechende Quellcode gemeinsam
mit dem endgültigen Abhängigkeitsstand zu prüfen.

[Referenz-Commit](https://github.com/Ableton/link/tree/5ba907ae027a8c2ec8824463e37296dcefc5e9be) · [Ableton-Lizenz](https://github.com/Ableton/link/blob/5ba907ae027a8c2ec8824463e37296dcefc5e9be/LICENSE.md)

## Integration in SYNC 0.3.0

`link_audio_control.c` implementiert die Kanalankündigung und die Wire-Formate
für Request, Stop, Pong und Bye. Die lwIP-Anbindung kündigt den Audio-Port über
Link Discovery an. Sie bindet Empfangsrequests an den bekannten Link-Peer,
dessen UDP-Endpunkt, den veröffentlichten Kanal und die aktuelle Session.

Der R246-Adapter kopiert Stereo-Master-Blöcke nur während eines gültigen
Abonnements in einen statischen Ring. Im Main-Pass werden Sample-Positionen
auf dieselbe Link-Timeline projiziert und PCM16-Pakete gesendet. Die
Sample-Rate ist nominell 44,1 kHz. Hardwaremessungen zu Timing, CPU und
Live-Interoperabilität sowie Audioempfang am OP-1 sind offen.
