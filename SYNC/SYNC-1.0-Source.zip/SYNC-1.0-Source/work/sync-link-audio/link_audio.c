/* SPDX-License-Identifier: GPL-2.0-or-later
 * Based on Ableton Link 4.1.1 (original C++ code copyright 2025 Ableton AG, Berlin).
 */
#include "link_audio.h"

enum {
    HEADER_SIZE = 20,
    CHUNKS_OFFSET = 40,
    CHUNK_SIZE = 26,
    PCM_DESCRIPTOR_SIZE = 8,
    FIXED_SIZE = CHUNKS_OFFSET + PCM_DESCRIPTOR_SIZE,
    AUDIO_MESSAGE = 6,
    PCM_I16 = 1
};

static const uint8_t protocol_magic[8] = {'c', 'h', 'n', 'n', 'l', 's', 'v', 1};

static void copy_id(uint8_t *output, const uint8_t *input)
{
    for (unsigned i = 0; i < LINK_AUDIO_ID_SIZE; ++i)
        output[i] = input[i];
}

static uint64_t read_be(const uint8_t *input, unsigned bytes)
{
    uint64_t value = 0;
    for (unsigned i = 0; i < bytes; ++i)
        value = (value << 8) | input[i];
    return value;
}

static void write_be(uint8_t *output, unsigned bytes, uint64_t value)
{
    while (bytes != 0) {
        output[--bytes] = (uint8_t)value;
        value >>= 8;
    }
}

static int64_t signed64(uint64_t value)
{
    if (value <= INT64_MAX)
        return (int64_t)value;
    return -1 - (int64_t)(UINT64_MAX - value);
}

size_t link_audio_encode(uint8_t *output, size_t capacity,
                         const LinkAudioTiming *timing, const int16_t *samples,
                         size_t sample_count)
{
    if (!output || !timing || (sample_count && !samples)
        || timing->channels < 1 || timing->channels > 2 || timing->sample_rate == 0
        || timing->chunk_count == 0 || timing->chunk_count > LINK_AUDIO_MAX_CHUNKS
        || sample_count > LINK_AUDIO_TX_MAX_SAMPLES)
        return 0;

    size_t length = FIXED_SIZE + CHUNK_SIZE * timing->chunk_count + 2 * sample_count;
    if (length > capacity || length > LINK_AUDIO_TX_MAX_PACKET)
        return 0;

    uint32_t frames = 0;
    for (unsigned i = 0; i < timing->chunk_count; ++i) {
        if (timing->chunks[i].micros_per_beat <= 0)
            return 0;
        frames += timing->chunks[i].frames;
    }
    if (frames * timing->channels != sample_count)
        return 0;

    copy_id(output, protocol_magic);
    write_be(output + 8, 4, UINT32_C(0x06000000)); /* type, TTL and group ID */
    copy_id(output + 12, timing->node_id);
    copy_id(output + HEADER_SIZE, timing->channel_id);
    copy_id(output + HEADER_SIZE + LINK_AUDIO_ID_SIZE, timing->session_id);
    write_be(output + 36, 4, timing->chunk_count);
    uint8_t *cursor = output + CHUNKS_OFFSET;
    for (unsigned i = 0; i < timing->chunk_count; ++i, cursor += CHUNK_SIZE) {
        const LinkAudioChunk *chunk = &timing->chunks[i];
        write_be(cursor, 8, chunk->count);
        write_be(cursor + 8, 2, chunk->frames);
        write_be(cursor + 10, 8, (uint64_t)chunk->begin_microbeats);
        write_be(cursor + 18, 8, (uint64_t)chunk->micros_per_beat);
    }
    cursor[0] = PCM_I16;
    write_be(cursor + 1, 4, timing->sample_rate);
    cursor[5] = timing->channels;
    write_be(cursor + 6, 2, sample_count * 2);
    cursor += PCM_DESCRIPTOR_SIZE;
    for (size_t i = 0; i < sample_count; ++i)
        write_be(cursor + i * 2, 2, (uint16_t)samples[i]);
    return length;
}

int link_audio_decode(LinkAudioView *view, const uint8_t *packet, size_t length)
{
    if (!view || !packet || length < FIXED_SIZE + CHUNK_SIZE
        || length > LINK_AUDIO_RX_MAX_PACKET)
        return 0;

    for (unsigned i = 0; i < sizeof(protocol_magic); ++i) {
        if (packet[i] != protocol_magic[i])
            return 0;
    }
    if (packet[8] != AUDIO_MESSAGE)
        return 0;
    uint32_t chunks = (uint32_t)read_be(packet + 36, 4);
    if (chunks == 0 || chunks > (length - FIXED_SIZE) / CHUNK_SIZE)
        return 0;

    const uint8_t *descriptor = packet + CHUNKS_OFFSET + CHUNK_SIZE * chunks;
    uint32_t rate = (uint32_t)read_be(descriptor + 1, 4);
    uint8_t channels = descriptor[5];
    uint16_t pcm_bytes = (uint16_t)read_be(descriptor + 6, 2);
    if (descriptor[0] != PCM_I16 || rate == 0 || channels < 1 || channels > 2
        || pcm_bytes != length - (size_t)(descriptor - packet) - PCM_DESCRIPTOR_SIZE)
        return 0;

    uint32_t frames = 0;
    const uint8_t *cursor = packet + CHUNKS_OFFSET;
    for (uint32_t i = 0; i < chunks; ++i, cursor += CHUNK_SIZE) {
        uint64_t tempo = read_be(cursor + 18, 8);
        if (tempo == 0 || tempo > INT64_MAX)
            return 0;
        frames += (uint16_t)read_be(cursor + 8, 2);
    }
    if (frames * channels * 2 != pcm_bytes)
        return 0;

    copy_id(view->timing.node_id, packet + 12);
    copy_id(view->timing.channel_id, packet + HEADER_SIZE);
    copy_id(view->timing.session_id, packet + HEADER_SIZE + LINK_AUDIO_ID_SIZE);
    view->timing.channels = channels;
    view->timing.sample_rate = rate;
    view->timing.chunk_count = (uint8_t)chunks;
    cursor = packet + CHUNKS_OFFSET;
    for (uint32_t i = 0; i < chunks; ++i, cursor += CHUNK_SIZE) {
        LinkAudioChunk *chunk = &view->timing.chunks[i];
        chunk->count = read_be(cursor, 8);
        chunk->frames = (uint16_t)read_be(cursor + 8, 2);
        chunk->begin_microbeats = signed64(read_be(cursor + 10, 8));
        chunk->micros_per_beat = (int64_t)read_be(cursor + 18, 8);
    }
    view->pcm = descriptor + PCM_DESCRIPTOR_SIZE;
    view->sample_count = pcm_bytes / 2;
    return 1;
}

int link_audio_copy_pcm(const LinkAudioView *view, int16_t *output, size_t capacity)
{
    if (!view || !view->pcm || (view->sample_count && !output)
        || capacity < view->sample_count)
        return 0;

    for (size_t i = 0; i < view->sample_count; ++i) {
        uint16_t sample = (uint16_t)read_be(view->pcm + 2 * i, 2);
        int32_t value = sample <= INT16_MAX ? sample : (int32_t)sample - 65536;
        output[i] = (int16_t)value;
    }
    return 1;
}
