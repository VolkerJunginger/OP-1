/* SPDX-License-Identifier: GPL-2.0-or-later
 * Wire format from Ableton Link 4.1.1, Copyright Ableton AG.
 */
#include "link_audio_control.h"

enum {
    SESSION = 0x73657373, PEER_INFO = 0x5f5f7069, CHANNELS = 0x61756361,
    CHANNEL_BYES = 0x61756362, CHANNEL_ID = 0x63686964, HOST_TIME = 0x5f5f6874,
    HEADER_BYTES = 20
};

static const uint8_t magic[8] = {'c', 'h', 'n', 'n', 'l', 's', 'v', 1};

static uint8_t *put(uint8_t *dst, uint64_t value, unsigned length)
{
    for (unsigned i = length; i; --i) {
        dst[i - 1] = (uint8_t)value;
        value >>= 8;
    }
    return dst + length;
}

static uint64_t get(const uint8_t *src, unsigned length)
{
    uint64_t value = 0;
    for (unsigned i = 0; i < length; ++i)
        value = (value << 8) | src[i];
    return value;
}

void link_audio_id(uint8_t out[LINK_AUDIO_ID_SIZE], uint64_t value)
{
    (void)put(out, value, LINK_AUDIO_ID_SIZE);
}

uint64_t link_audio_channel_id(uint64_t node, unsigned channel)
{
    uint64_t master = node ^ UINT64_C(0x4f50314d61737472);
    if (!master || master > UINT64_MAX - (LINK_AUDIO_CHANNELS - 1))
        master = 1;
    return master + channel;
}

static uint8_t *header(uint8_t *out, uint8_t type, uint64_t node)
{
    for (unsigned i = 0; i < sizeof magic; ++i)
        out[i] = magic[i];
    out[8] = type;
    out[9] = type == LINK_AUDIO_STOP ? 0 : LINK_AUDIO_TTL;
    out[10] = out[11] = 0;
    return put(out + 12, node, 8);
}

static uint8_t *entry(uint8_t *out, uint32_t key, uint32_t length)
{
    return put(put(out, key, 4), length, 4);
}

static uint8_t *name(uint8_t *out, const char *label, unsigned size)
{
    out = put(out, size, 4);
    for (unsigned i = 0; i < size; ++i)
        *out++ = (uint8_t)label[i];
    return out;
}

size_t link_audio_announce(uint8_t out[LINK_AUDIO_CONTROL_CAPACITY],
                           uint64_t node, uint64_t session, unsigned channels)
{
    const char peer_name[] = "OP-1";
    static const struct { const char *label; unsigned length; } names[LINK_AUDIO_CHANNELS] = {
        {"Master", 6}, {"Synth", 5}, {"Drum", 4},
        {"Tape 1", 6}, {"Tape 2", 6}, {"Tape 3", 6}, {"Tape 4", 6}
    };
    unsigned count = 0, bytes = 4;
    for (unsigned i = 0; i < LINK_AUDIO_CHANNELS; ++i) {
        if (channels & (1u << i)) {
            ++count;
            bytes += 12 + names[i].length;
        }
    }
    uint8_t *tail = header(out, LINK_AUDIO_ANNOUNCEMENT, node);
    tail = put(entry(tail, SESSION, 8), session, 8);
    tail = name(entry(tail, PEER_INFO, 4 + sizeof peer_name - 1),
                peer_name, sizeof peer_name - 1);
    tail = put(entry(tail, CHANNELS, bytes), count, 4);
    for (unsigned i = 0; i < LINK_AUDIO_CHANNELS; ++i) {
        if (channels & (1u << i))
            tail = put(name(tail, names[i].label, names[i].length),
                       link_audio_channel_id(node, i), 8);
    }
    return (size_t)(tail - out);
}

size_t link_audio_bye(uint8_t out[LINK_AUDIO_CONTROL_CAPACITY],
                     uint64_t node, unsigned channels)
{
    unsigned count = 0;
    for (unsigned i = 0; i < LINK_AUDIO_CHANNELS; ++i)
        count += (channels >> i) & 1u;
    uint8_t *tail = header(out, LINK_AUDIO_BYE, node);
    tail = put(entry(tail, CHANNEL_BYES, 4 + 8 * count), count, 4);
    for (unsigned i = 0; i < LINK_AUDIO_CHANNELS; ++i) {
        if (channels & (1u << i))
            tail = put(tail, link_audio_channel_id(node, i), 8);
    }
    return (size_t)(tail - out);
}

size_t link_audio_control_encode(uint8_t out[LINK_AUDIO_CONTROL_CAPACITY],
                                 uint8_t type, uint64_t node, uint64_t value)
{
    uint8_t *tail = header(out, type, node);
    switch (type) {
    case LINK_AUDIO_BYE:
        tail = put(entry(tail, CHANNEL_BYES, 12), 1, 4);
        break;
    case LINK_AUDIO_REQUEST:
    case LINK_AUDIO_STOP:
        tail = entry(tail, CHANNEL_ID, 8);
        break;
    case LINK_AUDIO_PONG:
        tail = entry(tail, HOST_TIME, 8);
        break;
    default:
        return 0;
    }
    return (size_t)(put(tail, value, 8) - out);
}

bool link_audio_control_decode(struct link_audio_control *message,
                               const uint8_t *packet, size_t size)
{
    if (size < HEADER_BYTES || size > LINK_AUDIO_RX_MAX_PACKET || packet[10] || packet[11])
        return false;
    for (unsigned i = 0; i < sizeof magic; ++i)
        if (packet[i] != magic[i]) return false;

    struct link_audio_control parsed = {
        .type = packet[8], .ttl = packet[9], .node = get(packet + 12, 8)
    };
    if (!parsed.node || (parsed.type != LINK_AUDIO_ANNOUNCEMENT &&
        parsed.type != LINK_AUDIO_REQUEST && parsed.type != LINK_AUDIO_STOP))
        return false;

    size_t cursor = HEADER_BYTES;
    bool have_channel = false;
    while (cursor < size) {
        if (size - cursor < 8)
            return false;
        const uint32_t tag = (uint32_t)get(packet + cursor, 4);
        const size_t length = (size_t)get(packet + cursor + 4, 4);
        cursor += 8;
        if (length > size - cursor)
            return false;
        if (tag == HOST_TIME) {
            if (parsed.has_host_time || length != 8) return false;
            parsed.host_time = get(packet + cursor, 8);
            parsed.has_host_time = true;
        } else if (tag == CHANNEL_ID) {
            if (have_channel || length != 8) return false;
            parsed.channel = get(packet + cursor, 8);
            have_channel = true;
        }
        cursor += length;
    }
    if (parsed.type != LINK_AUDIO_ANNOUNCEMENT && (!have_channel || !parsed.channel))
        return false;
    *message = parsed;
    return true;
}
