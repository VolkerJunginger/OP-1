/* SPDX-License-Identifier: GPL-2.0-or-later
 * Based on Ableton Link 4.1.1 (original C++ code copyright 2025 Ableton AG, Berlin).
 */
#ifndef ESC_LINK_AUDIO_PACKETIZER_H
#define ESC_LINK_AUDIO_PACKETIZER_H
#include "link_audio.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef void (*LinkAudioSend)(void *context, const uint8_t *packet, size_t size);

typedef struct {
    LinkAudioTiming timing;
    uint64_t next_count;
    size_t sample_count;
    size_t sample_budget;
    int16_t samples[LINK_AUDIO_TX_MAX_SAMPLES];
    uint8_t packet[LINK_AUDIO_TX_MAX_PACKET];
    LinkAudioSend send;
    void *context;
} LinkAudioPacketizer;

void link_audio_packetizer_init(LinkAudioPacketizer *state,
                                const uint8_t node[LINK_AUDIO_ID_SIZE],
                                const uint8_t channel[LINK_AUDIO_ID_SIZE],
                                LinkAudioSend send, void *context);

/* Configure a transport's smaller datagram limit before adding samples. */
void link_audio_packetizer_limit(LinkAudioPacketizer *state, size_t packet_bytes);

/* Run on the network worker. Send synchronously consumes the provided datagram. */
int link_audio_packetizer_add(LinkAudioPacketizer *state, const int16_t *samples,
                              size_t frames, uint8_t channels, uint32_t sample_rate,
                              const uint8_t session[LINK_AUDIO_ID_SIZE],
                              int64_t begin_microbeats, int64_t micros_per_beat);

/* Stops a subscription without emitting pending samples from that subscription. */
void link_audio_packetizer_discard(LinkAudioPacketizer *state);

#ifdef __cplusplus
}
#endif

#endif
