/* SPDX-License-Identifier: GPL-2.0-or-later */
#ifndef ESC_LINK_AUDIO_CONTROL_H
#define ESC_LINK_AUDIO_CONTROL_H
#include "link_audio.h"
#include <stdbool.h>
#ifdef __cplusplus
extern "C" {
#endif

enum {
    LINK_AUDIO_ANNOUNCEMENT = 1, LINK_AUDIO_BYE = 2, LINK_AUDIO_PONG = 3,
    LINK_AUDIO_REQUEST = 4, LINK_AUDIO_STOP = 5, LINK_AUDIO_PCM = 6,
    LINK_AUDIO_CONTROL_CAPACITY = 192, LINK_AUDIO_TTL = 5
};

enum {
    LINK_AUDIO_MASTER, LINK_AUDIO_SYNTH, LINK_AUDIO_DRUM,
    LINK_AUDIO_TAPE_1, LINK_AUDIO_TAPE_2, LINK_AUDIO_TAPE_3, LINK_AUDIO_TAPE_4,
    LINK_AUDIO_CHANNELS
};
#define LINK_AUDIO_ALL ((1u << LINK_AUDIO_CHANNELS) - 1u)

struct link_audio_control {
    uint64_t node, channel, host_time;
    uint8_t type, ttl;
    bool has_host_time;
};

void link_audio_id(uint8_t out[LINK_AUDIO_ID_SIZE], uint64_t value);
uint64_t link_audio_channel_id(uint64_t node, unsigned channel);
size_t link_audio_announce(uint8_t out[LINK_AUDIO_CONTROL_CAPACITY],
                           uint64_t node, uint64_t session, unsigned channels);
size_t link_audio_bye(uint8_t out[LINK_AUDIO_CONTROL_CAPACITY],
                     uint64_t node, unsigned channels);
size_t link_audio_control_encode(uint8_t out[LINK_AUDIO_CONTROL_CAPACITY],
                                 uint8_t type, uint64_t node, uint64_t value);
bool link_audio_control_decode(struct link_audio_control *message,
                               const uint8_t *packet, size_t size);
#ifdef __cplusplus
}
#endif
#endif
