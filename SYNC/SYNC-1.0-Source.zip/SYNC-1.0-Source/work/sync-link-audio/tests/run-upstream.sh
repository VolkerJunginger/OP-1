#!/bin/sh
set -eu
reference=${1:?Pass path to an Ableton Link 4.1.1 checkout}
here=$(CDPATH='' cd -- "$(dirname -- "$0")" && pwd)
output=$(mktemp -d)
trap 'rm -rf "$output"' EXIT
case $(uname -s) in
    Darwin) platform=LINK_PLATFORM_MACOSX ;;
    Linux) platform=LINK_PLATFORM_LINUX ;;
    *) echo "Unsupported host platform" >&2; exit 1 ;;
esac
sanitizers="-fsanitize=address,undefined -g"
"${CC:-cc}" -std=c11 -Wall -Wextra -Werror -pedantic $sanitizers \
    -c "$here/../link_audio.c" -o "$output/codec.o"
"${CC:-cc}" -std=c11 -Wall -Wextra -Werror -pedantic $sanitizers \
    -c "$here/../link_audio_packetizer.c" -o "$output/packetizer.o"
"${CC:-cc}" -std=c11 -Wall -Wextra -Werror -pedantic $sanitizers \
    -c "$here/../link_audio_control.c" -o "$output/control.o"
"${CXX:-c++}" -std=c++17 $sanitizers -D"$platform" -DASIO_STANDALONE \
    -DASIO_NO_TYPEID -Wno-multichar \
    -isystem "$reference/include" \
    -isystem "${ASIO_INCLUDE:-$reference/modules/asio-standalone/asio/include}" \
    "$here/compare_upstream.cpp" "$output/codec.o" "$output/packetizer.o" "$output/control.o" \
    -o "$output/compare"
"$output/compare"
