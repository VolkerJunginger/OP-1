/* SPDX-License-Identifier: GPL-2.0-or-later */
#include "../link_audio_packetizer.h"
#include "../link_audio_control.h"

#include <algorithm>
#include <arpa/inet.h>
#include <array>
#include <cassert>
#include <chrono>
#include <iostream>
#include <tuple>
#include <vector>
#include <ableton/link_audio/Encoder.hpp>
#include <ableton/link_audio/PeerAnnouncement.hpp>
#include <ableton/link_audio/ChannelRequests.hpp>
#include <ableton/link/PayloadEntries.hpp>

using namespace ableton;
using namespace ableton::link_audio;
using Datagram = std::vector<uint8_t>;
using Datagrams = std::vector<Datagram>;

const link::NodeId node{{0, 1, 2, 3, 4, 5, 6, 7}};
const Id channel{{7, 6, 5, 4, 3, 2, 1, 0}};
const Id session{{20, 21, 22, 23, 24, 25, 26, 27}};
const Id other_session{{30, 31, 32, 33, 34, 35, 36, 37}};

void compare_control()
{
    constexpr uint64_t nodeBytes = UINT64_C(0x0001020304050607);
    constexpr uint64_t channelBytes = UINT64_C(0x0706050403020100);
    constexpr uint64_t sessionBytes = UINT64_C(0x1415161718191a1b);
    Id master{}, synth{}, drum{};
    link_audio_id(master.data(), link_audio_channel_id(nodeBytes, LINK_AUDIO_MASTER));
    link_audio_id(synth.data(), link_audio_channel_id(nodeBytes, LINK_AUDIO_SYNTH));
    link_audio_id(drum.data(), link_audio_channel_id(nodeBytes, LINK_AUDIO_DRUM));
    Id tape[4]{};
    for (unsigned i = 0; i < 4; ++i)
        link_audio_id(tape[i].data(), link_audio_channel_id(nodeBytes, LINK_AUDIO_TAPE_1 + i));
    const auto announcement = PeerAnnouncement{node, session, PeerInfo{"OP-1"},
        ChannelAnnouncements{{ChannelAnnouncement{"Master", master},
                              ChannelAnnouncement{"Synth", synth},
                              ChannelAnnouncement{"Drum", drum},
                              ChannelAnnouncement{"Tape 1", tape[0]},
                              ChannelAnnouncement{"Tape 2", tape[1]},
                              ChannelAnnouncement{"Tape 3", tape[2]},
                              ChannelAnnouncement{"Tape 4", tape[3]}}}};
    uint8_t port[LINK_AUDIO_CONTROL_CAPACITY];
    v1::MessageBuffer upstream;
    size_t size = link_audio_announce(port, nodeBytes, sessionBytes, LINK_AUDIO_ALL);
    auto end = v1::detail::encodeMessage(node, 5, v1::kPeerAnnouncement,
                                        toPayload(announcement), upstream.begin());
    assert(Datagram(port, port + size) == Datagram(upstream.begin(), end));
    const unsigned removed = (1u << LINK_AUDIO_SYNTH) | (1u << LINK_AUDIO_DRUM);
    size = link_audio_bye(port, nodeBytes, removed);
    end = v1::detail::encodeMessage(node, 5, v1::kChannelByes,
              discovery::makePayload(ChannelByes{{ChannelBye{synth}, ChannelBye{drum}}}),
              upstream.begin());
    assert(Datagram(port, port + size) == Datagram(upstream.begin(), end));

    const auto check = [&](uint8_t type, uint8_t ttl, uint64_t value, const auto& payload) {
        const auto end = v1::detail::encodeMessage(node, ttl, type, payload, upstream.begin());
        const auto length = link_audio_control_encode(port, type, nodeBytes, value);
        assert(Datagram(port, port + length) == Datagram(upstream.begin(), end));
    };
    check(v1::kChannelRequest, 5, channelBytes, toPayload(ChannelRequest{node, channel}));
    check(v1::kStopChannelRequest, 0, channelBytes, toPayload(ChannelStopRequest{node, channel}));
    check(v1::kPong, 5, 532,
          discovery::makePayload(link::HostTime{std::chrono::microseconds{532}}));
    check(v1::kChannelByes, 5, channelBytes,
          discovery::makePayload(ChannelByes{{ChannelBye{channel}}}));
    std::cout << "PASS Link 4.1.1 announcement, start, stop, pong and bye datagrams\n";
}

struct UpstreamSender {
    Datagrams *datagrams;
    void operator()(const AudioBuffer &buffer)
    {
        v1::MessageBuffer packet;
        const auto end = v1::audioBufferMessage(node, buffer, packet.begin());
        datagrams->emplace_back(packet.begin(), end);
    }
};

void save_c(void *context, const uint8_t *data, size_t length)
{
    static_cast<Datagrams *>(context)->emplace_back(data, data + length);
}

void compare_packetizers(uint8_t channels)
{
    Datagrams upstream_datagrams;
    Datagrams c_datagrams;
    Encoder<UpstreamSender, int16_t> reference(util::injectVal(UpstreamSender{
                                                  &upstream_datagrams}), channel);
    LinkAudioPacketizer c;
    link_audio_packetizer_init(&c, node.data(), channel.data(), save_c, &c_datagrams);

    Buffer<int16_t> input(1600);
    std::array<uint16_t, 9> frames = {7, 61, 700, 6, 1, 1, 42, 100, 490};
    int64_t begin = -7500;
    for (size_t i = 0; i < frames.size(); ++i) {
        auto tempo = (i % 2 == 0) ? 500000 : 400000;
        input.mNumFrames = frames[i];
        input.mNumChannels = channels;
        input.mSampleRate = (i < 7) ? 44100 : 48000;
        input.mTempo = Tempo{std::chrono::microseconds{tempo}};
        input.mSessionId = (i < 4) ? session : other_session;
        input.mBeginBeats = Beats{begin};
        for (size_t sample = 0; sample < frames[i] * channels; ++sample) {
            int32_t value = (sample * 71 + i * 163) % 65536;
            input.mSamples[sample] = static_cast<int16_t>(value - 32768);
        }

        reference(input);
        assert(link_audio_packetizer_add(&c, input.mSamples.data(), frames[i],
                                         channels, input.mSampleRate,
                                         input.mSessionId.data(), begin, tempo));
        begin += 2345000;
    }

    assert(c_datagrams == upstream_datagrams);
    assert(c_datagrams.size() >= 7);
    bool multiple_chunks = false;
    for (const auto &datagram : upstream_datagrams) {
        LinkAudioView view;
        assert(link_audio_decode(&view, datagram.data(), datagram.size()));
        multiple_chunks |= view.timing.chunk_count > 1;
        auto [header, payload] = v1::parseMessageHeader(datagram.begin(), datagram.end());
        AudioBuffer official;
        assert(header.messageType == v1::kAudioBuffer);
        assert(AudioBuffer::fromNetworkByteStream(official, payload, datagram.end())
               == datagram.end());
        assert(view.timing.sample_rate == official.sampleRate);
        assert(view.timing.channels == official.numChannels);
        assert(view.timing.chunk_count == official.chunks.size());
        assert(std::equal(header.ident.begin(), header.ident.end(), view.timing.node_id));
        assert(std::equal(official.channelId.begin(), official.channelId.end(),
                          view.timing.channel_id));
        assert(std::equal(official.sessionId.begin(), official.sessionId.end(),
                          view.timing.session_id));

        std::array<int16_t, LINK_AUDIO_TX_MAX_SAMPLES> pcm;
        assert(link_audio_copy_pcm(&view, pcm.data(), pcm.size()));
        std::array<uint8_t, LINK_AUDIO_TX_MAX_PACKET> encoded;
        auto length = link_audio_encode(encoded.data(), encoded.size(), &view.timing,
                                        pcm.data(), view.sample_count);
        assert(!link_audio_encode(encoded.data(), datagram.size() - 1, &view.timing,
                                  pcm.data(), view.sample_count));
        assert(length == datagram.size());
        assert(std::equal(datagram.begin(), datagram.end(), encoded.begin()));

        const auto descriptor = 40 + 26 * view.timing.chunk_count;
        assert(!link_audio_copy_pcm(&view, pcm.data(), view.sample_count - 1));
        for (const auto offset : {0, 8, 36, 58, descriptor, descriptor + 5,
                                  descriptor + 6}) {
            auto damaged = datagram;
            damaged[offset] = 0xff;
            assert(!link_audio_decode(&view, damaged.data(), damaged.size()));
        }

        for (size_t prefix = 0; prefix < datagram.size(); ++prefix)
            assert(!link_audio_decode(&view, datagram.data(), prefix));
    }
    assert(multiple_chunks);
    std::cout << unsigned(channels) << " channel: " << c_datagrams.size()
              << " exact upstream datagrams, round trips and truncated prefixes passed\n";
}

void compare_receive_limit()
{
    AudioBuffer buffer;
    buffer.channelId = channel;
    buffer.sessionId = session;
    buffer.sampleRate = 44100;
    buffer.codec = Codec::kPCM_i16;
    buffer.chunks = {{1, 563, Beats{int64_t{-5}}, Tempo{120.0}}};
    buffer.numChannels = 1;
    buffer.numBytes = 1126;
    buffer.bytes.fill(0x80);
    v1::MessageBuffer reference;
    auto end = v1::audioBufferMessage(node, buffer, reference.begin());
    assert(end == reference.end());
    LinkAudioView view;
    assert(link_audio_decode(&view, reference.data(), reference.size()));
    assert(view.sample_count == 563);
    assert(view.pcm[1125] == 0x80);
    reference[36] = 255;
    assert(!link_audio_decode(&view, reference.data(), reference.size()));
    std::cout << "1200-byte official receive boundary and invalid chunk count passed\n";
}

void test_high_speed_usb_packet_budget(uint8_t channels)
{
    Datagrams datagrams;
    LinkAudioPacketizer packetizer;
    int16_t pcm[64 * 2] = {};
    link_audio_packetizer_init(&packetizer, node.data(), channel.data(), save_c, &datagrams);
    link_audio_packetizer_limit(&packetizer, 512 - 42 - 1);
    for (int64_t frame = 0; frame + 64 <= 44100; frame += 64) {
        int64_t beat = (frame * 2000000 + 22050) / 44100;
        assert(link_audio_packetizer_add(&packetizer, pcm, 64, channels, 44100,
                                         session.data(), beat, 500000));
    }
    size_t frames = 0;
    uint64_t last_chunk = 0;
    for (const auto& datagram : datagrams) {
        LinkAudioView view;
        assert(datagram.size() + 42 < 512);
        assert(link_audio_decode(&view, datagram.data(), datagram.size()));
        for (unsigned i = 0; i < view.timing.chunk_count; ++i)
            assert(view.timing.chunks[i].count == ++last_chunk);
        frames += view.sample_count / channels;
    }
    const size_t ideal = (44100 / 64 * 64) / (395 / (sizeof(int16_t) * channels));
    std::cout << "USB " << unsigned(channels) << "-channel packet count " << datagrams.size() << " (single-chunk minimum "
              << ideal << ")\n" << std::flush;
    assert(datagrams.size() >= ideal && datagrams.size() <= ideal + 12);
    assert(frames + packetizer.sample_count / channels == 44100 / 64 * 64);
    std::cout << "PASS one second of 44.1 kHz PCM in short USB HS transactions\n";
}

int main()
{
    compare_control();
    compare_packetizers(1);
    compare_packetizers(2);
    compare_receive_limit();
    test_high_speed_usb_packet_budget(1);
    test_high_speed_usb_packet_budget(2);
}
