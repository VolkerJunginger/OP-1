/* SYNC Pulse development build, based on Pulse Sync 1.1.11, GPL-3.0-or-later. R246 only; see FIRMWARE.md. */
#include "opus_plugin.h"
#include "op1fw.h"
#include "pulse_core.h"
#include "pulse_route.h"
#include <stdbool.h>
#ifdef PULSE_HOST_TEST
extern volatile unsigned test_ring[1024], test_wr, test_rd, test_mode, test_input_mode, test_rx_phase, test_follow, test_fallback, test_com, test_input_source, test_edit_mode;
#define RING test_ring
#define WR test_wr
#define RD test_rd
#define MODE test_mode
#define INPUT_SOURCE test_input_source
#define EDIT_MODE test_edit_mode
static unsigned test_cycles;
static unsigned cycles(void) { return test_cycles; }
static unsigned irq_off(void) { return 0; }
static void irq_restore(unsigned mask) { (void)mask; }
static void publish(void) { }
#else
#define RING ((volatile unsigned *)0x01ab0510u)
#define WR (*(volatile unsigned *)0x01ab1510u)
#define RD (*(volatile unsigned *)0x01ab1514u)
#define MODE (*(volatile const unsigned *)0x018c1870u)
#define INPUT_SOURCE (*(volatile const unsigned *)0xff8010b4u)
#define EDIT_MODE (*(volatile const unsigned *)0xff907d58u)
static unsigned cycles(void) { unsigned n; __asm__ volatile("%0 = CYCLES;" : "=d"(n)); return n; }
static unsigned irq_off(void) { unsigned n; __asm__ volatile("cli %0;" : "=d"(n) : : "memory"); return n; }
static void irq_restore(unsigned n) { __asm__ volatile("sti %0;" : : "d"(n) : "memory"); }
static void publish(void) { __asm__ volatile("ssync;" : : : "memory"); }
#endif
static struct opl_self *me;
/* A single packed word is published by the key thread. */
static volatile unsigned config;
const struct esc_pulse_route_info esc_pulse_route_descriptor __attribute__((used))={
 "esc.pulse.route",1,sizeof(struct esc_pulse_route_info),esc_pulsesync_input_mask,0x45534331u
};
#if __SIZEOF_POINTER__ == 4
_Static_assert(sizeof(struct esc_pulse_route_info)==32,"Pulse route ABI1 must be32 bytes");
#endif

static volatile unsigned detected, input_peak, input_blocks, sent, dropped;
static unsigned consumed;
static volatile unsigned sequence_blocks;

#define SYNC_INPUT_SHIFT 24u
enum { SYNC_BOTH, SYNC_LEFT, SYNC_RIGHT };
#define RATE_SHIFT 19u
#define DETECTOR_CONFIG 0x033bffffu /* Threshold, enable, polarity, rate and input selection. */
#define AUTOSTART (1u << 22)
#define PULSE_PRIORITY (1u << 23)
#define RATE_MASK 7u
#define PULSE_MODE (1u << 16)
#ifdef SYNC_LINK_DEVICE
int sync_device_init(struct opl_self *self);
void sync_device_setting(void);
unsigned sync_network_requested(void);
#ifndef PULSE_HOST_TEST
void sync_device_sequence_tick(void);
#endif
enum { CLOCK_OFF, CLOCK_MIDI, CLOCK_LINK, CLOCK_PULSE };
#define LINK_MODE (1u << 26)
#define MIDI_MODE (1u << 27)
static volatile unsigned clock_rearm, pulse_needs_mode, link_activation;
#ifdef PULSE_HOST_TEST
static unsigned test_screen;
#define ACTIVE_SCREEN test_screen
static void native_external_sync(void) { test_mode = 2; }
static unsigned test_history_resets;
static void native_clock_reset(void) { test_rx_phase = 0; ++test_history_resets; }
#define NATIVE_COM test_com
#else
#define ACTIVE_SCREEN (*(volatile const unsigned *)0x018b65c8u)
#define NATIVE_COM (*(volatile const unsigned char *)0x018b6074u)
static void native_external_sync(void)
{
    ((void (*)(unsigned))0x01a5ea68u)(2);
}

static void native_clock_reset(void)
{
    /* Reset the verified R246 timestamp history and quarter-note divider.
     * The current F8 then initializes both through the normal parser. */
    ((void (*)(void))0x019de510u)();
    *(volatile unsigned *)0x018b6010u = 0;
}
#endif
#define LINK_TAG 0x4c4b0000u
#define USB_CLOCK_TAG 0x55420000u
static volatile unsigned link_beat_period;
static unsigned link_beat_timestamp;
static unsigned link_beat_initialized;

void sync_link_tempo_period(unsigned period) { link_beat_period = period; }

/* The R246 estimator runs once per quarter note. Give it the Link period,
 * anchored to the stock timer, instead of the time a queued tick was drained. */
static unsigned tempo_timestamp(unsigned now, unsigned period, unsigned *timestamp, unsigned *initialized)
{
    if (!period) {
        *initialized = 0;
        return 0;
    }
    unsigned next = *timestamp + period;
    unsigned distance = now - next;
    unsigned difference = distance > 0x7fffffffu ? 0u - distance : distance;
    if (!*initialized || difference > period / 2)
        next = now;
    *initialized = 1;
    *timestamp = next ? next : 1;
    return *timestamp;
}

static unsigned link_tempo_timestamp(unsigned now, unsigned period)
{
    return tempo_timestamp(now, period, &link_beat_timestamp, &link_beat_initialized);
}

#ifndef PULSE_HOST_TEST
static unsigned tempo_now(void)
{
    return ((unsigned (*)(void))0x01a0dce4u)() * 1000u;
}
unsigned sync_link_tempo_timestamp(void)
{
    return link_tempo_timestamp(tempo_now(), link_beat_period);
}
#endif
#endif
#define MIDI_TAG 0x50530000u

static unsigned pulse_channels(unsigned cfg)
{
    unsigned selection = (cfg >> SYNC_INPUT_SHIFT) & 3u;
    return selection == SYNC_LEFT ? 1u : selection == SYNC_RIGHT ? 2u : 3u;
}

static unsigned pulse_input_active(unsigned cfg)
{
#ifdef SYNC_LINK_DEVICE
    /* LINE can supply edges before the native tempo mode is armed. */
    return (cfg & PULSE_MODE) && !NATIVE_COM;
#else
    unsigned mode = MODE;
    return (cfg & PULSE_MODE) && (mode == 2 || mode == 4);
#endif
}

unsigned esc_pulsesync_input_mask(void)
{
    unsigned cfg = config;
    return pulse_input_active(cfg) ? pulse_channels(cfg) : 0;
}

/* Shift + Mic opens the stock Input screen, even while monitoring is off. */
static void draw_sync_notice(unsigned short *buf)
{
    (void)buf;
    unsigned cfg = config;
    if ((cfg & PULSE_MODE) && EDIT_MODE == 5 && INPUT_SOURCE == 1) {
        static const char *const labels[] = {"", "sync l", "sync r", "sync l+r"};
        opus_page_text_right(me, 0, 85, 118, 9, OPUS_COLOR_E1, labels[pulse_channels(cfg)]);
    }
#ifdef SYNC_LINK_DEVICE
    if (EDIT_MODE == 4 && ACTIVE_SCREEN == 0x22 && (MODE == 2 || MODE == 4)) {
        const char *source = cfg & MIDI_MODE ? "midi" :
                             cfg & PULSE_MODE ? "pulse" :
                             cfg & LINK_MODE ? "link" : 0;
        if (source)
            opus_page_text_centre(me, 1, 145, 93, 10, OPUS_COLOR_TEXT, source);
    }
#endif
}
#define USB_TIMEOUT 200000000u
#define MIN_PULSE_TIMEOUT 40000000u
#define FIRST_PULSE_TIMEOUT 1600000000u

#define MAX_CLOCK_INTERVAL 1600000000u /* Four seconds at 400 MHz. */

enum { PPQ24, PPQ48, PPQ96, CLOCK_QUARTER, CLOCK_EIGHTH, CLOCK_SIXTEENTH, CLOCK_THIRTYSECOND };
static const unsigned ticks_per_pulse[] = {24, 12, 6, 3};
static unsigned clock_rate, divider_phase, last_edge, interval, subdivision, next_tick;
static unsigned have_edge;

enum clock_source { SOURCE_NONE, SOURCE_USB, SOURCE_PULSE };
static volatile unsigned selected_source;
#ifndef SYNC_LINK_DEVICE
static unsigned usb_seen, usb_last;
#endif
static unsigned pulse_seen, pulse_last, pulse_period;
static unsigned transport_running;
static const unsigned threshold_levels[] = {
    64, 128, 256, 512, 1024, 2048, 4096, 8192, 12000, 16000
};

static unsigned pulse_timeout(void)
{
    if (!pulse_period) return FIRST_PULSE_TIMEOUT;
    unsigned timeout = pulse_period < MAX_CLOCK_INTERVAL / 2u
        ? pulse_period * 2u : MAX_CLOCK_INTERVAL;
    return timeout < MIN_PULSE_TIMEOUT ? MIN_PULSE_TIMEOUT : timeout;
}

static unsigned choose_source(unsigned cfg, unsigned now)
{
    unsigned pulse_active = pulse_seen && now - pulse_last <= pulse_timeout();
#ifndef SYNC_LINK_DEVICE
    unsigned usb_active = usb_seen && now - usb_last <= USB_TIMEOUT;
    if (cfg & PULSE_PRIORITY) {
        if (pulse_active) return SOURCE_PULSE;
        if (usb_active) return SOURCE_USB;
    } else {
        if (usb_active) return SOURCE_USB;
        if (pulse_active) return SOURCE_PULSE;
    }
#else
    (void)cfg;
    if (pulse_active) return SOURCE_PULSE;
#endif
    return SOURCE_NONE;
}

/* Sequencer parser only: refreshed for each realtime packet before dispatch. */
volatile unsigned pulse_use_current_time;

/* Called by the two verified stock realtime-message sync-mode queries.
 * Injected messages use the otherwise unused realtime padding bytes as a tag.
 * Stock R246 reads only the status byte in this branch. */
int clock_sync_mode(const unsigned *packet)
{
    unsigned start = cycles();
    unsigned cfg = config;
    int result = (int)MODE;
    unsigned status = (*packet >> 8) & 255u;
    unsigned tagged = (*packet & 0xffff0000u) == MIDI_TAG;
#ifdef SYNC_LINK_DEVICE
    unsigned link_tagged = (*packet & 0xffff0000u) == LINK_TAG;
    unsigned usb_clock_tagged = (*packet & 0xffff0000u) == USB_CLOCK_TAG;
    if (status == 0xf8u || status == 0xfau || status == 0xfbu || status == 0xfcu) {
        bool allowed = (cfg & LINK_MODE) ? link_tagged :
                       (cfg & PULSE_MODE) ? tagged :
                       (cfg & MIDI_MODE) && !link_tagged && !tagged;
        if (!allowed) {
            result = 0;
        } else if (!NATIVE_COM &&
                   (clock_rearm || ((cfg & MIDI_MODE) && status == 0xf8u &&
                                    result != 2 && result != 4))) {
            if (result != 2 && result != 4) {
                native_external_sync();
                result = (int)MODE;
                clock_rearm = 1;
            }
            if (status == 0xf8u && (result == 2 || result == 4)) {
                native_clock_reset();
                link_beat_initialized = 0;
                clock_rearm = 0;
            }
        }
    }
    /* Composite USB Clock uses the firmware's local timestamp path. */
    tagged |= link_tagged | usb_clock_tagged;
#else
    if (cfg & (1u << 16)) {
        if (!tagged && status == 0xf8u) {
            usb_seen = 1;
            usb_last = cycles();
        }
        unsigned source = choose_source(cfg, cycles());
        if (tagged && source == SOURCE_USB) result = 0;
        if (!tagged && source == SOURCE_PULSE &&
            (status == 0xf8u || status == 0xfau || status == 0xfbu || status == 0xfcu))
            result = 0;
    }
#endif
    pulse_use_current_time = tagged && status == 0xf8u &&
                             (result == 2 || result == 4);
#ifdef SYNC_LINK_DEVICE
    if (pulse_use_current_time && link_tagged)
        pulse_use_current_time = 2;
#endif
    opus_cpu_charge(me, cycles() - start);
    return result;
}

static int queue_tagged(unsigned status, unsigned tag)
{
    unsigned mask = irq_off();
    unsigned wr = WR, rd = RD;
    int ok = pulse_ring_room(wr, rd);
    if (ok) {
        RING[wr & 1023u] = tag | (status << 8) | 0x0fu;
        publish();
        WR = wr + 1u;
        publish();
    }
    irq_restore(mask);
    if (!ok) ++dropped;
    return ok;
}

static int queue_message(unsigned status)
{
    return queue_tagged(status, MIDI_TAG);
}

#ifdef SYNC_LINK_DEVICE
unsigned sync_link_requested(void) { return config & LINK_MODE; }
unsigned sync_midi_requested(void) { return config & MIDI_MODE; }
unsigned sync_pulse_requested(void) { return config & PULSE_MODE; }
unsigned sync_link_activation(void) { return link_activation; }

void sync_usb_midi_realtime(unsigned status)
{
    if (sync_midi_requested())
        (void)queue_tagged(status, USB_CLOCK_TAG);
}

void sync_link_transport(unsigned status)
{
    if (sync_link_requested())
        (void)queue_tagged(status, LINK_TAG);
}

void sync_link_clock_tick(void) { sync_link_transport(0xf8u); }
#endif

#ifndef SYNC_LINK_DEVICE
/* Observe external USB packets without consuming or editing their queue slots. */
static void observe_usb(unsigned now)
{
    unsigned mask = irq_off();
    unsigned rd = RD, count = WR - rd;
    if (count <= 1023u) {
        for (unsigned i = 0; i < count; ++i) {
            unsigned packet = RING[(rd + i) & 1023u];
            if ((packet & 0xffff0000u) != MIDI_TAG &&
                (packet & 0xff0fu) == 0xf80fu) {
                usb_seen = 1;
                usb_last = now;
                break;
            }
        }
    }
    irq_restore(mask);
}

#endif

static void reset_conversion(void)
{
    divider_phase = have_edge = interval = subdivision = next_tick = 0;
}

/* Schedule interior ticks from the last measured interval. The next real
 * edge replaces the predicted boundary, and silence cannot free-run. */
static unsigned convert_pulses(unsigned rate, unsigned count, unsigned now)
{
    if (rate <= PPQ96) {
        unsigned mask = (1u << rate) - 1u;
        unsigned ticks = 0;
        while (count--) {
            if (!divider_phase) ++ticks;
            divider_phase = (divider_phase + 1u) & mask;
        }
        return ticks;
    }

    unsigned elapsed = now - last_edge;
    if (have_edge && (elapsed > MAX_CLOCK_INTERVAL || (interval && elapsed > 2u * interval)))
        reset_conversion();

    if (count) {
        unsigned divisions = ticks_per_pulse[rate - CLOCK_QUARTER];
        unsigned valid = have_edge && count == 1 && elapsed >= divisions;
        last_edge = now;
        have_edge = count == 1;
        interval = valid ? elapsed : 0;
        subdivision = valid ? elapsed / divisions : 0;
        next_tick = subdivision;
        return valid;
    }

    if (!subdivision || elapsed >= interval || elapsed < next_tick)
        return 0;

    /* A delayed callback may miss ticks. Never replay them as a burst. */
    do {
        next_tick += subdivision;
    } while (next_tick <= elapsed);
    if (next_tick >= subdivision * ticks_per_pulse[rate - CLOCK_QUARTER])
        subdivision = 0;
    return 1;
}
static void settings(const char *name, int value)
{
    unsigned level = (unsigned)opus_setting(me, "threshold");
    if (level < 1 || level > 10) level = 5;
    unsigned threshold = threshold_levels[level - 1];
#ifdef SYNC_LINK_DEVICE
    int source = opus_setting(me, "clock");
    unsigned enabled = source == CLOCK_PULSE;
    unsigned link = source == CLOCK_LINK;
    unsigned midi = source == CLOCK_MIDI;
    unsigned entering_pulse = enabled && !(config & PULSE_MODE);
    if ((midi && !sync_midi_requested()) || (link && !sync_link_requested()) || entering_pulse)
        clock_rearm = 1;
    if (!enabled || entering_pulse)
        pulse_needs_mode = entering_pulse;
    if (link && !sync_link_requested())
        ++link_activation;
#else
    unsigned enabled = (unsigned)opus_setting(me, "enabled");
#endif
    unsigned negative = (unsigned)opus_setting(me, "polarity");
    unsigned sync_input = (unsigned)opus_setting(me, "sync_input");
    unsigned rate = (unsigned)opus_setting(me, "input_rate");
    if (rate > CLOCK_THIRTYSECOND) rate = PPQ24;
    unsigned automatic = (unsigned)opus_setting(me, "autostart");
#ifndef SYNC_LINK_DEVICE
    unsigned priority = (unsigned)opus_setting(me, "priority");
#else
    unsigned priority = 0;
#endif
    (void)name; (void)value;
    if (sync_input > SYNC_RIGHT) sync_input = SYNC_BOTH;
    config = threshold | (enabled << 16) | (negative << 17) | (sync_input << SYNC_INPUT_SHIFT) | (rate << RATE_SHIFT) | (automatic << 22) | (priority << 23)
#ifdef SYNC_LINK_DEVICE
             | (link ? LINK_MODE : 0) | (midi ? MIDI_MODE : 0)
#endif
             ;
#ifdef SYNC_LINK_DEVICE
    sync_device_setting();
#endif
}
/* The kit generates the checked trampoline for this name. */
/* Opus supplies 64 writable interleaved stereo frames.
 * Edits feed the stock monitor and capture paths for this block. */
static struct pulse_detector stereo_edges[2];
static unsigned channel_age[2];
static unsigned stereo_config;


static void route_line_input(int *input, unsigned frames)
{
    unsigned cfg = config;
    if (!input || frames != 64 || !pulse_input_active(cfg)) {
        stereo_config = 0;
        return;
    }

    unsigned rate = (cfg >> RATE_SHIFT) & RATE_MASK;
    unsigned blank = rate <= PPQ96 ? 88u >> rate : 88u;
    unsigned threshold = cfg & 65535u;
    unsigned negative = (cfg >> 17) & 1u;
    if (stereo_config != (cfg & DETECTOR_CONFIG)) {
        for (unsigned ch = 0; ch < 2; ++ch) {
            pulse_reset(&stereo_edges[ch]);
            channel_age[ch] = 0;
        }
        stereo_config = cfg & DETECTOR_CONFIG;
    }

    unsigned selected_channels = pulse_channels(cfg);
    unsigned edges[2] = {0, 0}, peak = 0;
    for (unsigned i = 0; i < 64; ++i) {
        for (unsigned ch = 0; ch < 2; ++ch) {
            if (!(selected_channels & (1u << ch))) continue;
            int sample = input[2*i + ch] >> 16;
            unsigned level = (unsigned)(sample < 0 ? -sample : sample);
            if (level > peak) peak = level;
            edges[ch] += pulse_sample(&stereo_edges[ch], sample, threshold, negative, blank);
        }
    }

    for (unsigned ch = 0; ch < 2; ++ch) {
        if (edges[ch]) {
            channel_age[ch] = 2757; /* Four seconds at 44.1 kHz, 64 frames/block. */
        } else if (channel_age[ch]) {
            --channel_age[ch];
        }
    }

    unsigned channels = (channel_age[0] != 0) | ((channel_age[1] != 0) << 1);
    input_peak = peak;
    ++input_blocks;
    /* Use a single clock when both sides carry edges, to avoid duplicate ticks. */
    detected += channels & 1u ? edges[0] : edges[1];

    for (unsigned i = 0; i < frames; ++i) {
        if (selected_channels & 1u) input[2*i] = 0;
        if (selected_channels & 2u) input[2*i+1] = 0;
    }
}
/* Sequencer thread, before the normal stock MIDI drain. */
static void block(void)
{
    unsigned pulse_count = detected;
    unsigned count = pulse_count - consumed;
    unsigned now = cycles();
    unsigned cfg = config;
#if defined(SYNC_LINK_DEVICE) && !defined(PULSE_HOST_TEST)
    sync_device_sequence_tick();
#endif
    unsigned rate = (cfg >> RATE_SHIFT) & RATE_MASK;
    ++sequence_blocks;
    consumed = pulse_count;

#ifdef SYNC_LINK_DEVICE
    if (pulse_input_active(cfg) &&
        (pulse_needs_mode || (count && count <= 4 && MODE != 2 && MODE != 4))) {
        /* A real edge also reacquires Sync after a late stock mode change. */
        pulse_needs_mode = 0;
        if (MODE != 2 && MODE != 4) {
            native_external_sync();
            clock_rearm = 1;
        }
        reset_conversion();
        pulse_seen = transport_running = 0;
        selected_source = SOURCE_NONE;
    }
#endif
    if (!pulse_input_active(cfg) || (MODE != 2 && MODE != 4)) {
        reset_conversion();
        pulse_seen = transport_running = 0;
#ifndef SYNC_LINK_DEVICE
        usb_seen = 0;
#endif
        selected_source = SOURCE_NONE;
        clock_rate = rate;
        return;
    }
    if (rate != clock_rate) {
        reset_conversion();
        pulse_seen = 0;
        pulse_period = 0;
        clock_rate = rate;
        count = 0;
    }
    if (count > 4) {
        dropped += count;
        reset_conversion();
        count = 0;
    }

    unsigned was_active = pulse_seen && now - pulse_last <= pulse_timeout();
    if (count) {
        unsigned elapsed = now - pulse_last;
        if (was_active && elapsed && elapsed <= MAX_CLOCK_INTERVAL)
            pulse_period = elapsed / count;
        else
            pulse_period = 0;
        pulse_last = now;
        pulse_seen = 1;
    }
#ifndef SYNC_LINK_DEVICE
    observe_usb(now);
#endif
    unsigned source = choose_source(cfg, now);
    if (source != selected_source) reset_conversion();
    selected_source = source;

    if (!(cfg & AUTOSTART)) transport_running = 0;
#ifndef SYNC_LINK_DEVICE
    if (source == SOURCE_USB) {
        transport_running = 0; /* The USB transport now owns playback. */
        reset_conversion();
        return;
    }
#endif
    if (source == SOURCE_NONE) {
        if (transport_running && queue_message(0xfcu)) transport_running = 0;
        reset_conversion();
        return;
    }
    if (count && !was_active) reset_conversion();
    if ((cfg & AUTOSTART) && count && !transport_running) {
        if (!queue_message(0xfau)) return;
        transport_running = 1;
    }
    unsigned ticks = convert_pulses(rate, count, now);
    for (unsigned i = 0; i < ticks; ++i) {
        if (queue_message(0xf8u)) ++sent;
    }
}
static int firmware_ok(void)
{
#ifndef PULSE_HOST_TEST
    static const unsigned char parser[] = {0x00,0xe8,0x06,0x00,0xe3,0x05,0xa6,0x6f,0x08,0xe1,0x10,0x05,0x48,0xe1,0xab,0x01};
    static const unsigned char tick[] = {0x20,0xe4,0x19,0x00,0x20,0x64,0x20,0xe6,0x19,0x00,0x60,0xa0,0x00,0x0c,0x09,0x18};
    volatile const unsigned char *p = (volatile const unsigned char *)0x019e31a4u;
    volatile const unsigned char *t = (volatile const unsigned char *)0x019e3988u;
    for (unsigned i = 0; i < sizeof parser; ++i) if (p[i] != parser[i]) return 0;
    for (unsigned i = 0; i < sizeof tick; ++i) if (t[i] != tick[i]) return 0;
#ifdef SYNC_LINK_DEVICE
    static const unsigned char tempo_setter[] = {0x00,0xe8,0x00,0x00,0xf5,0x05,0xa6,0x6f,
                                           0x38,0x30,0x0d,0xe1,0x70,0x18,0x4d,0xe1,0x8c,0x01,0x2f,0x92};
    static const unsigned char history_reset[] = {0x09,0xe1,0xdc,0x7c,0x49,0xe1,0x90,0xff,
                                             0xf8,0x63,0x08,0x93,0x10,0x00};
    static const unsigned char parser_state[] = {0x0c,0xe1,0x0c,0x60,0x4c,0xe1,0x8b,0x01};
    const volatile unsigned char *setter = (const volatile unsigned char *)0x01a5ea68u;
    const volatile unsigned char *history = (const volatile unsigned char *)0x019de510u;
    const volatile unsigned char *state = (const volatile unsigned char *)0x019e31feu;
    for (unsigned i = 0; i < sizeof tempo_setter; ++i) if (setter[i] != tempo_setter[i]) return 0;
    for (unsigned i = 0; i < sizeof history_reset; ++i) if (history[i] != history_reset[i]) return 0;
    for (unsigned i = 0; i < sizeof parser_state; ++i) if (state[i] != parser_state[i]) return 0;
#endif
#endif
    return 1;
}
int opl_init(struct opl_self *self)
{
    if (!firmware_ok()) return -246;
    me = self;
    settings(0, 0);
    clock_rate = (config >> RATE_SHIFT) & RATE_MASK;
#ifdef SYNC_LINK_DEVICE
    if (sync_device_init(self) != 0) return -247;
#endif
    opus_on_setting(self, settings);
    opus_on_block(self, block);
    opus_on_line_input(self, route_line_input);
    opus_on_frame(self, draw_sync_notice);
    return 0;
}
