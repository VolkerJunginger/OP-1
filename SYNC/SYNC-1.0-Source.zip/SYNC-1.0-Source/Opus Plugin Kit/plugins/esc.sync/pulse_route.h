#ifndef ESC_PULSE_ROUTE_H
#define ESC_PULSE_ROUTE_H
/* Optional protocol embedded in this plugin image. No external module/import.
 * Consumers locate only this record in our loaded, immutable image using the
 * documented Core plugin statistics. ABI1 Blackfin layout is exactly32 bytes. */
struct esc_pulse_route_info {
 char tag[16];unsigned abi,bytes;
 unsigned (*mask)(void);
 unsigned trailer;
};
unsigned esc_pulsesync_input_mask(void);
#endif
