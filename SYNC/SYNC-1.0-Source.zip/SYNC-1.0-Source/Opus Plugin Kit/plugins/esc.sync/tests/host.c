/* Host simulations: these do not emulate the OP-1 firmware or USB interrupt. */
#include <assert.h>
#include <limits.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#define PULSE_HOST_TEST
#define SYNC_LINK_DEVICE
#include "../pulsesync.c"
static short test_input[64];
volatile unsigned test_ring[1024], test_wr, test_rd, test_mode, test_input_mode, test_rx_phase, test_follow, test_fallback, test_com, test_input_source, test_edit_mode;
static int clock;
int sync_device_init(struct opl_self *self) { (void)self; return 0; }
void sync_device_setting(void) {}
static int threshold = 5, polarity, sync_input=SYNC_BOTH, input_rate, autostart;
static void (*block_cb)(void);
static void (*line_cb)(int *, unsigned);
static void (*frame_cb)(unsigned short *);
static const char *pulse_notice;
static const char *tempo_notice;
void opus_on_line_input(struct opl_self *s, void (*f)(int *,unsigned)) { (void)s;line_cb=f; }
void opus_on_frame(struct opl_self *s, void (*f)(unsigned short *)) { (void)s;frame_cb=f; }
void opus_page_text_right(struct opl_self *s, int slot, int x, int y, int size, int colour, const char *label)
{
    (void)s;
    assert(slot == 0 && x == 85 && y == 118 && size == 9 && colour == OPUS_COLOR_E1);
    pulse_notice = label;
}
void opus_page_text_centre(struct opl_self *s, int slot, int x, int y, int size, int colour, const char *label)
{
    (void)s;
    assert(slot == 1 && x == 145 && y == 93 && size == 10 && colour == OPUS_COLOR_TEXT);
    tempo_notice = label;
}
int opus_setting(struct opl_self *s, const char *n) {
    (void)s;
    if (!strcmp(n, "clock")) return clock;
    if (!strcmp(n, "input_rate")) return input_rate;
    if (!strcmp(n, "autostart")) return autostart;
    return !strcmp(n,"threshold") ? threshold : !strcmp(n,"polarity") ? polarity : sync_input;
}
void opus_on_setting(struct opl_self *s, void (*f)(const char *,int)) { (void)s; (void)f; }
void opus_on_block(struct opl_self *s, void (*f)(void)) { (void)s; block_cb=f; }
void opus_on_panel(struct opl_self *s, void (*f)(void)) { (void)s; (void)f; }
void opus_cpu_charge(struct opl_self *s, unsigned n) { (void)s; (void)n; }
void opus_panel_text(struct opl_self *s,int slot,int x,int y,int size,int colour,const char *t) {
    (void)s;(void)slot;(void)x;(void)y;(void)size;(void)colour;(void)t;
}
int fw_snprintf(char *b, unsigned n, const char *f, ...) { va_list a; va_start(a,f);int r=vsnprintf(b,n,f,a);va_end(a);return r; }
static void reset(void) {
    memset((void *)test_input,0,sizeof test_input);memset((void *)test_ring,0,sizeof test_ring);
    test_wr=test_rd=0;test_mode=2;test_input_mode=0;test_input_source=1;test_edit_mode=0;test_rx_phase=test_follow=test_com=0;test_fallback=1;sequence_blocks=0;
    detected=sent=dropped=input_peak=input_blocks=0;consumed=0;
    clock=CLOCK_PULSE;clock_rearm=0;threshold=5;polarity=0;sync_input=SYNC_BOTH;stereo_config=0;input_rate=0;autostart=0;pulse_seen=pulse_period=transport_running=0;
    selected_source=SOURCE_NONE;test_cycles=0;clock_rate=0;reset_conversion();settings(0,0);
    clock_rearm=pulse_needs_mode=test_history_resets=0;
}
static void render(void) {
    int raw[128] = {0};
    for(unsigned i=0;i<64;i++)raw[2*i]=(int)test_input[i]*65536;
    line_cb(raw,64);
    block_cb();
}
static void drain(void) {
    while(test_rd!=test_wr) { assert(test_ring[test_rd&1023u]==(MIDI_TAG | 0xf80fu));test_rd++; }
}
static void stream(unsigned rate,unsigned bpm,int neg,unsigned input) {
    reset();polarity=neg;input_rate=(int)input;settings(0,0);block_cb();
    unsigned total=rate*8, expected=0, rng=42;
    unsigned last_quarter = 0;
    const int verify_native_clock = rate == 44100 && bpm == 120 && input == PPQ24;
    for(unsigned t=0;t<total;t+=64) {
        for(unsigned i=0;i<64;i++) {
            unsigned n=t+i;
            /* Rational clock: fractional periods alternate by one sample. */
            unsigned hz24=bpm*(24u << input), tick=(uint64_t)n*hz24/(rate*60u);
            unsigned edge=((uint64_t)tick*rate*60u+hz24-1u)/hz24, phase=n-edge;
            if(n<total && phase==0 && tick!=0) ++expected;
            rng=rng*1664525u+1013904223u;
            int noise=(int)((rng>>24)&127)-64;
            int x=(!tick || n>=total)?0:phase<12?10000:phase<20?-5000:noise;
            test_input[i]=(short)(neg?-x:x);
        }
        test_cycles = (uint64_t)(t + 64) * 400000000u / rate;
        render();
        if (verify_native_clock && test_rd != test_wr) {
            assert(test_wr - test_rd == 1);
            unsigned packet = test_ring[test_rd & 1023u];
            assert(clock_sync_mode(&packet) == 2 && pulse_use_current_time == 1);
            if (sent % 24 == 0) {
                unsigned quarter = (t + 64) * 1000u / rate;
                if (last_quarter) {
                    assert(quarter - last_quarter >= 498);
                    assert(quarter - last_quarter <= 502);
                }
                last_quarter = quarter;
            }
        }
        drain();
    }
    assert(detected==expected);assert(sent==(expected+(1u<<input)-1u)/(1u<<input));assert(dropped==0);
    if (verify_native_clock) assert(last_quarter != 0);
}

static void sparse_clock(unsigned rate)
{
    reset();
    input_rate = (int)rate;
    settings(0, 0);
    block_cb();
    unsigned divisions = ticks_per_pulse[rate - CLOCK_QUARTER];
    unsigned step = 1000000u, period = step * divisions;
    unsigned start = UINT_MAX - period / 2;
    test_cycles = start;
    ++detected;
    block_cb();
    assert(sent == 0);

    /* Verify exact output deadlines across counter rollover and stop. */
    for (unsigned slot = 1; slot < divisions * 4u; ++slot) {
        test_cycles = start + slot * step - 1u;
        block_cb();
        unsigned before = sent;
        test_cycles++;
        if (slot == divisions || slot == 2u * divisions) ++detected;
        block_cb();
        assert(sent - before == (slot >= divisions && slot < 3u * divisions));
        drain();
    }
    assert(sent == divisions * 2u);
    /* An expired tempo must be learned from two fresh pulses. */
    test_cycles += period * 3u;
    ++detected;
    block_cb();
    assert(sent == divisions * 2u);
    test_cycles += period;
    ++detected;
    block_cb();
    assert(sent == divisions * 2u + 1u);
    test_mode = 0;
    block_cb();
    test_mode = 2;
    test_cycles += step;
    block_cb();
    assert(sent == divisions * 2u + 1u);
}

/* Process realtime packets through the same source filter called by stock R246. */
static unsigned drain_transport(void)
{
    unsigned events = 0;
    while (test_rd != test_wr) {
        unsigned packet = test_ring[test_rd & 1023u];
        unsigned status = (packet >> 8) & 255u;
        if (clock_sync_mode(&packet)) {
            if (status == 0xf8u) events |= 1u;
            if (status == 0xfau) events |= 2u;
            if (status == 0xfcu) events |= 4u;
        }
        ++test_rd;
    }
    return events;
}

static void incoming(unsigned status)
{
    assert(pulse_ring_room(test_wr, test_rd));
    test_ring[test_wr++ & 1023u] = (status << 8) | 15u;
}

static void transport_tests(void)
{
    /* AutoStart precedes the very first F8, including divided PPQ modes. */
    for (unsigned rate = PPQ24; rate <= CLOCK_THIRTYSECOND; ++rate) {
        reset();
        autostart = 1;
        input_rate = (int)rate;
        settings(0, 0);
        block_cb();
        test_cycles = 10000000u;
        ++detected;
        block_cb();
        assert(((test_ring[test_rd & 1023u] >> 8) & 255u) == 0xfau);
        unsigned initial = drain_transport();
        assert(initial & 2u);
        assert(transport_running);
        unsigned period = rate >= CLOCK_QUARTER
            ? ticks_per_pulse[rate - CLOCK_QUARTER] * 1000000u : 10000000u;
        test_cycles += period;
        ++detected;
        block_cb();
        unsigned ongoing = drain_transport();
        assert(!(ongoing & 2u));
        if (rate == PPQ24 || rate >= CLOCK_QUARTER) assert(ongoing & 1u);
        unsigned timeout = pulse_timeout();
        test_cycles += timeout;
        block_cb();
        assert(!(drain_transport() & 4u));
        ++test_cycles;
        block_cb();
        assert(drain_transport() == 4u);
        block_cb();
        assert(drain_transport() == 0u);
        ++test_cycles;
        ++detected;
        block_cb();
        assert(drain_transport() & 2u);
    }

    /* AutoStart off produces only timing messages. */
    reset();
    ++detected;
    block_cb();
    assert(drain_transport() == 1u);
    test_cycles += FIRST_PULSE_TIMEOUT + 1u;
    block_cb();
    assert(drain_transport() == 0u);

    /* MIDI sync and transport never take over Pulse, even before the first edge. */
    reset();
    unsigned note = 0x00643c09u;
    unsigned note_copy = note;
    for (unsigned status = 0xf8; status <= 0xfc; ++status) {
        if (status == 0xf9) continue;
        unsigned midi = (status << 8) | 0x0fu;
        assert(clock_sync_mode(&midi) == 0);
    }
    incoming(0xfau);
    incoming(0xf8u);
    incoming(0xfbu);
    incoming(0xfcu);
    ++detected;
    block_cb();
    assert(selected_source == SOURCE_PULSE && test_wr == 5);
    assert(clock_sync_mode(&note) == 2 && note == note_copy);
    assert(drain_transport() == 1u);
    test_cycles = FIRST_PULSE_TIMEOUT + 1u;
    block_cb();
    assert(selected_source == SOURCE_NONE);
    incoming(0xf8u);
    block_cb();
    assert(selected_source == SOURCE_NONE && drain_transport() == 0u);

    /* Getter is queried twice by the stock mode-4 branch. Filter both queries. */
    reset();
    test_mode = 4;
    settings(0, 0);
    ++detected;
    block_cb();
    drain_transport();
    unsigned usb_tick = 0xf80fu;
    assert(clock_sync_mode(&usb_tick) == 0);
    assert(clock_sync_mode(&usb_tick) == 0);
    unsigned tagged_tick = MIDI_TAG | 0xf80fu;
    assert(clock_sync_mode(&tagged_tick) == 4 && pulse_use_current_time);
    assert(clock_sync_mode(&tagged_tick) == 4 && pulse_use_current_time);
    unsigned tagged_start = MIDI_TAG | 0xfa0fu;
    assert(clock_sync_mode(&tagged_start) == 4 && !pulse_use_current_time);
    test_mode = 2;
    assert(clock_sync_mode(&tagged_tick) == 2 && pulse_use_current_time);
    test_mode = 4;
    clock = CLOCK_OFF;
    settings(0, 0);
    assert(clock_sync_mode(&usb_tick) == 0 && !pulse_use_current_time);

    /* Lowercase settings migrate invalid old raw thresholds to the default. */
    reset();
    const unsigned levels[] = {64,128,256,512,1024,2048,4096,8192,12000,16000};
    for (unsigned i = 1; i <= 10; ++i) {
        threshold = (int)i;
        settings(0, 0);
        assert((config & 65535u) == levels[i - 1u]);
    }
    threshold = 1024;
    settings(0, 0);
    assert((config & 65535u) == 1024u);

    /* Long quarter-note acquisition, missing pulses, and timer rollover. */
    reset();
    autostart = 1;
    input_rate = CLOCK_QUARTER;
    settings(0, 0);
    block_cb();
    test_cycles = UINT_MAX - 500000000u;
    ++detected;
    block_cb();
    assert(drain_transport() == 2u);
    test_cycles += 600000000u; /* 40 BPM quarter notes */
    ++detected;
    block_cb();
    assert(drain_transport() == 1u);
    assert(transport_running && pulse_period == 600000000u);

    /* A full queue must not mark a failed Start as delivered. */
    reset();
    autostart = 1;
    settings(0, 0);
    test_wr = 1023;
    ++detected;
    block_cb();
    assert(!transport_running && dropped == 1u);
    test_rd = test_wr;
    test_cycles += 10000000u;
    ++detected;
    block_cb();
    assert(drain_transport() & 2u);
}

int main(void) {
    struct opl_self self={sizeof self,"esc.pulsesync",0,0};assert(opl_init(&self)==0);
    for(unsigned r=0;r<2;r++)for(unsigned b=0;b<3;b++)for(int p=0;p<2;p++) {
        const unsigned bpms[]={60,120,300};for(unsigned input=0;input<=PPQ96;input++) stream(r?22050:44100,bpms[b],p,input);
    }
    for(unsigned rate=CLOCK_QUARTER;rate<=CLOCK_THIRTYSECOND;rate++) sparse_clock(rate);
    /* No rising edge at startup while a gate is already high; no repeat on a held gate. */
    reset();for(unsigned i=0;i<64;i++)test_input[i]=12000;
    for(unsigned i=0;i<100;i++)render();assert(detected==0);
    memset((void *)test_input,0,sizeof test_input);render();
    for(unsigned i=0;i<64;i++)test_input[i]=12000;
    for(unsigned i=0;i<100;i++)render();assert(detected==1 && sent==1);
    /* Block callback alone cannot re-detect a stale audio buffer. */
    for(unsigned i=0;i<100;i++)block_cb();assert(detected==1 && sent==1);
    /* Retrigger noise inside blanking cannot become a delayed second trigger. */
    struct pulse_detector d={0,0};unsigned ticks=0;
    ticks+=pulse_sample(&d,0,1024,0,88);ticks+=pulse_sample(&d,12000,1024,0,88);
    ticks+=pulse_sample(&d,0,1024,0,88);
    for(unsigned i=0;i<200;i++)ticks+=pulse_sample(&d,12000,1024,0,88);
    assert(ticks==1);
    /* Off and COM never inject. A late native mode change cannot strand Pulse. */
    reset();clock=CLOCK_OFF;settings(0,0);test_input[1]=10000;render();assert(sent==0 && detected==0);
    clock=CLOCK_PULSE;settings(0,0);test_mode=0;test_com=1;render();
    assert(detected==0 && sent==0 && test_mode==0 && esc_pulsesync_input_mask()==0);
    test_com=0;test_input[1]=0;render();
    assert(sent==0 && test_mode==2);
    test_mode=1;test_rx_phase=15;test_input[1]=10000;render();
    assert(test_mode==2 && detected==1 && sent==1 && clock_rearm);
    unsigned resumed_tick=test_ring[0];
    assert(clock_sync_mode(&resumed_tick)==2 && test_rx_phase==0 && pulse_use_current_time==1);
    reset();test_input_mode=1;test_input[2]=10000;render();assert(sent==1 && input_peak==10000);
    /* Full/invalid ring: leave data and both counters alone. */
    reset();test_wr=1023;test_rd=0;test_ring[1023]=0x12345678;detected=1;block_cb();
    assert(test_wr==1023 && test_rd==0 && test_ring[1023]==0x12345678 && dropped==1);
    reset();test_wr=2;test_rd=3;detected=1;block_cb();assert(test_wr==2 && dropped==1);
    /* Free-running counter rollover and last free slot. */
    reset();test_wr=UINT_MAX;test_rd=UINT_MAX-5;detected=1;block_cb();
    assert(test_wr==0 && test_ring[1023]==(MIDI_TAG | 0xf80fu) && sent==1);
    reset();test_wr=1022;detected=2;block_cb();assert(sent==1 && dropped==1 && test_wr==1023);
    /* A delayed consumer discards an old burst instead of accelerating time. */
    reset();detected=9;block_cb();assert(sent==0 && dropped==9);block_cb();assert(dropped==9);
    /* Input extreme and threshold extremes. */
    for(unsigned th=1;th<=10;th+=9) {
        reset();threshold=(int)th;polarity=1;settings(0,0);test_input[2]=-32768;render();
        assert(detected==1 && input_peak==32768);
    }
    /* Clock removal happens in the same block and preserves the other side. */
    for (unsigned mask=1;mask<=3;++mask) {
        reset();int raw[128]={0};
        sync_input=mask==3?SYNC_BOTH:mask==1?SYNC_LEFT:SYNC_RIGHT;settings(0,0);
        raw[126]=(mask&1)?10000*65536:200*65536;
        raw[127]=(mask&2)?10000*65536:300*65536;
        int left=raw[126],right=raw[127];
        line_cb(raw,64);
        assert(detected==1);
        assert(raw[126]==((mask&1)?0:left));
        assert(raw[127]==((mask&2)?0:right));
        clock=CLOCK_OFF;settings(0,0);raw[126]=left;raw[127]=right;line_cb(raw,64);assert(raw[126]==left && raw[127]==right);
    }
    reset();
    int idle_audio[128] = {0};
    idle_audio[126] = 100 * 65536;
    idle_audio[127] = 200 * 65536;
    line_cb(idle_audio,64);assert(idle_audio[126]==0 && idle_audio[127]==0);
    sync_input=SYNC_BOTH;settings(0,0);
    line_cb(idle_audio,64);
    assert(idle_audio[126]==0 && idle_audio[127]==0);
    idle_audio[126]=10000*65536;
    line_cb(idle_audio,64);
    assert(idle_audio[126]==0 && idle_audio[127]==0 && detected==1);
    reset();
    sync_input=SYNC_LEFT;settings(0,0);
    idle_audio[126]=100*65536;idle_audio[127]=200*65536;
    line_cb(idle_audio,64);
    assert(idle_audio[126]==0 && idle_audio[127]==200*65536);
    sync_input=SYNC_RIGHT;settings(0,0);
    idle_audio[126]=100*65536;
    line_cb(idle_audio,64);
    assert(idle_audio[126]==100*65536 && idle_audio[127]==0);
    /* Re-selecting the same input must not invent a tick. */
    reset();test_input[1]=10000;render();unsigned before=detected;
    settings(0,0);render();assert(detected==before);
    reset();assert(esc_pulsesync_input_mask()==3);
    sync_input=SYNC_LEFT;settings(0,0);assert(esc_pulsesync_input_mask()==1);
    sync_input=SYNC_RIGHT;settings(0,0);assert(esc_pulsesync_input_mask()==2);
    clock=CLOCK_OFF;settings(0,0);assert(esc_pulsesync_input_mask()==0);
    clock=CLOCK_PULSE;test_mode=0;settings(0,0);assert(esc_pulsesync_input_mask()==2);
    transport_tests();
    reset();
    clock = CLOCK_LINK;
    const unsigned first_activation = sync_link_activation();
    settings(0, 0);
    assert(sync_link_activation() == first_activation + 1);
    assert(sync_link_requested() && esc_pulsesync_input_mask() == 0);
    test_input[2] = 10000;
    render();
    assert(test_wr == 0 && detected == 0);
    sync_link_clock_tick();
    sync_link_transport(0xfau);
    assert(test_wr == 2 && test_ring[0] == (LINK_TAG | 0xf80fu));
    assert(test_ring[1] == (LINK_TAG | 0xfa0fu));
    unsigned link_tick = test_ring[0], pulse_tick = MIDI_TAG | 0xf80fu, usb_tick = 0xf80fu;
    test_rx_phase = 22;
    test_mode = 0;
    assert(clock_sync_mode(&link_tick) == 2 && pulse_use_current_time == 2);
    assert(test_rx_phase == 0 && !clock_rearm);
    assert(clock_sync_mode(&pulse_tick) == 0 && !pulse_use_current_time);
    assert(clock_sync_mode(&usb_tick) == 0 && !pulse_use_current_time);
    const unsigned note = 0x00643c09u;
    assert(clock_sync_mode(&note) == 2);
    clock = CLOCK_MIDI;
    settings(0, 0);
    assert(!sync_link_requested() && esc_pulsesync_input_mask() == 0);
    assert(sync_midi_requested() && clock_rearm);
    test_mode = 1; /* Native tempo screen was on internal clock. */
    test_rx_phase = 19;
    test_follow = 1;
    test_com = 1;
    assert(clock_sync_mode(&usb_tick) == 1 && clock_rearm && test_rx_phase == 19);
    test_com = 0;
    const unsigned start = 0xfa0fu;
    assert(clock_sync_mode(&start) == 2 && clock_rearm && test_rx_phase == 19);
    assert(clock_sync_mode(&usb_tick) == 2 && !clock_rearm);
    assert(test_rx_phase == 0 && test_history_resets == 2);
    test_rx_phase = 7;
    assert(clock_sync_mode(&usb_tick) == 2 && test_rx_phase == 7);
    settings(0, 0); /* An unrelated setting does not restart clock acquisition. */
    assert(!clock_rearm);
    /* The native tempo screen can change mode after the first MIDI lock. */
    test_mode = 1;
    test_rx_phase = 13;
    assert(clock_sync_mode(&usb_tick) == 2 && !clock_rearm && test_rx_phase == 0);
    assert(!pulse_use_current_time);
    assert(clock_sync_mode(&note) == 2);
    assert(clock_sync_mode(&link_tick) == 0);
    assert(clock_sync_mode(&pulse_tick) == 0);
    sync_link_clock_tick();
    assert(test_wr == 2);
    for (unsigned status = 0xfa; status <= 0xfc; ++status) {
        unsigned midi_transport = (status << 8) | 0x0fu;
        assert(clock_sync_mode(&midi_transport) == 2);
    }

    clock = CLOCK_OFF;
    settings(0, 0);
    sync_link_clock_tick();
    assert(test_wr == 2 && clock_sync_mode(&link_tick) == 0);
    assert(clock_sync_mode(&usb_tick) == 0 && !sync_midi_requested());
    assert(clock_sync_mode(&note) == 2);
    clock = CLOCK_PULSE;
    settings(0, 0);
    clock = CLOCK_MIDI;
    settings(0, 0);
    test_mode = 4;
    assert(clock_rearm && clock_sync_mode(&usb_tick) == 4 && !clock_rearm);
    clock = CLOCK_LINK;
    settings(0, 0);
    assert(sync_link_activation() == first_activation + 2);
    test_rx_phase = 6;
    assert(clock_rearm && clock_sync_mode(&link_tick) == 4 && !clock_rearm);
    assert(test_rx_phase == 0 && pulse_use_current_time == 2);
    sync_link_tempo_period(500000);
    assert(link_tempo_timestamp(1000000, link_beat_period) == 1000000);
    assert(link_tempo_timestamp(1511000, link_beat_period) == 1500000);
    assert(link_tempo_timestamp(1992000, link_beat_period) == 2000000);
    sync_link_tempo_period(480000);
    assert(link_tempo_timestamp(2490000, link_beat_period) == 2480000);
    assert(link_tempo_timestamp(4000000, link_beat_period) == 4000000);
    clock = CLOCK_PULSE;
    settings(0, 0);
    test_mode = 1;
    test_rx_phase = 11;
    assert(clock_rearm && pulse_needs_mode && esc_pulsesync_input_mask() == 3);
    block_cb();
    assert(test_mode == 2 && !pulse_needs_mode && esc_pulsesync_input_mask() == 3);
    assert(test_rx_phase == 11 && clock_sync_mode(&usb_tick) == 0 && clock_rearm);
    assert(clock_sync_mode(&pulse_tick) == 2 && !clock_rearm && test_rx_phase == 0);
    assert(pulse_use_current_time == 1);
    reset();
    frame_cb(NULL);
    assert(!pulse_notice);
    test_edit_mode = 5;
    test_input_source = 0;
    frame_cb(NULL);
    assert(!pulse_notice);
    test_input_source = 1;
    test_mode = 1; /* The label reports the selection before the first pulse. */
    const char *const notices[] = {"sync l+r", "sync l", "sync r"};
    for (unsigned i = 0; i < 3; ++i) {
        sync_input = (int)i;
        settings(0, 0);
        frame_cb(NULL);
        assert(pulse_notice && !strcmp(pulse_notice, notices[i]));
    }
    for (clock = CLOCK_OFF; clock < CLOCK_PULSE; ++clock) {
        settings(0, 0);
        pulse_notice = NULL;
        frame_cb(NULL);
        assert(!pulse_notice && !esc_pulsesync_input_mask());
    }
    test_edit_mode = 4;
    test_screen = 0x22;
    test_mode = 2;
    const char *const tempo_labels[] = {NULL, "midi", "link", "pulse"};
    for (clock = CLOCK_OFF; clock <= CLOCK_PULSE; ++clock) {
        tempo_notice = NULL;
        settings(0, 0);
        frame_cb(NULL);
        assert(tempo_labels[clock] ? tempo_notice && !strcmp(tempo_notice, tempo_labels[clock])
                                   : !tempo_notice);
    }
    tempo_notice = NULL;
    test_mode = 1;
    frame_cb(NULL);
    assert(!tempo_notice);
    test_mode = 4;
    test_screen = 0x21;
    frame_cb(NULL);
    assert(!tempo_notice);
    test_screen = 0x22;
    frame_cb(NULL);
    assert(tempo_notice && !strcmp(tempo_notice, "pulse"));
    puts("PASS tempo screen source label and MIDI reacquisition");
    reset();
    clock = CLOCK_LINK;
    settings(0, 0);
    sync_usb_midi_realtime(0xf8u);
    assert(test_wr == 0);
    clock = CLOCK_MIDI;
    settings(0, 0);
    sync_usb_midi_realtime(0xf8u);
    assert(test_wr == 1 && test_ring[0] == (USB_CLOCK_TAG | 0xf80fu));
    unsigned composite_tick = test_ring[0];
    test_mode = 1;
    test_rx_phase = 20;
    assert(clock_sync_mode(&composite_tick) == 2 && pulse_use_current_time == 1);
    assert(!clock_rearm && test_rx_phase == 0);
    clock = CLOCK_LINK;
    settings(0, 0);
    assert(clock_sync_mode(&composite_tick) == 0 && !pulse_use_current_time);
    clock = CLOCK_PULSE;
    settings(0, 0);
    assert(clock_sync_mode(&composite_tick) == 0 && !pulse_use_current_time);
    puts("PASS composite USB-MIDI Clock after Link, native timestamp and source isolation");
    puts("PASS stock LINE input page notice and Pulse reacquisition on the first edge");
    puts("PASS MIDI, Link and Pulse handovers, native clock reacquisition and input release");
    puts("PASS: 36 noisy 24/48/96-PPQ streams and all four sparse rates (60/120/300 BPM, both rates/polarities), held gates, ringing, stale buffers, enable/sync modes and line input gating, queue bounds/rollover, stale bursts, extremes, same-block stereo split, label routing, mute toggle continuity, threshold mapping, AutoStart/Stop and clock-source arbitration.");
}
