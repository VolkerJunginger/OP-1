#!/bin/sh
set -eu
here=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
kit=$(CDPATH= cd -- "$here/../../.." && pwd)
tmp=$(mktemp -d /tmp/pulse-test.XXXXXX)
trap 'rm -rf "$tmp"' EXIT
"${CC:-clang}" -std=c11 -O1 -Wall -Wextra -Werror -fsanitize=address,undefined -fno-sanitize-recover=all \
 -I "$kit/sdk" "$here/host.c" -o "$tmp/test"
"$tmp/test"
