# Building SYNC 1.0

This archive contains the corresponding source and build scripts for the distributed SYNC 1.0 OP-1 mod. Its embedded version is 0.3.17.

Use Python 3.8 or later and a Blackfin ELF toolchain with `bfin-elf-gcc` and binutils. If the kit cannot find the compiler, set `OP1_BFIN_TOOLCHAIN` to the directory containing its `bin` directory.

From this directory, run:

```sh
sh work/sync-usbnet/r246/build.sh vendor/lwip/src "$PWD/SYNC.opmod"
```

This compiles the C and assembly sources with the bundled Opus kit and selected lwIP 2.2.1 modules, produces a standalone mod, then displays its manifest. Run `sh work/sync-usbnet/r246/test.sh` for the USB and Tape rendering host checks. See the Link Core and Link Audio source notes for their upstream reference tests.

The release mod's SHA-256 is `4f792d89b551304b4e6664d4dca68de57f4c55ffe9a336422ce2cd08362d24e3`.

See THIRD_PARTY_NOTICES.md, LICENSE, the Opus kit README, and the upstream license files under vendor.
