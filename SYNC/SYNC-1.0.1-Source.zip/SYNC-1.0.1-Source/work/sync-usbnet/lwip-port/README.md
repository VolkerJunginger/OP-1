# SYNC Link über lwIP

Der Port verbindet den C-Link-Core über lwIP 2.2.1 mit einem IPv4-netif.
Ein einzelner NO_SYS-Worker führt alle Aufrufe aus. `ecm_link.c` verwaltet
die lwIP-Schnittstelle, AutoIP, Timer und Link-Session. Der Firmwareadapter
aktiviert die USB-Endpunkte, leitet Änderungen des ECM-Paketfilters und
des Alternate Settings in den Worker und übergibt USB-OUT-Pakete.
Die TX-Funktion muss den angegebenen Frame kopieren, bevor sie zurückkehrt.
Sie erhält das ZLP-Flag zur Terminierung. Vor dem Abbau muss der
Firmwareadapter alte Transferabschlüsse vom neuen Empfang fernhalten.
Der Worker stoppt Link und AutoIP bei Alt 0. Bei Wiederaktivierung wird
die Session mit neuer Node-ID eröffnet.

Die drei UDP-PCBs empfangen Multicast-Discovery, unicast Discovery und
Clock-Measurement. Jeder Ausgangspuffer wird nach dem Versandversuch
freigegeben. Ausgabefehler werden als verlorene UDP-Datagramme behandelt.

## Hostprüfung

```sh
sh work/sync-usbnet/lwip-port/test.sh /pfad/zu/lwip/src
```

Verwende den Upstream-Tag `STABLE-2_2_1_RELEASE`. Der Test verwendet
echte lwIP-Ethernet-, IP-, IGMP- und UDP-Verarbeitung mit einer simulierten
Ethernet-Schnittstelle. Er prüft Link ALIVE, RX über fragmentierten
ECM-Bulk-OUT, den Empfang eines zweiten Nodes und das erneute Öffnen nach
einem Fehler oder regulären Abbau. lwIP bezieht die Testadresse mit
AutoIP über eine simulierte NIC. Adresskonflikte und UDP mit Ableton Live
bleiben separat zu prüfen.

Der ausgelieferte Blackfin-Build verwendet `../r246/build.sh` und dessen
Manifest. `../r246/sync_device.c` verbindet den Netzwerk-Worker mit dem
R246-USB-Dispatcher und stellt Zeit, Zufall und den Assertion-Pfad bereit.

[Upstream-Quelle](https://github.com/lwip-tcpip/lwip/tree/STABLE-2_2_1_RELEASE)

## Übergabe an den USB-Controller

Der Gerätepfad nutzt den R246-Deskriptorgraphen und die Transferverwaltung
aus `../r246/ecm_graph.c`, `../r246/ecm_setup.c` und
`../r246/usb_requests.c`. `../r246/test.sh` prüft deren Logik mit
Host-Stubs und testet die Link-Audio-Sendekapazität mit dem produktiven
Paketierer und simulierten USB-Transfers.

`ecm_endpoint.c` ist der frühere generische Adapter für den in
`test_link_net.c` simulierten Controller. Dieser Test prüft unter anderem
Altsetting-Wechsel, OUT-Fehler und verspätete Abschlüsse. Der Adapter
wird beim SYNC-Gerätebuild nicht gelinkt.
