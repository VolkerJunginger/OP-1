/* SPDX-License-Identifier: GPL-3.0-or-later */
#include "../audio_usb.h"
#include "link_audio_packetizer.h"
#include <assert.h>
#include <limits.h>
#include <stdio.h>

struct simulated_usb {
    unsigned read, write, peers;
};

static void queue_datagram(void *context, const uint8_t *packet, size_t length)
{
    struct simulated_usb *usb = context;
    (void)packet;
    assert(length <= AUDIO_UDP_BYTES);
    for (unsigned peer = 0; peer < usb->peers; ++peer) {
        assert(audio_usb_has_room(usb->read, usb->write, 1));
        ++usb->write;
    }
}

static void test_fanout(unsigned peers)
{
    struct simulated_usb usb = {UINT_MAX - 1, UINT_MAX - 1, peers};
    const unsigned reservation = peers * LINK_AUDIO_CHANNELS;
    const uint8_t id[LINK_AUDIO_ID_SIZE] = {0};
    const int16_t pcm[AUDIO_FRAMES * 2] = {0};
    LinkAudioPacketizer streams[LINK_AUDIO_CHANNELS];

    for (unsigned channel = 0; channel < LINK_AUDIO_CHANNELS; ++channel) {
        link_audio_packetizer_init(&streams[channel], id, id, queue_datagram, &usb);
        link_audio_packetizer_limit(&streams[channel], AUDIO_UDP_BYTES);
    }

    unsigned max_emitted = 0;
    for (unsigned block = 0; block < 64; ++block) {
        /* Leave exactly the reserved space, exercising index wrap as well. */
        usb.read = usb.write - (AUDIO_USB_SLOTS - reservation);
        assert(audio_usb_has_room(usb.read, usb.write, reservation));
        assert(!audio_usb_has_room(usb.read - 1, usb.write, reservation));
        unsigned before = usb.write;
        int64_t beat = ((int64_t)block * AUDIO_FRAMES * 2000000 + 22050) / 44100;
        if (block >= 32)
            beat += block * 100; /* Start a new timing chunk on every block. */
        for (unsigned channel = 0; channel < LINK_AUDIO_CHANNELS; ++channel) {
            unsigned datagram_start = usb.write;
            uint8_t channels = channel == LINK_AUDIO_MASTER ? 2 : 1;
            assert(link_audio_packetizer_add(&streams[channel], pcm, AUDIO_FRAMES, channels,
                                             44100, id, beat, 500000));
            assert(usb.write - datagram_start <= peers);
        }
        unsigned emitted = usb.write - before;
        if (emitted > max_emitted)
            max_emitted = emitted;
    }
    assert(max_emitted == reservation);
    printf("Link Audio fan-out: %u listeners, %u datagrams in one block, no queue overflow\n",
           peers, max_emitted);
}

int main(void)
{
    test_fanout(5);
    test_fanout(LINK_MAX_PEERS);
}
