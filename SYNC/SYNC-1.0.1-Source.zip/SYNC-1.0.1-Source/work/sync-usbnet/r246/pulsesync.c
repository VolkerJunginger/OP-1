/* SPDX-License-Identifier: GPL-3.0-or-later */
#define SYNC_LINK_DEVICE 1
#include "pulse/pulsesync.c"
