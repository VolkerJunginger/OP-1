#!/bin/sh
set -eu
src=${1:?Pass the src directory of lwIP STABLE-2_2_1_RELEASE}
output=${2:?Pass the absolute destination path for the .opmod}
here=$(CDPATH='' cd -- "$(dirname -- "$0")" && pwd)
root=$(CDPATH='' cd -- "$here/../../.." && pwd)
kit="$root/Opus Plugin Kit"
pulse="$kit/plugins/esc.sync"
net="$here/../lwip-port"
core="$root/work/sync-link-core"
audio="$root/work/sync-link-audio"
stage=$(mktemp -d)
trap 'rm -rf "$stage"' EXIT
cp -R "$src/include/lwip" "$src/include/netif" "$net/arch" "$stage"
cp "$net/bf524/include/"*.h "$net/bf524/runtime.c" "$net/lwipopts.h" "$stage"

mkdir "$stage/pulse"
cp "$pulse/pulsesync.c" "$pulse/sync_filter.S" \
    "$pulse/pulse_core.h" "$pulse/pulse_route.h" "$stage/pulse"
cp "$here/pulsesync.c" "$here/sync_filter.S" "$here/manifest.txt" "$stage"
cp "$here/ecm_graph.c" "$here/ecm_graph.h" "$here/ecm_setup.c" "$here/ecm_setup.h" \
    "$here/usb_requests.c" "$here/usb_requests.h" "$here/sync_device.c" "$here/audio_usb.h" \
    "$here/tape_capture_r246.c" "$here/tape_capture_r246.h" \
    "$here/tape_render.c" "$here/tape_render.h" "$stage"
cp "$here/../ecm.c" "$here/../ecm.h" "$here/../ecm_bulk.c" "$here/../ecm_bulk.h" \
    "$here/../ecm_port.c" "$here/../ecm_port.h" \
    "$here/../ecm_rx_queue.c" "$here/../ecm_rx_queue.h" "$stage"
cp "$net/link_net.c" "$net/link_net.h" "$net/link_audio_net.c" \
    "$net/ecm_link.c" "$net/ecm_link.h" "$stage"
cp "$core/link_session.c" "$core/link_session.h" "$core/link_wire.c" "$core/link_wire.h" \
    "$core/link_timeline.c" "$core/link_clock.c" "$core/link_clock.h" "$stage"
cp "$audio/link_audio.c" "$audio/link_audio.h" \
    "$audio/link_audio_control.c" "$audio/link_audio_control.h" \
    "$audio/link_audio_packetizer.c" "$audio/link_audio_packetizer.h" "$stage"
cp "$root/work/sync-clock/link_midi_clock.c" "$root/work/sync-clock/link_midi_clock.h" "$stage"

for f in core/def.c core/init.c core/inet_chksum.c core/ip.c core/mem.c core/memp.c \
    core/netif.c core/pbuf.c core/stats.c core/sys.c core/timeouts.c core/udp.c \
    core/ipv4/acd.c core/ipv4/autoip.c core/ipv4/etharp.c core/ipv4/icmp.c \
    core/ipv4/igmp.c core/ipv4/ip4.c core/ipv4/ip4_addr.c netif/ethernet.c
do
    cp "$src/$f" "$stage"
done
cd "$kit"
python3 plugin_tool.py doctor
python3 plugin_tool.py build "$stage" --out "$output"
python3 plugin_tool.py show "$output"
