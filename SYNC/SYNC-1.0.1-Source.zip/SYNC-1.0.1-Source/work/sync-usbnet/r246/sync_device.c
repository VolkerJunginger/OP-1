/* SPDX-License-Identifier: GPL-3.0-or-later */
#include "opus_plugin.h"
#include "op1fw.h"
#include "audio_usb.h"
#include "ecm_setup.h"
#include "ecm_link.h"
#include "ecm_rx_queue.h"
#include "link_midi_clock.h"
#include "link_audio_control.h"
#include "link_audio_packetizer.h"
#include "tape_capture_r246.h"
#include "lwip/init.h"
#include <string.h>

/* The USB task serializes the R246 dispatcher, lwIP and bulk submission.
 * OP_Main and the sequencer only wake the task. */
extern unsigned sync_link_requested(void);
extern unsigned sync_midi_requested(void);
extern unsigned sync_pulse_requested(void);
extern unsigned sync_link_activation(void);
extern void sync_link_clock_tick(void);
extern void sync_link_transport(unsigned status);
extern void sync_link_tempo_period(unsigned period);
extern void sync_usb_midi_realtime(unsigned status);
static struct r246_ecm_graph graph;
static struct ecm_state usb_control;
static struct r246_usb_pipe tx, notify, midi_in;
static struct r246_midi_tx midi_tx;
static volatile bool midi_tx_active;
static struct ecm_link network;
static struct link_midi_clock clock;
static unsigned clock_activation;
static struct opl_self *plugin;
static const struct ecm_endpoints addresses = {
    R246_ECM_INTERRUPT_IN, R246_ECM_BULK_OUT, R246_ECM_BULK_IN
};
static uint8_t host_mac[6] = {2, 0x53, 0x59, 0, 0, 2};
static uint8_t device_mac[6] = {2, 0x53, 0x59, 0, 0, 1};
static unsigned random_state, last_cycles, fraction;
static int64_t worker_us;
static uint64_t node;
static int usb_guard = -1;
static unsigned rx_packet_bytes, epoch;
static volatile unsigned usb_state, usb_attached;
static bool usb_restart_pending;
static unsigned worker_epoch;
static volatile unsigned last_work_cycles, wake_pending;
static bool tx_zlp;
static enum { NO_NOTICE, CONNECTION_NOTICE, SPEED_NOTICE } notice_pending;
static bool link_playing;
static volatile unsigned transport_enabled;
static volatile bool network_open;

enum { AUDIO_BLOCKS = 64 };
static volatile unsigned audio_enabled, audio_generation;
static volatile bool link_audio_on;

unsigned sync_network_requested(void)
{
    return sync_link_requested() || link_audio_on;
}
static volatile unsigned audio_capture_mask;
_Static_assert((int)AUDIO_FRAMES == (int)TAPE_BLOCK, "Tape block size");
_Static_assert(LINK_AUDIO_CHANNELS - LINK_AUDIO_TAPE_1 == TAPE_TRACKS, "Tape channel count");
enum { TX_MASTER = 1, TX_TAPE = 2 };
static bool tape_supported;
static unsigned audio_generation_counter;
static uint64_t audio_node, audio_session;
static struct audio_stream {
    LinkAudioPacketizer packetizer;
    unsigned generation;
    unsigned subscribers;
} audio_streams[LINK_AUDIO_CHANNELS];
static int16_t instrument_pcm[2][AUDIO_FRAMES];
static unsigned instrument_ready;
static struct {
    volatile unsigned read, write;
    unsigned next_sample;
    struct {
        unsigned generation, sample, cycles, mask;
        unsigned stream_generation[LINK_AUDIO_CHANNELS];
        int16_t pcm[AUDIO_FRAMES * (LINK_AUDIO_CHANNELS + 1)];
    } slots[AUDIO_BLOCKS];
} captured;
static struct {
    volatile unsigned read, write;
    struct {
        unsigned generation, size, channel;
        bool zlp;
        uint8_t bytes[AUDIO_ETH_BYTES];
    } slots[AUDIO_USB_SLOTS];
} audio_usb;
static struct {
    unsigned sample;
    int64_t beat, period;
    link_timeline timeline;
    link_clock clock;
    bool valid;
} audio_timing;

struct packet_slot {
    volatile unsigned ready;
    unsigned generation, size;
    bool zlp;
    uint8_t bytes[ECM_MAX_FRAME];
};
static struct packet_slot outgoing;
static struct ecm_rx_queue incoming;
static const struct r246_usb_request_ops *const pipes = &r246_usb_request_ops;

static void publish(void) { __asm__ volatile("ssync;" : : : "memory"); }
static void acquire(void) { __asm__ volatile("" : : : "memory"); }
static void worker(unsigned now);
static void stop_capture(void);

static unsigned cycles_now(void)
{
    unsigned result;
    __asm__ volatile("%0 = CYCLES;" : "=d"(result));
    return result;
}

static void wake_usb(void)
{
    if (wake_pending)
        return;
    int sem = *(volatile const int *)0x01dfe044u;
    if (sem >= 0) {
        wake_pending = 1;
        fw_vdk_post_semaphore(sem);
    }
}

/* Notes and other MIDI messages are produced by the native MIDI API.
 * Clock-source filtering only affects incoming realtime messages. */
extern void orig_019e0d18(int unused, const unsigned *packets, int count);

void sync_midi_send(int unused, const unsigned *packets, int count)
{
    if (!usb_attached) {
        orig_019e0d18(unused, packets, count);
        return;
    }
    if (count <= 0)
        return;
    unsigned irq;
    __asm__ volatile("cli %0;" : "=d"(irq) : : "memory");
    if (midi_tx_active)
        (void)r246_midi_tx_push(&midi_tx, packets, (unsigned)count);
    __asm__ volatile("sti %0;" : : "d"(irq) : "memory");
}

void sync_device_sequence_tick(void)
{
    if ((midi_tx.write != midi_tx.read || (audio_generation && (usb_state & (1u << 16)))) &&
        cycles_now() - last_work_cycles >= 320000u)
        wake_usb();
}

static void wake_from_main(void)
{
    if ((usb_attached || network_open) &&
        cycles_now() - last_work_cycles >= 800000u)
        wake_usb();
}

uint32_t sys_now(void) { return (uint32_t)(worker_us / 1000); }

uint32_t sync_net_random(void)
{
    random_state ^= random_state << 13;
    random_state ^= random_state >> 17;
    random_state ^= random_state << 5;
    return random_state;
}

void sync_net_assert(const char *message)
{
    (void)message;
    __builtin_trap();
}

static void publish_state(void)
{
    /* One consistent word: reset token, speed, alternate, filter. */
    usb_state = ((epoch & 0x3fffu) << 18) |
                (rx_packet_bytes == ECM_BULK_HIGH_SPEED ? 1u << 17 : 0) |
                ((unsigned)ecm_link_up(&usb_control) << 16) | usb_control.packet_filter;
}

static void retire_bulk(void)
{
    stop_capture();
    r246_usb_pipe_retire(&tx, pipes);
    tx_zlp = false;
    ++epoch;
}

static int event(struct r246_usb_device *dev, int kind)
{
    if (kind == 3 && usb_control.configured)
        fw_usb_event(dev, 10); /* Reset while configured: drain data endpoints. */
    if (kind == 4 || kind == 10 || kind == 15) {
        midi_tx_active = false;
        midi_tx.read = midi_tx.write;
        if (kind != 4) {
            retire_bulk();
            r246_usb_pipe_retire(&notify, pipes);
            r246_usb_pipe_retire(&midi_in, pipes);
        }
        ecm_configured(&usb_control, 0);
        notice_pending = NO_NOTICE;
        ++epoch;
    } else if (kind == 6) {
        ecm_configured(&usb_control, 1);
        midi_tx_active = true;
    } else if (kind == 7 && usb_control.configured) {
        /* R246's current alternate table starts at device + 0x14. */
        const uint8_t *device_bytes = (const uint8_t *)dev;
        unsigned alt = device_bytes[0x15];
        if (alt != usb_control.data_alt && ecm_data_alt(&usb_control, alt)) {
            if (!alt) retire_bulk();
            notice_pending = CONNECTION_NOTICE;
        }
    }
    const uint8_t *out = graph.data_endpoints[0];
    rx_packet_bytes = out[4] | ((unsigned)out[5] << 8);
    publish_state();
    /* The two replaced native AudioStreaming interfaces occupied indices 1 and 2.
     * Their SET_INTERFACE handlers must never run for the new interfaces. */
    return kind == 7 ? 0 : graph.stock_function->callbacks->event(dev, kind);
}

static bool on_endpoint(const struct r246_usb_request *req, unsigned address)
{
    return req->device == graph.attached_device &&
           req->endpoint && *(const uint32_t *)req->endpoint == address;
}

/* SYNC owns the composite IN endpoint. Keep the native allocations for
 * standard USB only. Native SET_CONFIGURATION still runs for MIDI RX. */
struct r246_usb_request *sync_midi_allocate(struct r246_usb_device *dev,
                                           unsigned endpoint, unsigned capacity)
{
    if (dev == graph.attached_device && endpoint == R246_NATIVE_MIDI_IN)
        return NULL;
    return pipes->allocate(dev, endpoint, capacity);
}

static int in_done(struct r246_usb_request *req)
{
    if (req == tx.request)
        return r246_usb_pipe_complete(&tx, req);
    if (req == midi_in.request) {
        if (midi_tx_active && req->status == R246_IN_DONE &&
            req->transferred <= req->length)
            r246_midi_tx_sent(&midi_tx, req->transferred);
        return r246_usb_pipe_complete(&midi_in, req);
    }
    return r246_usb_pipe_complete(&notify, req);
}

static int out_done(struct r246_usb_request *req)
{
    if (on_endpoint(req, R246_MIDI_OUT)) {
        if (req->status == R246_OUT_DONE && req->buffer && req->transferred <= req->capacity)
            r246_midi_receive(req->buffer, req->transferred,
                             sync_midi_requested() ? sync_usb_midi_realtime : NULL);
        return -1; /* The firmware recycles the original OUT request. */
    }
    if (ecm_link_up(&usb_control) && on_endpoint(req, addresses.bulk_out) &&
        req->status == R246_OUT_DONE && req->buffer &&
        req->transferred <= req->capacity) {
        ecm_rx_queue_packet(&incoming, &usb_control, rx_packet_bytes, req->buffer,
                            req->transferred, epoch & 0x3fffu);
    }
    /* R246 immediately recycles its OUT request here. Generic submission
     * is used only for the separately allocated IN requests. */
    return -1;
}

int sync_usb_setup(struct r246_usb_request *ep0)
{
    uint16_t previous_filter = usb_control.packet_filter;
    int result = r246_ecm_setup(&graph, &usb_control, ep0,
                               (int (*)(struct r246_usb_request *))fw_usb_setup);
    if (usb_control.packet_filter != previous_filter)
        publish_state();
    return result;
}

static const struct r246_usb_callbacks callbacks = {event, in_done, out_done, sync_usb_setup};

struct r246_usb_device *sync_usb_construct(void *dcd)
{
    struct r246_usb_device *dev = ((struct r246_usb_device *(*)(void *))0x01a6cd28u)(dcd);
    if (dev && (uintptr_t)dev->function == 0x018c1ddcu && sync_network_requested()) {
        const struct r246_usb_callbacks *native = dev->function->callbacks;
        bool midi_layout_failed = !native ||
            (uintptr_t)native->event != 0x01a69e80u ||
            (uintptr_t)native->in_done != 0x01a693c8u ||
            (uintptr_t)native->out_done != 0x01a694a6u ||
            !r246_ecm_graph_prepare(&graph, dev->function, &callbacks, addresses,
                                     ECM_BULK_HIGH_SPEED, 64, host_mac) ||
            !r246_ecm_graph_add_midi(&graph);
        if (!midi_layout_failed)
            usb_attached = r246_ecm_graph_attach(&graph, dev);
    }
    return dev;
}

void sync_usb_destroy(struct r246_usb_device *dev)
{
    if (graph.attached_device && graph.attached_device == dev) {
        stop_capture();
        wake_pending = 0;
        midi_tx_active = false;
        midi_tx.read = midi_tx.write;
        usb_attached = 0;
        ecm_configured(&usb_control, 0);
        publish_state();
        (void)r246_ecm_graph_detach(&graph, dev);
    }
    ((void (*)(struct r246_usb_device *))0x01a6e60cu)(dev);
}

/* The stock reset-time speed walker assumes the stock descriptor tree.
 * ECM keeps its own descriptors valid at both speeds. The DCD still
 * handles the reset and configures the endpoints from those descriptors. */
void sync_usb_high_speed(struct r246_usb_device *dev)
{
    if (r246_ecm_graph_set_speed(&graph, dev, ECM_BULK_HIGH_SPEED)) {
        rx_packet_bytes = ECM_BULK_HIGH_SPEED;
        publish_state();
    } else {
        ((void (*)(struct r246_usb_device *))0x01a6c774u)(dev);
    }
}

void sync_usb_full_speed(struct r246_usb_device *dev)
{
    if (r246_ecm_graph_set_speed(&graph, dev, ECM_BULK_PACKET)) {
        rx_packet_bytes = ECM_BULK_PACKET;
        publish_state();
    } else {
        ((void (*)(struct r246_usb_device *))0x01a6c788u)(dev);
    }
}

void sync_usb_stop(void)
{
    bool guarded = usb_attached;
    if (guarded) fw_vdk_pend_semaphore(usb_guard, 0);
    if (usb_restart_pending) {
        /* R246's normal stop disables GLOBAL_ENA but leaves USB_POWER's
         * SOFT_CONN set. Drop the pull-up before stopping the controller.
         * The stock start routine reasserts it. */
        ((void (*)(void))0x01a6a6b4u)();
        publish();
    }
    ((void (*)(void))0x01a6c004u)();
    if (guarded) fw_vdk_post_semaphore(usb_guard);
}

static void pump_usb(void)
{
    struct r246_usb_device *dev = graph.attached_device;
    if (!usb_control.configured)
        return;
    if (midi_tx_active && !midi_in.queued && midi_tx.write != midi_tx.read &&
        (midi_in.request || r246_usb_pipe_open(&midi_in, pipes, dev, R246_MIDI_IN,
                                                R246_NATIVE_MIDI_BUFFER))) {
        const uint8_t *bytes;
        /* End every transfer with a short packet at full speed, too. */
        unsigned limit = rx_packet_bytes == ECM_BULK_HIGH_SPEED ?
                         R246_NATIVE_MIDI_BUFFER : ECM_BULK_PACKET - 4;
        unsigned length = r246_midi_tx_peek(&midi_tx, limit, &bytes);
        if (length)
            (void)r246_usb_pipe_submit(&midi_in, pipes, bytes, length);
    }
    if (notice_pending != NO_NOTICE && !notify.queued &&
        (notify.request || r246_usb_pipe_open(&notify, pipes, dev, addresses.interrupt_in,
                                            ECM_SPEED_NOTIFICATION_BYTES))) {
        uint8_t message[ECM_SPEED_NOTIFICATION_BYTES];
        if (notice_pending == CONNECTION_NOTICE) {
            ecm_connection(&usb_control, message);
            if (r246_usb_pipe_submit(&notify, pipes, message, ECM_NOTIFICATION_BYTES))
                notice_pending = SPEED_NOTICE;
        } else {
            ecm_connection_speed(&usb_control, rx_packet_bytes, message);
            if (r246_usb_pipe_submit(&notify, pipes, message, ECM_SPEED_NOTIFICATION_BYTES))
                notice_pending = NO_NOTICE;
        }
    }
    if (!usb_control.data_alt)
        return;
    if (tx.queued)
        return;
    if (tx_zlp) {
        tx_zlp = !r246_usb_pipe_submit(&tx, pipes, NULL, 0);
        return;
    }
    if (outgoing.ready) {
        acquire();
        if (outgoing.generation == (epoch & 0x3fffu)) {
            if (!(tx.request || r246_usb_pipe_open(&tx, pipes, dev, addresses.bulk_in, ECM_MAX_FRAME)) ||
                !r246_usb_pipe_submit(&tx, pipes, outgoing.bytes, outgoing.size))
                return;
            tx_zlp = outgoing.zlp;
        }
        publish();
        outgoing.ready = 0;
        return;
    }
    unsigned read = audio_usb.read;
    const unsigned write = audio_usb.write;
    acquire();
    while (read != write) {
        unsigned index = read % AUDIO_USB_SLOTS;
        unsigned channel = audio_usb.slots[index].channel;
        if ((audio_capture_mask & (1u << channel)) &&
            audio_usb.slots[index].generation == audio_streams[channel].generation) {
            if ((epoch & 0x3fffu) != worker_epoch ||
                !(tx.request || r246_usb_pipe_open(&tx, pipes, dev, addresses.bulk_in, ECM_MAX_FRAME)) ||
                !r246_usb_pipe_submit(&tx, pipes, audio_usb.slots[index].bytes,
                                      audio_usb.slots[index].size))
                return;
            tx_zlp = audio_usb.slots[index].zlp;
            publish();
            audio_usb.read = read + 1;
            return;
        }
        ++read;
    }
    publish();
    audio_usb.read = read;
}

int sync_usb_dispatch(int mode)
{
    bool guarded = usb_attached;
    if (guarded) fw_vdk_pend_semaphore(usb_guard, 0);
    wake_pending = 0;
    int result = ((int (*)(int))0x01a6abacu)(mode);
    unsigned now = cycles_now();
    if (((usb_state & (1u << 16)) || network.registered) &&
        now - last_work_cycles >= 320000u) {
        last_work_cycles = now;
        worker(now);
    }
    if (graph.attached_device)
        pump_usb();
    if (guarded) fw_vdk_post_semaphore(usb_guard);
    return result;
}

static err_t send_frame(void *context, const uint8_t *frame, unsigned bytes, bool zlp)
{
    (void)context;
    /* ARP resolution can release a waiting payload after its original send.
     * Read the wire channel ID rather than relying on caller-local state. */
    if (bytes >= 70 && bytes <= AUDIO_ETH_BYTES && frame[12] == 8 &&
        frame[13] == 0 && frame[14] == 0x45 && frame[23] == 17 &&
        memcmp(frame + 42, "chnnlsv\1", 8) == 0 && frame[50] == LINK_AUDIO_PCM) {
        unsigned channel = 0;
        while (channel < LINK_AUDIO_CHANNELS &&
               memcmp(frame + 62, audio_streams[channel].packetizer.timing.channel_id,
                      LINK_AUDIO_ID_SIZE) != 0)
            ++channel;
        unsigned write = audio_usb.write;
        if (channel == LINK_AUDIO_CHANNELS || !(audio_capture_mask & (1u << channel)))
            return ERR_IF;
        if (!audio_usb_has_room(audio_usb.read, write, 1))
            return ERR_WOULDBLOCK;
        unsigned index = write % AUDIO_USB_SLOTS;
        audio_usb.slots[index].generation = audio_streams[channel].generation;
        audio_usb.slots[index].channel = channel;
        audio_usb.slots[index].size = bytes;
        audio_usb.slots[index].zlp = zlp;
        memcpy(audio_usb.slots[index].bytes, frame, bytes);
        publish();
        audio_usb.write = write + 1;
        return ERR_OK;
    }
    if (outgoing.ready)
        return ERR_WOULDBLOCK;
    memcpy(outgoing.bytes, frame, bytes);
    outgoing.size = bytes;
    outgoing.generation = worker_epoch;
    outgoing.zlp = zlp;
    publish();
    outgoing.ready = 1;
    return ERR_OK;
}

static void receive_frame(void *context, const uint8_t *frame, unsigned length)
{
    struct ecm_link *link = context;
    (void)link_net_rx_frame(&link->iface, frame, (uint16_t)length);
}

static void capture_instrument(int instrument, short *pcm)
{
    if ((unsigned)instrument >= 2 ||
        !(audio_capture_mask & (1u << (LINK_AUDIO_SYNTH + (unsigned)instrument))))
        return;
    memcpy(instrument_pcm[instrument], pcm, AUDIO_FRAMES * sizeof *pcm);
    instrument_ready |= 1u << (unsigned)instrument;
}

static void refresh_tape_clips(int ran)
{
    bool active = (audio_capture_mask >> LINK_AUDIO_TAPE_1) != 0;
    tape_capture_refresh(active, ran, active ? cycles_now() : 0);
}

static void capture_master(short *left, short *right)
{
    const unsigned ready = instrument_ready;
    instrument_ready = 0;
    const unsigned generation = audio_generation;
    const unsigned mask = audio_capture_mask;
    if (!generation || !mask)
        return;
    unsigned sample = captured.next_sample;
    captured.next_sample += AUDIO_FRAMES;
    unsigned write = captured.write;
    if (write - captured.read >= AUDIO_BLOCKS)
        return;
    unsigned index = write % AUDIO_BLOCKS;
    captured.slots[index].generation = generation;
    captured.slots[index].sample = sample;
    captured.slots[index].cycles = cycles_now();
    captured.slots[index].mask = mask;
    for (unsigned channel = 0; channel < LINK_AUDIO_CHANNELS; ++channel)
        captured.slots[index].stream_generation[channel] = audio_streams[channel].generation;
    int16_t *pcm = captured.slots[index].pcm;
    if (mask & (1u << LINK_AUDIO_MASTER)) {
        for (unsigned i = 0; i < AUDIO_FRAMES; ++i) {
            pcm[2 * i] = left[i];
            pcm[2 * i + 1] = right[i];
        }
    }
    for (unsigned instrument = 0; instrument < 2; ++instrument) {
        unsigned channel = LINK_AUDIO_SYNTH + instrument;
        if (!(mask & (1u << channel)))
            continue;
        int16_t *dst = pcm + (channel + 1) * AUDIO_FRAMES;
        if (ready & (1u << instrument))
            memcpy(dst, instrument_pcm[instrument], AUDIO_FRAMES * sizeof *dst);
        else
            memset(dst, 0, AUDIO_FRAMES * sizeof *dst);
    }
    unsigned tape_mask = mask >> LINK_AUDIO_TAPE_1;
    if (tape_mask)
        tape_capture_pcm(tape_mask, pcm + (LINK_AUDIO_TAPE_1 + 1) * AUDIO_FRAMES);
    publish();
    captured.write = write + 1;
}

static void audio_datagram(void *context, const uint8_t *packet, size_t size)
{
    struct audio_stream *stream = context;
    unsigned channel = (unsigned)(stream - audio_streams);
    (void)link_net_audio_send(&network.net, channel, packet, (uint16_t)size);
}

static void stop_capture(void)
{
    if (!audio_generation)
        return;
    audio_capture_mask = 0;
    audio_generation = 0;
    captured.read = captured.write;
    audio_timing.valid = false;
    for (unsigned channel = 0; channel < LINK_AUDIO_CHANNELS; ++channel) {
        audio_streams[channel].subscribers = 0;
        link_audio_packetizer_discard(&audio_streams[channel].packetizer);
    }
}

static void pump_audio(unsigned now_cycles)
{
    struct link_net *net = &network.net;
    link_session *session = &net->session;
    if (audio_session != session->state.session || audio_node != session->state.node) {
        stop_capture();
        audio_session = session->state.session;
    }
    unsigned count = 0, mask = 0;
    for (unsigned channel = 0; channel < LINK_AUDIO_CHANNELS; ++channel) {
        struct audio_stream *stream = &audio_streams[channel];
        unsigned subscribers = link_net_audio_subscribers(net, channel);
        if (!subscribers && stream->subscribers)
            link_audio_packetizer_discard(&stream->packetizer);
        if (subscribers && !stream->subscribers)
            ++stream->generation;
        stream->subscribers = subscribers;
        if (subscribers) mask |= 1u << channel;
        count += subscribers;
    }
    if (!count) {
        stop_capture();
        return;
    }
    uint8_t session_id[LINK_AUDIO_ID_SIZE];
    link_audio_id(session_id, session->state.session);
    if (audio_node != session->state.node) {
        uint8_t node_id[LINK_AUDIO_ID_SIZE];
        audio_node = session->state.node;
        link_audio_id(node_id, audio_node);
        for (unsigned channel = 0; channel < LINK_AUDIO_CHANNELS; ++channel) {
            struct audio_stream *stream = &audio_streams[channel];
            uint8_t channel_id[LINK_AUDIO_ID_SIZE];
            link_audio_id(channel_id, link_audio_channel_id(audio_node, channel));
            link_audio_packetizer_init(&stream->packetizer, node_id, channel_id,
                                       audio_datagram, stream);
            link_audio_packetizer_limit(&stream->packetizer, AUDIO_UDP_BYTES);
        }
    }
    if (!audio_generation) {
        captured.read = captured.write;
        if (!++audio_generation_counter) ++audio_generation_counter;
        publish();
        audio_generation = audio_generation_counter;
    }
    audio_capture_mask = mask;
    unsigned write = captured.write;
    acquire();
    const link_clock *mapping = &session->clock;
    const link_timeline *timeline = &session->state.timeline;
    for (unsigned n = 0; n < 8 && captured.read != write; ++n) {
        /* Wait for USB capacity before consuming any of the captured block. */
        if (!audio_usb_has_room(audio_usb.read, audio_usb.write, count))
            break;
        unsigned read = captured.read;
        unsigned index = read % AUDIO_BLOCKS;
        if (captured.slots[index].generation == audio_generation) {
            unsigned sample = captured.slots[index].sample;
            unsigned elapsed = sample - audio_timing.sample;
            if (!audio_timing.valid || elapsed > 4410000 ||
                audio_timing.timeline.us_per_beat != timeline->us_per_beat ||
                audio_timing.timeline.beat_origin != timeline->beat_origin ||
                audio_timing.timeline.time_origin != timeline->time_origin ||
                audio_timing.clock.host_anchor != mapping->host_anchor ||
                audio_timing.clock.ghost_anchor != mapping->ghost_anchor ||
                audio_timing.clock.rate_ppm != mapping->rate_ppm) {
                int32_t offset_cycles = (int32_t)(captured.slots[index].cycles - now_cycles);
                int64_t host = worker_us + offset_cycles / 400;
                int64_t ghost;
                audio_timing.valid = link_clock_ghost_at(mapping, host, &ghost) &&
                    link_timeline_beat_at(timeline, ghost, &audio_timing.beat);
                audio_timing.sample = sample;
                audio_timing.timeline = *timeline;
                audio_timing.clock = *mapping;
                audio_timing.period = timeline->us_per_beat;
                elapsed = 0;
            }
            if (audio_timing.valid) {
                uint64_t denominator = (uint64_t)audio_timing.period * LINK_AUDIO_OP1_SAMPLE_RATE;
                int64_t beat = audio_timing.beat + (int64_t)
                    (((uint64_t)elapsed * UINT64_C(1000000000000) + denominator / 2) / denominator);
                unsigned sources = captured.slots[index].mask & mask;
                for (unsigned channel = 0; channel < LINK_AUDIO_CHANNELS; ++channel) {
                    if (!(sources & (1u << channel)) ||
                        captured.slots[index].stream_generation[channel] !=
                        audio_streams[channel].generation)
                        continue;
                    bool stereo = channel == LINK_AUDIO_MASTER;
                    const int16_t *pcm = captured.slots[index].pcm +
                        (stereo ? 0 : (channel + 1) * AUDIO_FRAMES);
                    (void)link_audio_packetizer_add(&audio_streams[channel].packetizer,
                        pcm, AUDIO_FRAMES, stereo ? 2 : 1, LINK_AUDIO_OP1_SAMPLE_RATE,
                        session_id, beat, audio_timing.period);
                }
            }
        }
        publish();
        captured.read = read + 1;
    }
}

static void worker(unsigned now)
{
    unsigned delta = now - last_cycles;
    last_cycles = now;
    worker_us += delta / 400;
    fraction += delta % 400;
    if (fraction >= 400) {
        ++worker_us;
        fraction -= 400;
    }

    unsigned state = usb_state;
    unsigned generation = state >> 18;
    bool active = (state & (1u << 16)) && sync_network_requested();
    if (network.registered && (!active || generation != worker_epoch)) {
        stop_capture();
        ecm_link_close(&network);
        clock = (struct link_midi_clock){0};
        if (link_playing) sync_link_transport(0xfc);
        link_playing = false;
    }
    if (active && !network.registered &&
        ecm_link_open(&network, (state & (1u << 17)) ? ECM_BULK_HIGH_SPEED : ECM_BULK_PACKET,
                      device_mac, host_mac, ++node, 500000, send_frame, NULL) == ERR_OK) {
        worker_epoch = generation;
        (void)ecm_link_alt(&network, 1);
    }
    if (network.registered) {
        network.net.now_us = worker_us;
        network.port.control.packet_filter = (uint16_t)state;
    }
    network_open = network.registered;
    ecm_rx_queue_drain(&incoming, generation, network.registered ? receive_frame : NULL, &network);
    if (!network.registered) {
        sync_link_tempo_period(0);
        return;
    }
    ecm_link_poll(&network, worker_us);
    link_net_audio_configure(&network.net, audio_enabled);
    link_net_audio_poll(&network.net);
    link_session *session = &network.net.session;
    unsigned peers = link_session_peer_count(session);
    const unsigned period = peers ? (unsigned)session->state.timeline.us_per_beat : 0;
    bool follow_link = sync_link_requested() != 0;
    unsigned activation = sync_link_activation();
    if (follow_link && activation != clock_activation) {
        clock_activation = activation;
        clock = (struct link_midi_clock){0};
        link_playing = false;
    }
    sync_link_tempo_period(follow_link ? period : 0);
    session->transport_sync = follow_link && transport_enabled;
    bool playing = session->transport_sync && peers &&
                   session->state.playing;
    if (playing != link_playing) {
        sync_link_transport(playing ? 0xfa : 0xfc);
        link_playing = playing;
    }
    if (follow_link) {
        if (link_midi_clock_poll(&clock, session, worker_us))
            sync_link_clock_tick();
    } else if (clock.armed) {
        clock = (struct link_midi_clock){0};
    }
    pump_audio(now);
}

enum { USB_SETTING_SETTLE_MS = 80, USB_DISCONNECT_MS = 500, USB_START_LIMIT = 3 };
static unsigned usb_start_attempts;
static void reconcile_usb(void);

static struct r246_usb_device *current_usb_device(void)
{
    return *(struct r246_usb_device *volatile *)0x018c1e94u;
}

static void restart_usb(void)
{
    /* The OS may have installed a different USB function while we waited. */
    if (current_usb_device() || ((int (*)(void))0x01a6ed54u)() ||
        current_usb_device() || ++usb_start_attempts >= USB_START_LIMIT) {
        usb_restart_pending = false;
        /* The settings may have changed while USB was disconnected. */
        reconcile_usb();
        return;
    }
    opus_key_timer(plugin, USB_DISCONNECT_MS, restart_usb);
}

/* Both halves of a switch run on KeyHandler, alongside stock Disk/normal
 * changes. Allow the host to observe removal before reconnecting. */
static void reconcile_usb(void)
{
    static int requested_last = -1;
    if (usb_restart_pending)
        return;
    struct r246_usb_device *dev = current_usb_device();
    if (!dev)
        return;
    bool composite = dev->function == &graph.function;
    if (!composite && (uintptr_t)dev->function != 0x018c1ddcu)
        return;
    /* Preserve the enumerated MIDI port while using MIDI or Pulse clock.
     * The network worker stops independently of the USB graph. */
    bool keep_composite = composite && (sync_midi_requested() || sync_pulse_requested());
    bool requested = sync_network_requested() || keep_composite;
    if (requested == composite) {
        requested_last = -1;
        return;
    }
    if (requested_last == (int)requested)
        return;
    requested_last = requested;
    usb_restart_pending = true;
    usb_start_attempts = 0;
    ((void (*)(void))0x01a6ee0cu)();
    opus_key_timer(plugin, USB_DISCONNECT_MS, restart_usb);
}

static void reconcile_usb_after_key(int key, int pressed)
{
    (void)key;
    if (!pressed)
        reconcile_usb();
}

void sync_device_setting(void)
{
    if (plugin) {
        transport_enabled = (unsigned)opus_setting(plugin, "link_transport");
        unsigned tx = (unsigned)opus_setting(plugin, "link_audio_tx");
        unsigned enabled = ((tx & TX_MASTER) << LINK_AUDIO_MASTER) |
            ((unsigned)opus_setting(plugin, "link_synth_tx") << LINK_AUDIO_SYNTH) |
            ((unsigned)opus_setting(plugin, "link_drum_tx") << LINK_AUDIO_DRUM);
        if (tape_supported && (tx & TX_TAPE))
            enabled |= TAPE_TRACK_MASK << LINK_AUDIO_TAPE_1;
        link_audio_on = opus_setting(plugin, "link_audio") != 0;
        audio_enabled = link_audio_on ? enabled : 0;
        if (!usb_restart_pending)
            opus_key_timer(plugin, USB_SETTING_SETTLE_MS, reconcile_usb);
    }
}

int sync_device_init(struct opl_self *self)
{
    usb_guard = fw_vdk_create_semaphore(1, 1, 0, 0);
    if (usb_guard < 0)
        return -1;
    plugin = self;
    tape_supported = tape_capture_supported();
    sync_device_setting();
    random_state = cycles_now() | 1u;
    uint32_t first = sync_net_random(), second = sync_net_random();
    node = ((uint64_t)first << 32) | second;
    for (unsigned i = 0; i < 3; ++i) {
        host_mac[2 + i] = (uint8_t)(first >> (i * 8));
        device_mac[2 + i] = host_mac[2 + i];
    }
    last_cycles = cycles_now();
    last_work_cycles = last_cycles;
    lwip_init();
    opus_on_main_pass(self, wake_from_main);
    if (tape_supported)
        opus_on_queue_after(self, refresh_tape_clips);
    opus_on_post_master(self, capture_master);
    opus_on_post_fx(self, capture_instrument);
    opus_on_key_after(self, reconcile_usb_after_key);
    return 0;
}
