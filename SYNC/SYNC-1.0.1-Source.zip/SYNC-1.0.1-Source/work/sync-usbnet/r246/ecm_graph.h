/* SPDX-License-Identifier: GPL-3.0-or-later */
#ifndef ESC_R246_ECM_GRAPH_H
#define ESC_R246_ECM_GRAPH_H

#include <stdbool.h>
#include "ecm.h"

struct r246_usb_request;
struct r246_usb_device;

struct r246_usb_callbacks {
    int (*event)(struct r246_usb_device *device, int event);
    int (*in_done)(struct r246_usb_request *request);
    int (*out_done)(struct r246_usb_request *request);
    int (*setup)(struct r246_usb_request *ep0);
};

struct r246_usb_alternate {
    uint8_t *descriptor;
    uint32_t class_count;
    uint8_t **class_descriptors;
    uint32_t endpoint_count;
    uint8_t **endpoints;
};

struct r246_usb_interface {
    uint32_t alternate_count;
    struct r246_usb_alternate *alternates;
};

struct r246_usb_configuration {
    uint32_t interface_count;
    uint8_t *descriptor;
    struct r246_usb_interface *interfaces;
    uint32_t reserved;
};

struct r246_usb_function {
    uint32_t reserved;
    const struct r246_usb_callbacks *callbacks;
    const void *device_source;
    const void *configuration_source;
    uint8_t *device_descriptor;
    struct r246_usb_configuration *configurations;
    uint32_t configuration_count;
    uint8_t *qualifier;
};

/* Prefix only. smxUSBD owns the rest of the 36-byte object. */
struct r246_usb_device {
    void *dcd;
    struct r246_usb_function *function;
};

enum {
    R246_ECM_MAC_STRING_BYTES = 26,
    R246_COMPOSITE_MAX_BYTES = 320,
    R246_ECM_INTERRUPT_IN = 0x83,
    R246_NATIVE_MIDI_OUT = 0x04,
    R246_NATIVE_MIDI_IN = 0x83,
    R246_MIDI_OUT = 0x07,
    R246_MIDI_IN = 0x87,
    R246_NATIVE_MIDI_BUFFER = 128,
    R246_MIDI_INTERFACE = 3,
    R246_ECM_BULK_OUT = 0x05,
    R246_ECM_BULK_IN = 0x86,
};

/* Fixed-address storage. Once prepared it must not be moved or copied. */
struct r246_ecm_graph {
    struct r246_usb_function function;
    struct r246_usb_configuration configuration;
    struct r246_usb_interface interfaces[4];
    struct r246_usb_alternate midi_control;
    uint8_t *midi_control_classes[1];
    uint8_t midi_control_descriptor[9];
    uint8_t midi_control_header[9];
    const uint8_t *midi_jacks[2];
    struct r246_usb_alternate midi_streaming;
    uint8_t *midi_endpoints[2];
    uint8_t midi_endpoint_desc[2][9];
    uint8_t composite_wire[R246_COMPOSITE_MAX_BYTES];
    unsigned composite_size, composite_bulk_bytes;
    struct r246_usb_alternate control;
    struct r246_usb_alternate data[2];
    uint8_t *class_descriptors[3];
    uint8_t *control_endpoints[1];
    uint8_t *data_endpoints[2];
    uint8_t device_descriptor[18];
    uint8_t qualifier[10];
    uint8_t mac_string[R246_ECM_MAC_STRING_BYTES];
    uint8_t descriptors[ECM_CONFIG_BYTES];
    struct r246_usb_device *attached_device;
    struct r246_usb_function *stock_function;
};

/* Prepare for one ECM function, with the MAC exposed as a USB string by
 * the caller. The stock function supplies the device and qualifier
 * descriptors. Zero-initialize the graph before first use. No stock descriptor or callback table is modified. */
bool r246_ecm_graph_prepare(struct r246_ecm_graph *graph,
                            struct r246_usb_function *stock,
                            const struct r246_usb_callbacks *callbacks,
                            struct ecm_endpoints endpoints, unsigned packet_bytes,
                            uint8_t mac_index, const uint8_t mac[6]);

/* Use in the USB/device lifecycle only. Attach before DCD enable. Detach
 * after DCD disable and before smxUSBD destroys its original object graph.
 * The caller serializes both with SETUP, completion and reset dispatch. */
/* Add the verified stock MIDI streaming interface before attaching the graph.
 * AudioControl here groups MIDI only. The stock audio streaming endpoints are absent. */
bool r246_ecm_graph_add_midi(struct r246_ecm_graph *graph);
const uint8_t *r246_ecm_graph_wire(struct r246_ecm_graph *graph, bool other,
                                  unsigned *size);

bool r246_ecm_graph_attach(struct r246_ecm_graph *graph, struct r246_usb_device *device);
/* Handles the reset's speed selection only while the ECM function owns dev. */
bool r246_ecm_graph_set_speed(struct r246_ecm_graph *graph, struct r246_usb_device *dev,
                             unsigned packet_bytes);
bool r246_ecm_graph_detach(struct r246_ecm_graph *graph, struct r246_usb_device *device);

#endif
