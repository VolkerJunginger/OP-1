/* SPDX-License-Identifier: GPL-3.0-or-later */
#ifndef ESC_SYNC_R246_AUDIO_USB_H
#define ESC_SYNC_R246_AUDIO_USB_H

#include "ecm_bulk.h"
#include "link_audio_control.h"
#include "link_session.h"

enum {
    AUDIO_FRAMES = 64,
    AUDIO_USB_SLOTS = 64,
    AUDIO_ETH_BYTES = ECM_BULK_HIGH_SPEED - 1,
    AUDIO_UDP_BYTES = AUDIO_ETH_BYTES - 42 /* Ethernet, IPv4 and UDP headers. */
};

/* A block fits in a fresh datagram with room to spare, even in stereo.
 * Each packetizer can therefore emit at most once per block, including
 * when a timing change flushes its previous partial datagram. */
_Static_assert(LINK_AUDIO_FIRST_CHUNK_BYTES + AUDIO_FRAMES * 2 * sizeof(int16_t) < AUDIO_UDP_BYTES,
               "A fresh datagram must hold more than one stereo block");
_Static_assert(AUDIO_USB_SLOTS >= LINK_AUDIO_CHANNELS * LINK_MAX_PEERS,
               "The queue must hold one full block's subscriber fan-out");

static inline bool audio_usb_has_room(unsigned read, unsigned write, unsigned datagrams)
{
    return datagrams <= AUDIO_USB_SLOTS && write - read <= AUDIO_USB_SLOTS - datagrams;
}

#endif
