/* SPDX-License-Identifier: GPL-3.0-or-later */
#ifndef ESC_LINK_MIDI_CLOCK_H
#define ESC_LINK_MIDI_CLOCK_H

#include "link_session.h"

struct link_midi_clock {
    uint64_t session_id;
    int64_t last_tick;
    bool armed;
};

/* Worker-side timeline sampling. Emits at most one MIDI Clock per call.
 * A missed interval is skipped rather than replayed in a burst. The
 * caller owns mode changes and must clear the clock on source changes. */
bool link_midi_clock_poll(struct link_midi_clock *clock,
                          const link_session *session, int64_t host_us);
#endif
