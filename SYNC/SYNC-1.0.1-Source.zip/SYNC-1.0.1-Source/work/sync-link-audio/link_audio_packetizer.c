/* SPDX-License-Identifier: GPL-2.0-or-later
 * Based on Ableton Link 4.1.1 (original C++ code copyright 2025 Ableton AG, Berlin).
 */
#include "link_audio_packetizer.h"

enum { EXTRA_CHUNK_BYTES = 26 };

static void copy_id(uint8_t *out, const uint8_t *in)
{
    for (unsigned i = 0; i < LINK_AUDIO_ID_SIZE; ++i)
        out[i] = in[i];
}

static int ids_match(const uint8_t *first, const uint8_t *second)
{
    for (unsigned i = 0; i < LINK_AUDIO_ID_SIZE; ++i) {
        if (first[i] != second[i])
            return 0;
    }
    return 1;
}

static int64_t chunk_end(const LinkAudioChunk *chunk, uint32_t sample_rate)
{
    /* Frames / rate gives seconds. One beat is micros_per_beat / 1e6
       seconds, and the timeline is represented in millionths of a beat. */
    uint64_t numerator = chunk->frames * UINT64_C(1000000000000);
    uint64_t tempo = (uint64_t)chunk->micros_per_beat;
    if (tempo > UINT64_MAX / sample_rate)
        return chunk->begin_microbeats;
    uint64_t denominator = tempo * sample_rate;
    uint64_t elapsed = numerator / denominator;
    if (numerator % denominator >= denominator / 2 + denominator % 2)
        ++elapsed;
    int64_t delta = (int64_t)elapsed;
    if (chunk->begin_microbeats > INT64_MAX - delta)
        return INT64_MAX;
    return chunk->begin_microbeats + delta;
}

static int is_continuous(int64_t end, int64_t begin)
{
    if (end > begin)
        return end - 1 == begin;
    if (begin > end)
        return begin - 1 == end;
    return 1;
}

void link_audio_packetizer_discard(LinkAudioPacketizer *state)
{
    state->sample_count = 0;
    state->timing.chunk_count = 0;
}

void link_audio_packetizer_init(LinkAudioPacketizer *state,
                                const uint8_t node[LINK_AUDIO_ID_SIZE],
                                const uint8_t channel[LINK_AUDIO_ID_SIZE],
                                LinkAudioSend send, void *context)
{
    link_audio_packetizer_discard(state);
    state->next_count = 0;
    state->sample_budget = LINK_AUDIO_TX_MAX_SAMPLES;
    state->send = send;
    state->context = context;
    copy_id(state->timing.node_id, node);
    copy_id(state->timing.channel_id, channel);
}

void link_audio_packetizer_limit(LinkAudioPacketizer *state, size_t packet_bytes)
{
    if (!state->sample_count && packet_bytes >= LINK_AUDIO_FIRST_CHUNK_BYTES + 4 &&
        packet_bytes <= LINK_AUDIO_TX_MAX_PACKET)
        state->sample_budget = (packet_bytes - LINK_AUDIO_FIRST_CHUNK_BYTES) / 2;
}

static void emit(LinkAudioPacketizer *state)
{
    size_t size = link_audio_encode(state->packet, sizeof(state->packet),
                                    &state->timing, state->samples, state->sample_count);
    if (size)
        state->send(state->context, state->packet, size);
    link_audio_packetizer_discard(state);
}

static LinkAudioChunk *start_chunk(LinkAudioPacketizer *state,
                                   int64_t begin_microbeats, int64_t micros_per_beat)
{
    LinkAudioTiming *timing = &state->timing;
    size_t required = (state->sample_count + timing->channels) * 2
                      + timing->chunk_count * EXTRA_CHUNK_BYTES;
    if (required > state->sample_budget * 2)
        emit(state);

    LinkAudioChunk *chunk = &timing->chunks[timing->chunk_count++];
    chunk->count = ++state->next_count;
    chunk->frames = 0;
    chunk->begin_microbeats = begin_microbeats;
    chunk->micros_per_beat = micros_per_beat;
    return chunk;
}

int link_audio_packetizer_add(LinkAudioPacketizer *state, const int16_t *samples,
                              size_t frames, uint8_t channels, uint32_t sample_rate,
                              const uint8_t session[LINK_AUDIO_ID_SIZE],
                              int64_t begin_microbeats, int64_t micros_per_beat)
{
    if (!state || !state->send || !session || (frames && !samples)
        || channels < 1 || channels > 2 || sample_rate == 0
        || micros_per_beat <= 0 || frames > SIZE_MAX / channels)
        return 0;
    LinkAudioTiming *timing = &state->timing;
    if (state->sample_count != 0
        && (timing->channels != channels || timing->sample_rate != sample_rate
            || !ids_match(timing->session_id, session)))
        emit(state);
    if (frames == 0)
        return 1;

    LinkAudioChunk *chunk;
    if (timing->chunk_count == 0) {
        timing->channels = channels;
        timing->sample_rate = sample_rate;
        copy_id(timing->session_id, session);
        chunk = start_chunk(state, begin_microbeats, micros_per_beat);
    } else {
        chunk = &timing->chunks[timing->chunk_count - 1];
        if (chunk->micros_per_beat != micros_per_beat
            || !is_continuous(chunk_end(chunk, sample_rate), begin_microbeats))
            chunk = start_chunk(state, begin_microbeats, micros_per_beat);
    }

    while (frames != 0) {
        size_t allowed = (state->sample_budget
                         - (timing->chunk_count - 1) * (EXTRA_CHUNK_BYTES / 2))
                         / channels;
        size_t available = allowed - state->sample_count / channels;
        size_t copied = frames < available ? frames : available;
        for (size_t i = 0; i < copied * channels; ++i)
            state->samples[state->sample_count + i] = samples[i];
        state->sample_count += copied * channels;
        chunk->frames = (uint16_t)(chunk->frames + copied);
        samples += copied * channels;
        frames -= copied;

        if (copied == available) {
            int64_t next = chunk_end(chunk, sample_rate);
            emit(state);
            if (frames != 0)
                chunk = start_chunk(state, next, micros_per_beat);
        }
    }
    return 1;
}
