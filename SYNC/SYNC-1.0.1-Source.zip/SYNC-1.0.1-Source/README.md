# Building SYNC 1.0.1

This archive contains the corresponding source and build scripts for the distributed SYNC 1.0.1 OP-1 mod. Its embedded version is 1.0.1.

Use Python 3.8 or later and a Blackfin ELF toolchain with `bfin-elf-gcc` and binutils. If the kit cannot find the compiler, set `OP1_BFIN_TOOLCHAIN` to the directory containing its `bin` directory.

From this directory, run:

```sh
sh work/sync-usbnet/r246/build.sh vendor/lwip/src "$PWD/SYNC.opmod"
```

This compiles the C and assembly sources with the bundled Opus kit and selected lwIP 2.2.1 modules, produces a standalone mod, then displays its manifest. Run `sh work/sync-usbnet/r246/test.sh` for the USB, Link Audio transmit queue and Tape rendering host checks. See the Link Core and Link Audio source notes for their upstream reference tests.

The release mod's SHA-256 is `10ca69689d571051b4768d6a3b30815596cedb568f60a1b387e7bdcd90529f80`.

See THIRD_PARTY_NOTICES.md, LICENSE, the Opus kit README, and the upstream license files under vendor.
