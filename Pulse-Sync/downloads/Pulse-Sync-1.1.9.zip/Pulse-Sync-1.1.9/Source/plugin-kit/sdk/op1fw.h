/* op1fw.h for an Opus 2 plugin: the OP-1 firmware (#246) functions a plugin can call by name.
 * Each is declared by name only: the plugin imports it, and Opus gives its address when it loads the
 * plugin. Arguments go in R0-R2, the rest on the stack from [SP + 12], as GCC passes them. */
#ifndef OP1FW_H
#define OP1FW_H

/* fw_bind: Screen.cpp bind, 0x01A3B5D0. A page's named element -> its handle (for
 * fw_set_text). name: a string from the page's own name table (e.g. 0x018F2F4C); align 0 as
 * the play-mode page uses it. */
typedef void *fw_bind_t(void *page, const char *name, int align);
extern fw_bind_t fw_bind;

/* fw_heap_malloc: heap_malloc: the C runtime's heap N (0 the low SDRAM heap, bank 0; 1 the
 * samplers', full by design), 0x01AA0318. The C heaps' one lock (a VDK unscheduled region:
 * thread level only; from an interrupt it stops the OS), first fit from the heap's rover, else
 * its top grows (never down); 0 when it does not fit, no message. Under Opus heap 0 ends at
 * 0x00E00000 (sqlitemem.hooks). Opus's bank 0 arena (loader.c, 2026-11-05). */
typedef void *fw_heap_malloc_t(int heap, unsigned bytes);
extern fw_heap_malloc_t fw_heap_malloc;

/* fw_remove_node: Screen.cpp removeNode, 0x01A3B7D0. Removes a page's named element; asserts
 * (Screen.cpp:154-166) when the page or the element is missing. Return value not established. */
typedef void fw_remove_node_t(void *page, const char *name);
extern fw_remove_node_t fw_remove_node;

/* fw_set_text: setText, 0x01A61AAC. Sets an element's text; the handle from fw_bind. */
typedef void fw_set_text_t(void *handle, const char *text);
extern fw_set_text_t fw_set_text;

/* fw_snprintf: snprintf (the runtime library), 0x01A9CE04. The fourth argument on is on the
 * stack from [SP + 12], as GCC passes it. */
typedef int fw_snprintf_t(char *dst, unsigned int size, const char *fmt, ...);
extern fw_snprintf_t fw_snprintf;

/* fw_usb_configured: the USB-configured check, 0x01A69360. Nonzero once the computer has
 * configured the OP-1's USB (it returns [0x01DFE03C]). */
typedef int fw_usb_configured_t(void);
extern fw_usb_configured_t fw_usb_configured;

/* fw_midi_send: USB MIDI out, 0x019E0D18. Queues count 4-byte USB-MIDI packets for the
 * computer; the first argument is ignored. packets must be 4-byte aligned (it copies with
 * 32-bit loads). Dropped whole if the out ring has no room. Call fw_usb_configured first. */
typedef void fw_midi_send_t(int unused, const unsigned int *packets, int count);
extern fw_midi_send_t fw_midi_send;

/* fw_ui_dispatch: ui_dispatch (KeyHandler), 0x019B6C74. Sends a key event to the current
 * screen's controller. The KeyHandler thread calls it from 0x019C2D3E; a mod that wraps that
 * call forwards the events it does not take. */
typedef void fw_ui_dispatch_t(int key, int pressed);
extern fw_ui_dispatch_t fw_ui_dispatch;

/* fw_knob_dispatch: the knob router (KeyHandler), 0x019B6C0C. Called from 0x019C2E94. */
typedef void fw_knob_dispatch_t(int index, short *delta);
extern fw_knob_dispatch_t fw_knob_dispatch;

/* fw_render: the display thread's render, 0x019B2674. Draws the whole frame into buf (RGB565,
 * rows 512 bytes apart). Called from 0x019AB8B2; a wrapper may draw over buf after it returns. */
typedef void fw_render_t(unsigned short *buf);
extern fw_render_t fw_render;

/* fw_shift_held: shift state, 0x019D7C6C. Nonzero while shift is held (B[0x01DD7F78]). */
typedef int fw_shift_held_t(void);
extern fw_shift_held_t fw_shift_held;

/* fw_tape_db: the tape database, 0x0196DD50. The handle fw_bg_save takes for tape.db. */
typedef void *fw_tape_db_t(void);
extern fw_tape_db_t fw_tape_db;

/* fw_bg_save: bg_saver, 0x019410C8. Queues one SQL statement for the saver thread (copies the
 * text). Thread context only: it may wait. The queue holds 128; queue a few statements per
 * action, never hundreds. */
typedef void fw_bg_save_t(void *db, const char *sql);
extern fw_bg_save_t fw_bg_save;

/* fw_loop_start: the tape loop start, 0x01A53DA0. In samples ([0x01B4EF34]). */
typedef int fw_loop_start_t(void);
extern fw_loop_start_t fw_loop_start;

/* fw_loop_end: the tape loop end, 0x01A53D88. In samples ([0x01B4EF38]). */
typedef int fw_loop_end_t(void);
extern fw_loop_end_t fw_loop_end;

/* fw_set_loop_start: the tape loop start setter, 0x01A550A8. pos 0..0xF23FA0 (asserts
 * outside). Follow with fw_save_arm(0x01B5FF90) and fw_tape_loop_changed(). */
typedef void fw_set_loop_start_t(int pos);
extern fw_set_loop_start_t fw_set_loop_start;

/* fw_set_loop_end: the tape loop end setter, 0x01A55100. pos 0..0xF23FA0 (asserts outside),
 * clamped to 0xF23F90. Follow with fw_save_arm(0x01B5FF90) and fw_tape_loop_changed(). */
typedef void fw_set_loop_end_t(int pos);
extern fw_set_loop_end_t fw_set_loop_end;

/* fw_save_arm: save later, 0x0193EF3C. Asks the saver to write a controller's state soon. The
 * tape's flags are at 0x01B5FF90 (the tape controller 0x01B5FF88 + 8): the loop points and
 * position. */
typedef void fw_save_arm_t(void *flags);
extern fw_save_arm_t fw_save_arm;

/* fw_tape_loop_changed: the tape screen redraws the loop marks, 0x01A59B10. Sets B[0x01B6039C]
 * = 1 (the stock handlers call it after every loop change; it returns 1). */
typedef void fw_tape_loop_changed_t(void);
extern fw_tape_loop_changed_t fw_tape_loop_changed;

/* fw_yaffs_open: yaffs_open, 0x01A997F4. Path "/yaffs2/...". oflag: O_RDWR 2, O_CREAT 0x40,
 * O_TRUNC 0x200; mode 0x180. Returns a handle, or -1. Thread context only (a global lock). */
typedef int fw_yaffs_open_t(const char *path, int oflag, int mode);
extern fw_yaffs_open_t fw_yaffs_open;

/* fw_yaffs_close: yaffs_close, 0x01A99908. Thread context only. */
typedef int fw_yaffs_close_t(int fd);
extern fw_yaffs_close_t fw_yaffs_close;

/* fw_yaffs_read: yaffs_read, 0x01A99C90. Reads at the file position and moves it; returns the
 * bytes read. Not on the tape fd outside OP_Main: use fw_yaffs_pread. */
typedef int fw_yaffs_read_t(int fd, void *buf, unsigned int n);
extern fw_yaffs_read_t fw_yaffs_read;

/* fw_yaffs_pread: yaffs_pread, 0x01A99CA8. Reads at off; the file position is left alone.
 * Thread context only. */
typedef int fw_yaffs_pread_t(int fd, void *buf, unsigned int n, int off);
extern fw_yaffs_pread_t fw_yaffs_pread;

/* fw_yaffs_write: yaffs_write, 0x01A99F84. Writes at the file position and moves it; returns
 * the bytes written. Every tape audio write comes through here. */
typedef int fw_yaffs_write_t(int fd, const void *buf, unsigned int n);
extern fw_yaffs_write_t fw_yaffs_write;

/* fw_yaffs_pwrite: yaffs_pwrite, 0x01A99F9C. Writes at off; the file position is left alone.
 * Thread context only. */
typedef int fw_yaffs_pwrite_t(int fd, const void *buf, unsigned int n, int off);
extern fw_yaffs_pwrite_t fw_yaffs_pwrite;

/* fw_yaffs_lseek: yaffs_lseek, 0x01A9A0E4. whence 0 set, 1 current, 2 end; returns the new
 * position (fw_yaffs_lseek(fd, 0, 1) reads it without moving it). */
typedef int fw_yaffs_lseek_t(int fd, int off, int whence);
extern fw_yaffs_lseek_t fw_yaffs_lseek;

/* fw_yaffs_unlink: yaffs_unlink, 0x01A9A3FC. Deletes a file. Thread context only. */
typedef int fw_yaffs_unlink_t(const char *path);
extern fw_yaffs_unlink_t fw_yaffs_unlink;

/* fw_tape_invalidate: tape cache invalidate, 0x01A540C0. Makes the engine re-read the tape
 * samples [start, stop] (all tracks) after their audio changed in the file. Skips a stale
 * line. */
typedef void fw_tape_invalidate_t(int start, int stop);
extern fw_tape_invalidate_t fw_tape_invalidate;

/* fw_clip_queue_run: clip_queue_run (OP_Main), 0x0191B560. Runs the next queued clip command
 * (lift, drop, all-track lift and drop, tape clear, sampler copies); returns 1 if it ran one
 * (OP_Main uses the result). OP_Main calls it once per pass from 0x019F0A2A. */
typedef int fw_clip_queue_run_t(void);
extern fw_clip_queue_run_t fw_clip_queue_run;

/* fw_clips_add: Clips::add, 0x0195CCEC. Adds clip {ch, start, stop} to the table at 0x01AA8D70
 * in the lowest free id and returns it (-1 when full); its overlap resolver trims or removes
 * clips it covers, and it queues the SQL itself. Keep 0 <= ch < 4, start < stop, stop - start
 * >= the minimum length [0x01AA7360], stop <= 0xF23FA0 (Clip::set asserts them). OP_Main
 * thread (it may wait in bg_save). */
typedef int fw_clips_add_t(void *clips, const int *clip);
extern fw_clips_add_t fw_clips_add;

/* fw_clips_remove: Clips::remove, 0x0195D5F8. Removes clip id from the table at 0x01AA8D70:
 * clears its slot, frees the id, queues the DELETE, writes 0xFF900504. OP_Main thread. */
typedef void fw_clips_remove_t(void *clips, int id);
extern fw_clips_remove_t fw_clips_remove;

/* fw_text_new: Text.cpp constructor, 0x01A61904. Builds a Text object in mem (0xA4 bytes, word
 * aligned) and returns it: x in 22.10 fixed point, y and size in the 320 x 160 drawing's units
 * (the panel's scale is applied inside), rgba = 4 bytes (a palette entry), align 0 left, 1
 * centre. Fill it with fw_set_text, draw it with fw_text_draw. */
typedef void *fw_text_new_t(void *mem, int x_q10, int y, int size, const unsigned char *rgba, int align);
extern fw_text_new_t fw_text_new;

/* fw_text_draw: Text.cpp draw, 0x01A6259C. Draws a Text object through raster
 * (fw_screen_raster()) with a 3 x 3 22.10 matrix (the identity at 0x01B60FD8). Display thread,
 * after the frame is attached (render, or fw_raster_begin). */
typedef void fw_text_draw_t(void *text, void *raster, const int *matrix);
extern fw_text_draw_t fw_text_draw;

/* fw_screen_raster: Screen.cpp raster getter, 0x01A3B490. The raster screens draw through
 * ([0x01DF4E34]). */
typedef void *fw_screen_raster_t(void);
extern fw_screen_raster_t fw_screen_raster;

/* fw_raster_begin: Raster.cpp attach, 0x01A23442. Points the raster at a frame (render does it
 * with *(void **)0x01DCE8CC and the frame it was given); a mod that draws a whole page instead
 * of calling fw_render calls it first, then clears the frame itself. */
typedef void fw_raster_begin_t(void *raster, unsigned short *buf);
extern fw_raster_begin_t fw_raster_begin;

/* fw_svg_load: Parser.cpp load, 0x019FB458. Parses /yaffs2/content/display/<name>
 * ("../../mod/x.svg" reaches /yaffs2/mod) and returns the document. Asserts (crash screen) on
 * a missing file or a parse error: check with fw_yaffs_access first. Thread context; allocates
 * from the TE pool. */
typedef void *fw_svg_load_t(const char *name);
extern fw_svg_load_t fw_svg_load;

/* fw_screen_draw: Screen.cpp draw, 0x01A3B4C8. Draws screen[0], a document, through
 * fw_screen_raster(). A mod passes a fake screen {doc, 0, 0, 0x01911474}. */
typedef void fw_screen_draw_t(void *screen);
extern fw_screen_draw_t fw_screen_draw;

/* fw_yaffs_mkdir: yaffsfs.c yaffs_mkdir, 0x01A9A886. 0, or -1 when it exists or cannot be
 * made. The OS passes mode 0 (db2) or 0x4180 (tar). Thread context. */
typedef int fw_yaffs_mkdir_t(const char *path, int mode);
extern fw_yaffs_mkdir_t fw_yaffs_mkdir;

/* fw_yaffs_rmdir: yaffsfs.c yaffs_rmdir, 0x01A9AAD0. Removes an empty folder: 0, or -1 (not
 * there, not empty, not a folder). Thread context. */
typedef int fw_yaffs_rmdir_t(const char *path);
extern fw_yaffs_rmdir_t fw_yaffs_rmdir;

/* fw_yaffs_access: yaffsfs.c yaffs_access, 0x01A9A6B0. 0 when the path exists (amode 0), else
 * -1; ".." is resolved. Thread context. */
typedef int fw_yaffs_access_t(const char *path, int amode);
extern fw_yaffs_access_t fw_yaffs_access;

/* fw_yaffs_stat: yaffsfs.c yaffs_stat, 0x01A9A688. st: 13 words; mode in word 2 (0x4000
 * folder, 0x8000 file), size in word 7. 0 or -1. Thread context. */
typedef int fw_yaffs_stat_t(const char *path, unsigned *st);
extern fw_yaffs_stat_t fw_yaffs_stat;

/* fw_yaffs_freespace: yaffsfs.c yaffs_freespace, 0x01A9B1C0. Free bytes on the device holding
 * path ("/yaffs2"). Takes the yaffs lock: not from the display thread. */
typedef unsigned fw_yaffs_freespace_t(const char *path);
extern fw_yaffs_freespace_t fw_yaffs_freespace;

/* fw_bend_down: VoiceCtl bend down pressed, 0x01A86074. Sets the stock rate -32, the left held
 * flag and the live flag; returns the rate. KeyHandler thread. */
typedef int fw_bend_down_t(void);
extern fw_bend_down_t fw_bend_down;

/* fw_bend_up: VoiceCtl bend up pressed, 0x01A86098. Sets the stock rate +64, the right held
 * flag and the live flag; returns the rate. */
typedef int fw_bend_up_t(void);
extern fw_bend_up_t fw_bend_up;

/* fw_bend_release_left: VoiceCtl left released, 0x01A85F98. Clears the left held flag; right
 * still held: rate +64, else 0; live = 1; returns 1. */
typedef int fw_bend_release_left_t(void);
extern fw_bend_release_left_t fw_bend_release_left;

/* fw_bend_release_right: VoiceCtl right released, 0x01A86004. Clears the right held flag; left
 * still held: rate -32, else 0; live = 1; returns 1. */
typedef int fw_bend_release_right_t(void);
extern fw_bend_release_right_t fw_bend_release_right;

/* fw_bend_stop: VoiceCtl stop all, 0x01A85F58. Clears the bend state. */
typedef int fw_bend_stop_t(void);
extern fw_bend_stop_t fw_bend_stop;

/* fw_player_midi: PlayerManager per-block MIDI drain wrapper, 0x019E3CC4. Called once per
 * audio block from 0x01A0D2C8 with (1, 0); returns 0; wraps the USB MIDI drain 0x019E31A4. */
typedef int fw_player_midi_t(int a, int b);
extern fw_player_midi_t fw_player_midi;

/* fw_db_exec: db2 exec, 0x0196F950. Runs one SQL statement on an open database synchronously
 * under the db2 lock. The statement is formatted printf-style twice (the call, then the
 * prepare): avoid % in it (a literal one would need %%%%). Any error, or a statement that
 * returns rows, stops the OP-1 with a fatal assert: only UPDATE / INSERT / DELETE in SQLite
 * 3.6.20's SQL. Thread context only: it waits. Handles: op1.db [0x01BAB720], op1_factory.db
 * [0x01BAB724], tape.db [0x01BAB72C]. */
typedef void fw_db_exec_t(void *db, const char *sql);
extern fw_db_exec_t fw_db_exec;

/* fw_load_types: load_types, 0x019707D8. Reads (id, type) rows of a types table of
 * op1_factory.db into a sorted list of 48-byte entries (a std::string, the id at +0x1C). The
 * effect list is loaded once, from 0x01970AF6, as (factory db, 0x01BAB748, "fx_types"), when
 * shift + t3 first opens it. */
typedef int fw_load_types_t(void *db, void *list, const char *table);
extern fw_load_types_t fw_load_types;

/* fw_fx_off_draw: fx_bypass.cpp draw, 0x019AAC38. The effect pages' "X off" overlay's draw
 * (screen 54, vtable 0x0191007C): dims the whole frame (0x01A2357A on the canvas, 0x01A3B490)
 * and draws the off badge for the mode ("X off" synth, "H off" drum, "I off" master: the
 * OP-1's icon font). self is not used. Display thread, on a drawn frame (Opus: after its
 * effect screen). */
typedef void fw_fx_off_draw_t(void *self);
extern fw_fx_off_draw_t fw_fx_off_draw;

/* fw_db_open: db2 open, 0x0196F912. Opens tape.db, user/op1.db, content/op1_factory.db and
 * content/kerntable.db under root (OP_Main at boot, from 0x019F02E0, with "/yaffs2/"), before
 * the sound slots and the master are loaded. */
typedef void fw_db_open_t(const char *root);
extern fw_db_open_t fw_db_open;

/* fw_sqlite3_prepare_v2: SQLite 3.6.20 sqlite3_prepare_v2, 0x01A1537C. Compiles one statement
 * (bytes -1: to its NUL; tail 0) into *stmt; 0 SQLITE_OK, else an error (1 SQLITE_ERROR:
 * fw_sqlite3_errmsg says why). Finalize every statement. Thread context; take db2's lock as
 * the OS does (the semaphore [0x01BAB718]), or read only in opl_init. The handle of op1.db:
 * [[0x01BAB720]] (op1_factory.db [[0x01BAB724]], tape.db [[0x01BAB72C]]). */
typedef int fw_sqlite3_prepare_v2_t(void *db, const char *sql, int bytes, void **stmt, const char **tail);
extern fw_sqlite3_prepare_v2_t fw_sqlite3_prepare_v2;

/* fw_sqlite3_step: SQLite 3.6.20 sqlite3_step, 0x01A7BB20. 100 SQLITE_ROW (a row to read with
 * the fw_sqlite3_column_ names), 101 SQLITE_DONE, else an error. Thread context; take db2's
 * lock as the OS does (the semaphore [0x01BAB718]), or read only in opl_init. The handle of
 * op1.db: [[0x01BAB720]] (op1_factory.db [[0x01BAB724]], tape.db [[0x01BAB72C]]). */
typedef int fw_sqlite3_step_t(void *stmt);
extern fw_sqlite3_step_t fw_sqlite3_step;

/* fw_sqlite3_finalize: SQLite 3.6.20 sqlite3_finalize, 0x01A7B202. Frees a prepared statement
 * (0 harmless). The OS's db2 wrapper calls it before every prepare (db2.cpp:107). */
typedef int fw_sqlite3_finalize_t(void *stmt);
extern fw_sqlite3_finalize_t fw_sqlite3_finalize;

/* fw_sqlite3_column_int: SQLite 3.6.20 sqlite3_column_int, 0x01A7C544. The current row's
 * column col (from 0) as an int. */
typedef int fw_sqlite3_column_int_t(void *stmt, int col);
extern fw_sqlite3_column_int_t fw_sqlite3_column_int;

/* fw_sqlite3_column_int64: SQLite 3.6.20 sqlite3_column_int64, 0x01A7C5FC. As a 64-bit integer
 * (in R0:R1, as GCC returns long long). */
typedef long long fw_sqlite3_column_int64_t(void *stmt, int col);
extern fw_sqlite3_column_int64_t fw_sqlite3_column_int64;

/* fw_sqlite3_column_double: SQLite 3.6.20 sqlite3_column_double, 0x01A7C488. As a 64-bit
 * double (GCC's double: 2.5 read back as 0x40040000 00000000). */
typedef double fw_sqlite3_column_double_t(void *stmt, int col);
extern fw_sqlite3_column_double_t fw_sqlite3_column_double;

/* fw_sqlite3_column_text: SQLite 3.6.20 sqlite3_column_text, 0x01A7C6B8. As UTF-8 text, NUL-
 * terminated (0 for NULL); valid until the next step, reset or finalize. */
typedef const unsigned char *fw_sqlite3_column_text_t(void *stmt, int col);
extern fw_sqlite3_column_text_t fw_sqlite3_column_text;

/* fw_sqlite3_column_bytes: SQLite 3.6.20 sqlite3_column_bytes, 0x01A7C308. Its size in bytes
 * as text or a blob (without the NUL). */
typedef int fw_sqlite3_column_bytes_t(void *stmt, int col);
extern fw_sqlite3_column_bytes_t fw_sqlite3_column_bytes;

/* fw_sqlite3_column_type: SQLite 3.6.20 sqlite3_column_type, 0x01A7C8E8. 1 INTEGER, 2 FLOAT, 3
 * TEXT, 4 BLOB, 5 NULL. */
typedef int fw_sqlite3_column_type_t(void *stmt, int col);
extern fw_sqlite3_column_type_t fw_sqlite3_column_type;

/* fw_sqlite3_exec: SQLite 3.6.20 sqlite3_exec, 0x019C9460. Runs the statements in sql; row, an
 * int (*)(void *arg, int n, char **values, char **names), is called with arg, the columns, the
 * values as text and the names for each row (return 0 to go on); err 0. Thread context; take
 * db2's lock as the OS does (the semaphore [0x01BAB718]), or read only in opl_init. The handle
 * of op1.db: [[0x01BAB720]] (op1_factory.db [[0x01BAB724]], tape.db [[0x01BAB72C]]). */
typedef int fw_sqlite3_exec_t(void *db, const char *sql, void *row, void *arg, char **err);
extern fw_sqlite3_exec_t fw_sqlite3_exec;

/* fw_sqlite3_errmsg: SQLite 3.6.20 sqlite3_errmsg, 0x019D6C24. The last error's English text
 * ("no such table: nowhere"). */
typedef const char *fw_sqlite3_errmsg_t(void *db);
extern fw_sqlite3_errmsg_t fw_sqlite3_errmsg;

/* fw_read_iface: ReadInterface, 0x01A28DA0. The effect screens' params: a static
 * std::vector<float> (0x01AB32A0; begin at +4, end at +8) of each param scaled 0-1 by the
 * slot's own type's limits. editmode 0 synth, 1 drum, 3 master (else an assert); asserts when
 * a param is outside its limits. Display thread. */
typedef void *fw_read_iface_t(int slot, int editmode);
extern fw_read_iface_t fw_read_iface;

/* fw_fx_retvals: ReadInterface ret val, 0x01A28B34. The effect screens' animation: a static
 * vector (0x01AB3290) of the return values the effect's process writes (0xFF801774 + 16 x pos;
 * the master's two halves summed, the second cleared). Display thread. */
typedef void *fw_fx_retvals_t(int editmode, int n);
extern fw_fx_retvals_t fw_fx_retvals;

/* fw_hand_screen: hint hand overlay, 0x01A50204. The hint hand overlay (screen 61,
 * subscreenhand.svg; 0x01DF6EF0), built on the first call. For fw_hand_show. KeyHandler
 * thread, as the knob handlers call it. */
typedef void *fw_hand_screen_t(void);
extern fw_hand_screen_t fw_hand_screen;

/* fw_hand_show: hint hand show, 0x01A50168. Shows the hand pointing at element n of screen
 * (fw_hand_screen()); 3 points at t3, as the effect pages do on a turn while their effect is
 * off. Nothing new when that hand already shows. KeyHandler thread. */
typedef void fw_hand_show_t(void *screen, int n);
extern fw_hand_show_t fw_hand_show;

/* fw_hand_hide: hint hand hide, 0x01A501E8. Hides the hand if one shows (clears [0x01DF6EDC]
 * and the element's byte +0x50); screen (fw_hand_screen()) is not read. Every stock controller
 * key-down handler calls it first (synth 0x01A50904 / 0x01A51058, drum 0x019777DC /
 * 0x01978008, mixer 0x019DB7C4). KeyHandler thread. */
typedef void fw_hand_hide_t(void *screen);
extern fw_hand_hide_t fw_hand_hide;

/* fw_json_index: Json::Value::operator[], 0x019BFEB4. The member key of an object value
 * (created if missing): a reference for fw_json_assign. The OS's snapshot save uses it for
 * "name". */
typedef void *fw_json_index_t(void *value, const char *key);
extern fw_json_index_t fw_json_index;

/* fw_json_text: Json::Value::Value(const char *), 0x019BDC4C. Builds a string value in value
 * (16 bytes of storage are enough); free it with fw_json_free(value, 2). */
typedef void *fw_json_text_t(void *value, const char *text);
extern fw_json_text_t fw_json_text;

/* fw_json_assign: Json::Value::operator=, 0x019BDDC0. dst = src (a copy). */
typedef void fw_json_assign_t(void *dst, void *src);
extern fw_json_assign_t fw_json_assign;

/* fw_json_free: Json::Value::~Value, 0x019BDD18. Destroys a value built with fw_json_text
 * (flags 2, as the OS calls it for a local). */
typedef void fw_json_free_t(void *value, int flags);
extern fw_json_free_t fw_json_free;

/* fw_yaffs_lock: yaffsfs_Lock, 0x01A98B3C. Takes the file system's semaphore (waits). Not
 * recursive: no public fw_yaffs_* call until fw_yaffs_unlock. Thread context only. */
typedef void fw_yaffs_lock_t(void);
extern fw_yaffs_lock_t fw_yaffs_lock;

/* fw_yaffs_unlock: yaffsfs_Unlock, 0x01A98B78. Releases the semaphore fw_yaffs_lock took. */
typedef void fw_yaffs_unlock_t(void);
extern fw_yaffs_unlock_t fw_yaffs_unlock;

/* fw_yaffs_find_dir: yaffsfs_DoFindDirectory, 0x01A98FCC. The folder object holding the path's
 * last part (start 0: from the root; sym_depth 0), or 0; *leaf points into path after the last
 * '/'. not_dir and loop are written on a failure: pass real pointers. Under fw_yaffs_lock. */
typedef void *fw_yaffs_find_dir_t(void *start, const char *path, char **leaf, int sym_depth, int *not_dir, int *loop);
extern fw_yaffs_find_dir_t fw_yaffs_find_dir;

/* fw_yaffs_find_by_name: yaffs_find_by_name, 0x01A94678. The object named name in the folder
 * dir, or 0 (case-sensitive). dir must be a folder object (a null or a file is a fatal
 * assert). Under fw_yaffs_lock. */
typedef void *fw_yaffs_find_by_name_t(void *dir, const char *name);
extern fw_yaffs_find_by_name_t fw_yaffs_find_by_name;

/* fw_yaffs_change_name: yaffs_change_obj_name, 0x01A947C0. Renames obj to new_name in the
 * folder new_dir and writes its header (one page): 1 done, 0 failed. With force 0 and shadows
 * 0 it refuses a name new_dir already has, before changing anything. Under fw_yaffs_lock;
 * new_dir from fw_yaffs_find_dir. */
typedef int fw_yaffs_change_name_t(void *obj, void *new_dir, const char *new_name, int force, int shadows);
extern fw_yaffs_change_name_t fw_yaffs_change_name;

/* fw_yaffs_find_chunk: yaffs_find_chunk_in_file, 0x01A90144. The NAND chunk holding a file's
 * 1-based chunk (offset / 2048 + 1), or -1 when that part of the file is not on the flash (a
 * hole); tags 0. RAM only on the OP-1 (chunk group size 1): ~180 cycles a hole, ~350 a written
 * chunk. Under fw_yaffs_lock; obj from fw_yaffs_find_by_name. */
typedef int fw_yaffs_find_chunk_t(void *obj, int chunk, void *tags);
extern fw_yaffs_find_chunk_t fw_yaffs_find_chunk;

/* fw_disk_export_synth: filesync_common.cpp: disk mode's export of the synth presets,
 * 0x0199DA6C. Disk mode's first export, called once at its start (0x01997628) with the disk
 * controller in R0: writes the user's synth presets as .aif files into the USB disk (each
 * through 0x0199D668). FatFs mounted; the thread that enters disk mode. */
typedef void fw_disk_export_synth_t(void *disk);
extern fw_disk_export_synth_t fw_disk_export_synth;

/* fw_usb_ms_write: usb_ms_yaffs.cpp: the USB disk's media write, 0x01A715DC. Writes count
 * sectors of 512 bytes from buf at sector of tape_c.raw (fw_yaffs_lseek, fw_yaffs_write on
 * [0x018C180C]); 0 done; a short write asserts usb_ms_yaffs.cpp:55 (fatal). In kUsb_thread, at
 * most 32 sectors a call; counts sectors at [0x018C1F34]. */
typedef int fw_usb_ms_write_t(void *buf, unsigned int sector, unsigned int count);
extern fw_usb_ms_write_t fw_usb_ms_write;

/* fw_usb_event: smxUSBD core: a bus event to the core and the functions, 0x01A6C9B4. The DCD
 * event handler 0x01A6ABAC reports each bus event through it (R0 the device [0x01DFE040], R1
 * the event): 3 and 4 a bus reset, 12 a resume, 10 a suspend or disconnect (every endpoint
 * disabled and its transfer cancelled, 0x01A6BDCA; the mass-storage class closes the media,
 * 0x01A70080). In kUsb_thread. */
typedef int fw_usb_event_t(void *dev, int event);
extern fw_usb_event_t fw_usb_event;

/* fw_usb_setup: smxUSBD core: a control request's dispatch, 0x01A6D67A. Called by the DCD
 * event handler at 0x01A6AFAC and 0x01A6B0D6 once a SETUP (and its OUT data) is in; the
 * request's 8 bytes are at 0x01DFE060; standard requests go to 0x01A6D430, class requests (Get
 * Max LUN, the Bulk-Only reset) to the function. 0 handled. In kUsb_thread. */
typedef int fw_usb_setup_t(void *ep0);
extern fw_usb_setup_t fw_usb_setup;

/* fw_ms_out_done: MassStorage: a bulk OUT transfer done, 0x01A6FE18. The mass- storage class's
 * OUT completion (ops table 0x018FF7B8 + 8): a CBW (state [0x01DFE2EC] 1: the transfer's
 * buffer [xfer + 0x18], its length [xfer + 0x24] 31) or a WRITE's data (state 4). In
 * kUsb_thread. */
typedef int fw_ms_out_done_t(void *xfer);
extern fw_ms_out_done_t fw_ms_out_done;

/* fw_ms_in_done: MassStorage: a bulk IN transfer done, 0x01A6FD6C. The mass- storage class's
 * IN completion (ops table 0x018FF7B8 + 4): a READ's data piece (state 3, [xfer + 0x24] bytes)
 * or the CSW sent; the next piece or the next CBW's OUT armed. In kUsb_thread. */
typedef void fw_ms_in_done_t(void *xfer);
extern fw_ms_in_done_t fw_ms_in_done;

/* fw_global_controller: global_controller.cpp: the hold-to-save, 0x019AD090. OP_Main once a
 * pass (0x019F0A3C): the s-key countdown, its overlay and the save; returns 1 while it counts
 * or saved (OP_Main adds it to its busy count), 0 otherwise. */
typedef int fw_global_controller_t(void);
extern fw_global_controller_t fw_global_controller;

/* fw_synth_presets_load: patch.cpp: the synth preset array rebuilt, 0x01A0567C. Every entry
 * from op1_factory.db then op1.db (asserts the limits); 0.68 s for 172 presets in the
 * emulator. OP_Main (the save calls it). Reads opus_presets under Opus (presets.hooks). */
typedef void fw_synth_presets_load_t(void);
extern fw_synth_presets_load_t fw_synth_presets_load;

/* fw_drum_presets_load: patch.cpp: the drum preset array rebuilt, 0x01A04FE8. As
 * fw_synth_presets_load for the drum array 0x01DE20F8. */
typedef void fw_drum_presets_load_t(void);
extern fw_drum_presets_load_t fw_drum_presets_load;

/* fw_synth_slot_preset: the synth slot's preset, 0x01A02030. The array index of the first
 * entry with the slot's "type" and "name" (*found = 1), else the first of its type (*found =
 * 0). */
typedef int fw_synth_slot_preset_t(int slot, unsigned char *found);
extern fw_synth_slot_preset_t fw_synth_slot_preset;

/* fw_drum_slot_preset: the drum slot's preset, 0x01A01DC8. The first drum array entry with the
 * slot's "name" (*found = 1), else 0. */
typedef int fw_drum_slot_preset_t(int slot, unsigned char *found);
extern fw_drum_slot_preset_t fw_drum_slot_preset;

/* fw_synth_slot_is_sampler: the synth slot's type is "sampler", 0x019957E4. Slot 0-7, else 0. */
typedef int fw_synth_slot_is_sampler_t(int slot);
extern fw_synth_slot_is_sampler_t fw_synth_slot_is_sampler;

/* fw_drum_slot_is_kit: the drum slot's type is "drum" (a sampled kit), 0x01995868. Slot 0-7,
 * else 0. */
typedef int fw_drum_slot_is_kit_t(int slot);
extern fw_drum_slot_is_kit_t fw_drum_slot_is_kit;

/* fw_save_overlay_ok: the save overlay's green tick, 0x01A3AA84. State 1, shown about 0.8 s (a
 * timer of 1024 audio blocks). Plain stores: any thread. */
typedef void fw_save_overlay_ok_t(void);
extern fw_save_overlay_ok_t fw_save_overlay_ok;

/* fw_save_overlay_full: the save overlay's red FULL, 0x01A3AA68. State 2, the same timer. */
typedef void fw_save_overlay_full_t(void);
extern fw_save_overlay_full_t fw_save_overlay_full;

/* fw_json_get: jsoncpp Value::operator[](const char *) const, 0x019BEB70. The member key of an
 * object value, or the static null value 0x01DD4FE4 when absent or when value is null; never
 * inserts (fw_json_index does). A value: +0 the union (a string value: its char *), B[+8] the
 * type (0 null, 4 string, 7 object); a value of another type asserts. */
typedef const void *fw_json_get_t(const void *value, const char *key);
extern fw_json_get_t fw_json_get;

/* fw_svg_node_find: Node.cpp: an SVG element by id, 0x019EB8AC. Depth first from node (a
 * screen's document is [screen + 0]) for the element whose id equals id exactly; 0 when none.
 * warn 1 also logs "Node.cpp:80 Can't find SVG object" through 0x01919AA8, which stops the OS
 * once asserts are on after boot (B[0xFF9002F4]); Screen.cpp's lookup 0x01A3B580 always warns:
 * pass warn 0. An element: +0x50 the shown byte (the save overlay's draw sets it per part),
 * +0x24 its id (std::string), +0x44/+0x48 the children. */
typedef void *fw_svg_node_find_t(void *node, const char *id, int warn);
extern fw_svg_node_find_t fw_svg_node_find;

/* fw_key_to_index: Keys.cpp: a note key's index 0..23, 0x019C3322. Asserts "Not a note key!"
 * (fatal after boot) for any other code: check is_note_key 0x019C316C first. */
typedef int fw_key_to_index_t(int key);
extern fw_key_to_index_t fw_key_to_index;

/* fw_make_midinote: VoiceCtl: a note event from a key index, 0x01A85014. ev: {+0 note = index
 * + 53 + 12 x the synth slot's octave (none on the drum), +4 velocity, +8 byte 1 echo to USB
 * MIDI, +0xC 0}. */
typedef void fw_make_midinote_t(void *ev, int index, int velocity);
extern fw_make_midinote_t fw_make_midinote;

/* fw_vc_note_on: VoiceCtl note on, 0x01A85750. Asserts 0 <= note < 128; synth or drum by
 * [0x01DE4C40]; echoes USB MIDI when ev+8. */
typedef void fw_vc_note_on_t(void *ev, int param);
extern fw_vc_note_on_t fw_vc_note_on;

/* fw_vc_note_off: VoiceCtl note off, 0x01A85840. Releases the first held entry with ev's note
 * number; echoes USB MIDI off when ev+8. */
typedef void fw_vc_note_off_t(void *ev);
extern fw_vc_note_off_t fw_vc_note_off;

/* fw_note_down: global_controller.cpp: the global note-on, 0x019AC0B0. A key index 0..23
 * played: tape start when armed, a running sequencer, or s_note_ons[key] (asserts it was
 * clear: fatal), make_midinote and VoiceCtl note-on. KeyHandler thread. Its result is not
 * used. */
typedef int fw_note_down_t(int key, int shift);
extern fw_note_down_t fw_note_down;

/* fw_note_up: global_controller.cpp: the global key-up's release, 0x019AC2F8. The sequencer's
 * key, or if s_note_ons[key]: cleared, make_midinote(ev, key, 0x40), VoiceCtl note-off. */
typedef int fw_note_up_t(int key);
extern fw_note_up_t fw_note_up;

/* fw_json_value: Json::Value::Value(ValueType), 0x019BFA30. Builds an empty value in 16 bytes
 * of fresh storage: 0 null, 6 array, 7 object. Returns value; free with fw_json_free(value,
 * 2). */
typedef void *fw_json_value_t(void *value, int type);
extern fw_json_value_t fw_json_value;

/* fw_json_int: Json::Value::Value(Int), 0x019BD890. Builds an int value (type 1) in fresh
 * storage; returns value. The knob writer 0x01A00D14 builds each knob this way. */
typedef void *fw_json_int_t(void *value, int n);
extern fw_json_int_t fw_json_int;

/* fw_json_bool: Json::Value::Value(bool), 0x019BD832. Builds a bool value (type 5) from the
 * low byte of b; returns value. The checker builds fx_active this way. */
typedef void *fw_json_bool_t(void *value, int b);
extern fw_json_bool_t fw_json_bool;

/* fw_json_copy: Json::Value::Value(const Value &), 0x019BE568. A deep copy of src into fresh
 * storage dst (not an assignment: dst must not hold a value). Returns dst. */
typedef void *fw_json_copy_t(void *dst, const void *src);
extern fw_json_copy_t fw_json_copy;

/* fw_json_type: Json::Value::type, 0x019BD82A. B[value + 8]: 0 null, 1 int, 2 uint, 3 real, 4
 * string, 5 bool, 6 array, 7 object. */
typedef int fw_json_type_t(const void *value);
extern fw_json_type_t fw_json_type;

/* fw_json_size: Json::Value::size, 0x019BE8D8. An array: its last index + 1; an object: its
 * member count; anything else 0. */
typedef unsigned int fw_json_size_t(const void *value);
extern fw_json_size_t fw_json_size;

/* fw_json_get_at: Json::Value::operator[](UInt) const, 0x019BEA94. The element, or the static
 * null 0x01DD4FE4 when absent or when value is null; never inserts; asserts unless value is
 * null or an array. Never write through the result. */
typedef const void *fw_json_get_at_t(const void *value, unsigned int index);
extern fw_json_get_at_t fw_json_get_at;

/* fw_json_index_at: Json::Value::operator[](UInt), 0x019BFAF8. The element, created as null
 * when missing (a null value first becomes an array): only that index is created, so fill an
 * array in order. Asserts unless value is null or an array. */
typedef void *fw_json_index_at_t(void *value, unsigned int index);
extern fw_json_index_at_t fw_json_index_at;

/* fw_json_remove: Json::Value::removeMember(const char *), 0x019BEE88. out (16 bytes of fresh
 * storage) receives the member, or null when absent; the member is erased from value. Free out
 * with fw_json_free(out, 2). Asserts unless value is null or an object. */
typedef void *fw_json_remove_t(void *value, void *out, const char *key);
extern fw_json_remove_t fw_json_remove;

/* fw_json_as_int: Json::Value::asInt, 0x019BE0C0. The full 32-bit int: null 0, int, uint, real
 * truncated, bool 0/1. A string, array or object is a fatal assert: test fw_json_type first. */
typedef int fw_json_as_int_t(const void *value);
extern fw_json_as_int_t fw_json_as_int;

/* fw_json_as_bool: Json::Value::asBool, 0x019BE35C. null false, a number nonzero, a bool, a
 * non-empty string, array or object; never asserts. The result is in the low byte: mask with
 * 0xFF. */
typedef int fw_json_as_bool_t(const void *value);
extern fw_json_as_bool_t fw_json_as_bool;

/* fw_json_as_cstr: Json::Value::asCString, 0x019BDFD4. The characters of a string value (owned
 * by the value). A fatal assert unless the type is 4: test fw_json_type first. */
typedef const char *fw_json_as_cstr_t(const void *value);
extern fw_json_as_cstr_t fw_json_as_cstr;

/* fw_synth_save_row: patch.cpp: the synth slot row writer (patch vtable +0x34), 0x01A00D90.
 * Queues the BgFile job that writes UPDATE synth_slots SET patch = the slot's in-memory JSON
 * as it is when the job runs. slot = 0x01DDD7E8 + 0x38 x n (asserts unless its slot word is
 * 0-7). Thread context (the OS calls it from KeyHandler after every T1 turn), not IVG11. */
typedef void fw_synth_save_row_t(void *slot);
extern fw_synth_save_row_t fw_synth_save_row;

/* fw_drum_save_row: patch.cpp: the drum slot row writer (drum vtable +0x34), 0x01A000D8. As
 * fw_synth_save_row for a drum slot (0x01DDD9A8 + 0x38 x n): UPDATE drum_slots. */
typedef void fw_drum_save_row_t(void *slot);
extern fw_drum_save_row_t fw_drum_save_row;

/* fw_synth_knobs_json: patch.cpp: a synth slot's knob writer (after every T1 turn),
 * 0x01A00D14. Sets the sound's JSON knobs to the 8 shorts at knobs (read sign- extended) and
 * queues the slot's synth_slots row (fw_synth_save_row). slot = 0x01DDD7E8 + 0x38 x n; the OS
 * passes the live knobs 0xFF8013C4 + 16 x n, written first. KeyHandler thread, as a turn. */
typedef void fw_synth_knobs_json_t(void *slot, const short *knobs);
extern fw_synth_knobs_json_t fw_synth_knobs_json;

/* fw_synth_adsr_json: patch.cpp: a synth slot's envelope writer (after every T2 turn),
 * 0x01A00C98. As fw_synth_knobs_json for the envelope: the sound's JSON adsr = the 8 words at
 * env (the OS passes the live record 0x01B60EF0 + 16 x n: attack, decay, sustain, release,
 * play mode, portamento, two hidden), then the row. */
typedef void fw_synth_adsr_json_t(void *slot, const unsigned short *env);
extern fw_synth_adsr_json_t fw_synth_adsr_json;

/* fw_synth_knob_turn: Ranges: one T1 turn event on a synth slot's knobs, 0x01A1DFEC. knob 0-3
 * (+4 with shift: the fine layer of 0-3, or knobs 4-7 on dsynth and the sampler); *delta in
 * the encoder's units (moves by (delta x step) >> 15, saturating); the knob clamped to its row
 * (drwave's 0-2 wrap), the sampler's linked knobs moved too; writes knobs and returns the new
 * value. No JSON or row: call fw_synth_knobs_json after. KeyHandler thread, as a turn (the LFO
 * also calls it in IVG11 on its render copy). */
typedef short fw_synth_knob_turn_t(int knob, short *delta, int engine, short *knobs);
extern fw_synth_knob_turn_t fw_synth_knob_turn;

/* fw_master_fx_on: the master effect's on/off, 0x0196728C. B[0x01AAAC40] = on: the master
 * effect runs or not. The master loader sets it from the row's fx_active. */
typedef void fw_master_fx_on_t(int on);
extern fw_master_fx_on_t fw_master_fx_on;

/* fw_list_add: the browser list's add, 0x01A18594. Adds an entry {label (a std::string: 0x1C
 * bytes, the characters inline at +4 while [+0x18] is 15, the size at +0x14), id} and sorts
 * the list. Call it after load_types (which needs the list empty). */
typedef void fw_list_add_t(void *list, const void *label, int id);
extern fw_list_add_t fw_list_add;

/* fw_list_pos: the engine list's position for a slot, 0x01A0240E. The id the engine list opens
 * on: the first synth_types row of the slot's type, or minus a sampler preset's index (*found
 * set). */
typedef int fw_list_pos_t(int slot, char *found);
extern fw_list_pos_t fw_list_pos;

/* fw_engine_job_run: the engine change job's run, 0x0193FFAC. job: {vtable, slot, id}. Looks
 * the id up in synth_types (no row: fatal), sets type, name, knobs, applies, writes the row.
 * BgFile thread. */
typedef void fw_engine_job_run_t(int *job);
extern fw_engine_job_run_t fw_engine_job_run;

/* fw_patch_set: patch: set the JSON without a check, 0x019FF5F0. obj json := json (a copy). No
 * checker: the caller answers for the sound. */
typedef void fw_patch_set_t(void *obj, const void *json);
extern fw_patch_set_t fw_patch_set;

/* fw_post_apply: the KeyHandler's pending apply, 0x019C2BB8. Marks slot for the KeyHandler to
 * apply ([0x01DD5030] = slot, B[0xFF9079CD] = 1); follow with fw_post_keyhandler. */
typedef void fw_post_apply_t(int slot);
extern fw_post_apply_t fw_post_apply;

/* fw_post_keyhandler: wake the KeyHandler thread, 0x019C2F04. Posts the KeyHandler's binary
 * semaphore (id at [0x01DD502C], through 0xFFA00134; callable from threads and interrupts): it
 * wakes about 1,780 cycles later and runs a pending apply, every queued key, then the four
 * encoder accumulators. A key written into the queue 0x01DD5044 or an accumulator 0x01DD5250
 * does nothing until a post (Opus's inject.c). */
typedef void fw_post_keyhandler_t(void);
extern fw_post_keyhandler_t fw_post_keyhandler;

/* fw_browse_run: the preset browse job's run, 0x019407DC. job: {vtable, slot, array index}:
 * loads the preset into the slot, copies a sampler's sample, posts the apply, writes the row.
 * BgFile thread. */
typedef void fw_browse_run_t(int *job);
extern fw_browse_run_t fw_browse_run;

/* fw_synth_patch_load: patch.cpp: synth patch set (patch vtable +0x14), 0x01A052DC. obj json
 * := json, then the checker (fatal on an error); slot -1 for a preset array entry. No apply. */
typedef void fw_synth_patch_load_t(void *obj, int slot, const void *json);
extern fw_synth_patch_load_t fw_synth_patch_load;

/* fw_synth_apply: patch.cpp: synth patch apply (patch vtable +0x1C), 0x01A010F8. Applies a
 * synth slot object's sound: the engine number, knobs, envelope, effect, LFO; rebuilds the
 * voices. Thread context. */
typedef void fw_synth_apply_t(void *obj);
extern fw_synth_apply_t fw_synth_apply;

/* fw_node_set_matrix: Node.cpp set matrix, 0x019EAD58. m: 3x3 22.10, row vector {a,b,0, c,d,0,
 * e,f,1} (x' = a x + c y + e). Copies it when it differs and clears the cached pixels (vtable
 * +0x74; a group: every descendant). Display thread. */
typedef void fw_node_set_matrix_t(void *node, const int *m9);
extern fw_node_set_matrix_t fw_node_set_matrix;

/* fw_node_scale_about_centre: Node.cpp scale about the centre, 0x019EAF70. The node's matrix
 * := T(-c) S(s, s) T(c) about the centre of its own bounds (the old matrix replaced); clears
 * the cache like fw_node_set_matrix. */
typedef void fw_node_scale_about_centre_t(void *node, int scale_q10);
extern fw_node_scale_about_centre_t fw_node_scale_about_centre;

/* fw_group_draw: Group draw (vtable +0x14 of groups), 0x019EB818. Draws one subtree with a
 * matrix of the caller's (node matrix x m) through raster (fw_screen_raster()); a hidden node
 * draws nothing. No stock screen calls it directly. Display thread. */
typedef void fw_group_draw_t(void *node, void *doc, const int *m9, void *raster);
extern fw_group_draw_t fw_group_draw;

/* fw_shape_draw: Shape draw (vtable +0x14 of shapes), 0x01A4333C. Draws one shape (if shown,
 * +0x50) with node matrix x m through fw_draw_path(raster, the shape's cacheable byte +0x58,
 * doc + 0x58 fills, doc + 0x68 line styles, node + 0x5C its path, the matrix, 0, 0). Called by
 * fw_group_draw for each child. Display thread. */
typedef void fw_shape_draw_t(void *node, void *doc, const int *m9, void *raster);
extern fw_shape_draw_t fw_shape_draw;

/* fw_screen_line_style: Screen.cpp line style, 0x01A3B854. The element's 20-byte line style in
 * its document {RGBA, width 22.10, cap, join, miter}; a group's descendants all take its first
 * line id. Fatal when the id or its stroke is missing (Screen.cpp:84). */
typedef void *fw_screen_line_style_t(void *screen, const char *id);
extern fw_screen_line_style_t fw_screen_line_style;

/* fw_screen_fill: Screen.cpp fill, 0x01A3B96C. The element's RGBA fill entry in its document
 * (u8 r, g, b, a); fatal when the id or its fill is missing (Screen.cpp:95). */
typedef void *fw_screen_fill_t(void *screen, const char *id);
extern fw_screen_fill_t fw_screen_fill;

/* fw_node_remove: Node.cpp remove, 0x019EBDBC. Takes node out from below root and deletes it. */
typedef void fw_node_remove_t(void *root, void *node);
extern fw_node_remove_t fw_node_remove;

/* fw_node_add_child: Node.cpp add child, 0x019EBBB4. Appends child (drawn last, on top); the
 * vector grows from the TE pool (thread context). */
typedef void fw_node_add_child_t(void *parent, void *child);
extern fw_node_add_child_t fw_node_add_child;

/* fw_path_init: Path init, 0x019F9FD6. Zeroes a Path of 0x34 bytes (word aligned): +0x10 fill
 * id, +0x12 line id, +0x18 its segment vector. */
typedef void fw_path_init_t(void *path);
extern fw_path_init_t fw_path_init;

/* fw_path_move_to: Path move to, 0x01A070A4. Starts a subpath at xy (22.10 drawing units;
 * absolute 0: relative to the current point). Allocates segments from the TE pool until the
 * vector is big enough (reuse one Path: fw_path_clear keeps its room). */
typedef void fw_path_move_to_t(void *path, const int *xy, int absolute);
extern fw_path_move_to_t fw_path_move_to;

/* fw_path_line_to: Path line to, 0x01A0712C. A line to xy; one shorter than about 0.17 units
 * is dropped and the current point stays. */
typedef void fw_path_line_to_t(void *path, const int *xy, int absolute);
extern fw_path_line_to_t fw_path_line_to;

/* fw_path_cubic: Path cubic, 0x01A06EAC. A cubic {control 1, control 2, end}, 22.10. */
typedef void fw_path_cubic_t(void *path, int x1, int y1, int x2, int y2, int x, int y, int absolute);
extern fw_path_cubic_t fw_path_cubic;

/* fw_path_close: Path close, 0x01A0722E. Closes the subpath. */
typedef void fw_path_close_t(void *path);
extern fw_path_close_t fw_path_close;

/* fw_path_finish: Path finish, 0x01A062D8. Stores the ids (1-based into the tables given at
 * the draw, 0 none) and works out each segment's directions for joins and caps; needed after
 * points change (or a stroke's width goes uneven). */
typedef void fw_path_finish_t(void *path, int fill_id, int line_id);
extern fw_path_finish_t fw_path_finish;

/* fw_path_clear: Path clear, 0x01A072E8. Empties the segments (their room kept: no allocation
 * next frame) and frees the path's rasterizers. */
typedef void fw_path_clear_t(void *path);
extern fw_path_clear_t fw_path_clear;

/* fw_line_style_make: LineStyle make, 0x019D1C70. Fills a 20-byte line style: cap 0 butt, 1
 * round, 2 square; join 0 miter, 1 round, 2 bevel. Returns out. */
typedef void *fw_line_style_make_t(void *out, const unsigned char *rgba, int width_q10, int cap, int join, int miter_q10);
extern fw_line_style_make_t fw_line_style_make;

/* fw_stroke_path: Raster stroke path, 0x01A2758C. Strokes a finished path with style through
 * fw_draw_path (anti-aliased); unused and extra 0; m the drawing's matrix (identity
 * 0x01B60FD8). Keep a shape under 4,096 AGG cells (agg.cpp:339 is fatal). Display thread. */
typedef void fw_stroke_path_t(void *raster, int unused, const void *style, void *path, const int *m9, int extra);
extern fw_stroke_path_t fw_stroke_path;

/* fw_draw_path: Raster draw path, 0x01A27368. The raster's path primitive: fills and lines are
 * vector headers {0, first, last, end} over RGBA bytes and 20-byte line styles; cache 0,
 * override 0, extra 0. Display thread. */
typedef void fw_draw_path_t(void *raster, int cache, const void *fills, const void *lines, void *path, const int *m9, int override, int extra);
extern fw_draw_path_t fw_draw_path;

/* fw_agg_add_cell: AGG add current cell (agg.cpp:339), 0x0191412C. Stores a rasterizer's
 * current cell in its store (+0 blocks allocated, +8 the block in use, +0xC cells); stock
 * stops the OP-1 when a block is needed and 16 were ever allocated (Opus 2's shapesafe.hooks:
 * a spare is used, a 17th cell block refused, the cell dropped). Internal: not for a mod to
 * call. */
typedef void fw_agg_add_cell_t(void *store);
extern fw_agg_add_cell_t fw_agg_add_cell;

/* fw_raster_clear: Raster clear, 0x01A23466. Clears the attached frame (memory DMA from
 * 0xFF800BAC, waiting for each chunk: the buffer is zero when it returns). render_all's only
 * call is at 0x01A3BBE0, once a frame before the screens draw; a hook there calls it, then
 * draws under the OS's screens and overlays. Display thread. */
typedef void fw_raster_clear_t(void *raster);
extern fw_raster_clear_t fw_raster_clear;

/* fw_usb_rx_buffer: the USB MIDI function's OUT buffer, 0x01A6936C. The current USB MIDI OUT
 * transfer's buffer, or 0 when USB is not configured; its only caller is the MIDI callback's
 * event 2 at 0x019E136C (in the USB interrupt), which then copies R7 / 4 packets from it into
 * the input ring 0x01AB0510. Opus's dev port calls it from opus_usb_rx (usbport_entry.S) at
 * that place. */
typedef void *fw_usb_rx_buffer_t(void);
extern fw_usb_rx_buffer_t fw_usb_rx_buffer;

/* fw_yaffs_opendir: yaffsfs.c yaffs_opendir, 0x01A9B450. A folder's handle, or 0. Thread
 * context. */
typedef void *fw_yaffs_opendir_t(const char *path);
extern fw_yaffs_opendir_t fw_yaffs_opendir;

/* fw_yaffs_readdir: yaffsfs.c yaffs_readdir, 0x01A9B648. The folder's next entry: its name at
 * +0x0B, NUL-terminated (yaffs_dirent: d_ino, d_off, d_reclen, d_type, d_name); 0 at the end.
 * Thread context. */
typedef void *fw_yaffs_readdir_t(void *dir);
extern fw_yaffs_readdir_t fw_yaffs_readdir;

/* fw_yaffs_closedir: yaffsfs.c yaffs_closedir, 0x01A9B74C. 0. Thread context. */
typedef int fw_yaffs_closedir_t(void *dir);
extern fw_yaffs_closedir_t fw_yaffs_closedir;

/* fw_f_mount: ff.c f_mount (FatFs R0.08), 0x01998E74. Registers fs as the volume (FatFs[0] at
 * 0x01D04BD0), 0 unregisters; vol is not checked; returns 0. Writes nothing back: close files
 * first. The OS's FATFS is 0x01AABEE4. Disk mode's start unmounts with it at 0x019975FA
 * (themes-A). */
typedef int fw_f_mount_t(int vol, void *fs);
extern fw_f_mount_t fw_f_mount;

/* fw_f_open: ff.c f_open, 0x0199B2A8. FIL 0x824 bytes (a 2,048-byte buffer); mode READ 1,
 * WRITE 2, CREATE_NEW 4, CREATE_ALWAYS 8, OPEN_ALWAYS 0x10; FRESULT (4 no file, 5 no path, 7
 * denied, 8 exists, 12 not mounted). Not reentrant (one LFN buffer, 0x01D04BD8): only where
 * the OS itself uses FatFs, with the volume mounted (themes-A). */
typedef int fw_f_open_t(void *fil, const char *path, int mode);
extern fw_f_open_t fw_f_open;

/* fw_f_read: ff.c f_read, 0x0199B5C4. FRESULT; *br the bytes read. */
typedef int fw_f_read_t(void *fil, void *buf, unsigned int n, unsigned int *br);
extern fw_f_read_t fw_f_read;

/* fw_f_write: ff.c f_write, 0x0199B8A8. FRESULT; a full disk gives 0 with *bw < n. Reaches
 * tape_c.raw and the folder entry only at f_close. */
typedef int fw_f_write_t(void *fil, const void *buf, unsigned int n, unsigned int *bw);
extern fw_f_write_t fw_f_write;

/* fw_f_close: ff.c f_close, 0x0199BD7C. Writes the file's last sector and folder entry, the
 * FAT window and both FATs, then the yaffs flush of tape_c.raw (0x01A99804); its FRESULT. */
typedef int fw_f_close_t(void *fil);
extern fw_f_close_t fw_f_close;

/* fw_f_opendir: ff.c f_opendir, 0x0199C07C. DIR 0x24 bytes; 5 when missing; nothing to close. */
typedef int fw_f_opendir_t(void *dir, const char *path);
extern fw_f_opendir_t fw_f_opendir;

/* fw_f_readdir: ff.c f_readdir, 0x0199C148. FILINFO 0x20: size +0, attribute +8, the 8.3 name
 * +9, lfname +0x18 and lfsize +0x1C set before each call; the end: name[0] 0; the long name
 * empty when there is none, it is not code page 1252, or it does not fit (themes-A). */
typedef int fw_f_readdir_t(void *dir, void *info);
extern fw_f_readdir_t fw_f_readdir;

/* fw_f_unlink: ff.c f_unlink, 0x0199C620. A file or an empty folder; 7 for a read-only one or
 * a folder with files. */
typedef int fw_f_unlink_t(const char *path);
extern fw_f_unlink_t fw_f_unlink;

/* fw_f_mkdir: ff.c f_mkdir, 0x0199C7B8. 8 when it exists, 7 when the disk is full; writes the
 * folder's 8 KB cluster. */
typedef int fw_f_mkdir_t(const char *path);
extern fw_f_mkdir_t fw_f_mkdir;

/* fw_disk_changes: disk mode's end: the change check, 0x01996008. Non-zero when the end's
 * tracker found changed, deleted or new presets, tracks or sides. Called at 0x019974E8 with
 * the tracker [0xFF906F08], the volume mounted again (themes-A). */
typedef int fw_disk_changes_t(void *tracker);
extern fw_disk_changes_t fw_disk_changes;

/* fw_boot_logo_layout: OP_Main's boot logo layout, 0x01976474. Moves TE's logo (loaded by the
 * LDR into frame buffer A) into the panel's rows and clears the margins; OP_Main at boot
 * (0x019F0E8E, 0x019F0EB8), before the panel's init. Thread context. */
typedef void fw_boot_logo_layout_t(void);
extern fw_boot_logo_layout_t fw_boot_logo_layout;

/* fw_dcache_flush: the data cache flush, 0x01AA185C. Writes the data cache's lines for [start,
 * end) back to SDRAM (invalidate 1: drops them too), as the boot console does for frame buffer
 * A before its DMA (0x01AA185C(0x02003800, 0x0202B800, 0)). Static (no cache in the emulator);
 * on the device the splash, flushed so, showed whole. */
typedef void fw_dcache_flush_t(void *start, void *end, int invalidate);
extern fw_dcache_flush_t fw_dcache_flush;

/* fw_tape_set_pos: the tape's set_pos: moves the playhead, 0x01A55024. The playhead to samples
 * (44.1 kHz, from the tape's start), applied by the audio engine within the next block;
 * playing goes on from there. The OS calls it from the KeyHandler for stop while stopped (to
 * the loop's start point) and the loop jump of play while playing. */
typedef void fw_tape_set_pos_t(int samples);
extern fw_tape_set_pos_t fw_tape_set_pos;

/* fw_seq_id: SeqIds.cpp: sequencer name to id, 0x01A42344. name: a std::string (size +0x14,
 * capacity +0x18, text inline at +4 below 16, else a pointer at +4). pattern 0, endless 1,
 * tombola 2, finger 3, sketch 4, arpeggio 5; any other name asserts (SeqIds.cpp:41, fatal).
 * Opus hooks its entry (sound.c). */
typedef int fw_seq_id_t(void *name);
extern fw_seq_id_t fw_seq_id;

/* fw_json_as_string: Json::Value::asString, 0x019BE00C. out: a std::string the caller provides
 * (28 bytes). null gives "", a bool "true" or "false", a string its text; a number, array or
 * object is a fatal assert (json_value.cpp:731). */
typedef void fw_json_as_string_t(const void *value, void *out);
extern fw_json_as_string_t fw_json_as_string;

/* fw_vdk_thread_handles: VDK: the threads' handles, 0xFFA0BBB0. Fills handles with the
 * threads' handles (generation << 14 | index) and returns their count. Thread context only:
 * from an interrupt (IPEND checked) it calls the kernel's error. In L1. */
typedef int fw_vdk_thread_handles_t(int *handles, int max);
extern fw_vdk_thread_handles_t fw_vdk_thread_handles;

/* fw_vdk_thread_stack: VDK: a thread's stack, 0xFFA0BC4C. A thread's stack: its size in words
 * (the block's +0x2C) and its top (+0x30); its lowest word is top - 4 x size + 4, 0xDEADBEEF
 * while unused. Thread context only (IPEND checked). In L1. */
typedef int fw_vdk_thread_stack_t(int handle, unsigned *size_words, unsigned *top);
extern fw_vdk_thread_stack_t fw_vdk_thread_stack;

/* fw_fatal: the OS's fatal message (every assert), 0x01919AA8. Formats fmt (printf-style, 256
 * bytes) and, once the boot has set B[0xFF9002F4], stops the OP-1: interrupts off, the audio
 * and the amplifier off, then the crash screen 0x0191995C, which Opus 2 (from dev 18) replaces
 * with its own: the crash record, Stop or the power switch to restart, the plugin it came from
 * skipped at the next start (crash.c). Its call returns to 0x01919B08, the first return
 * address of every assert's record. For a plugin: a deliberate stop with a message, e.g. a
 * check that must never fail (testdata plugin_crash). */
typedef void fw_fatal_t(const char *fmt, ...);
extern fw_fatal_t fw_fatal;

/* fw_yaffs_fsync: yaffsfs.c yaffs_fsync, 0x01A998F4. Flushes the file's object: its cached
 * chunks, then its header (0x01A99804 -> yaffs_flush_file 0x01A93C80); nothing when it is
 * clean. 0, or -1 for a bad handle. The object is shared by its handles: one opened just for
 * this flushes what another wrote (savesafe.c). Thread context only. */
typedef int fw_yaffs_fsync_t(int fd);
extern fw_yaffs_fsync_t fw_yaffs_fsync;

/* fw_yaffs_resize_file: yaffs_guts.c yaffs_resize_file, 0x01A93BA4. Under fw_yaffs_lock only:
 * flushes the object's cached chunks, drops those past size (a hole when larger) and writes
 * its header; 1 (YAFFS_OK) or 0. obj: a handle's object as yaffsfs.c walks it (savesafe.c
 * writable_object). The OS's yaffs_ftruncate 0x01A99FB4 is compiled for one size, 0x18000000,
 * whatever is passed: not for other sizes. */
typedef int fw_yaffs_resize_file_t(void *obj, int size);
extern fw_yaffs_resize_file_t fw_yaffs_resize_file;

/* fw_sqlite_vfs_delete: yaffs-interface.cpp xDelete (the OS's SQLite file layer), 0x01A8E774.
 * yaffs_unlink(path); sync_dir must be 0 (asserts :221). Opus 2's core puts savesafe_delete in
 * its place in the VFS table (0x018C23E0) and calls this after flushing the database the
 * journal belongs to. */
typedef int fw_sqlite_vfs_delete_t(void *vfs, const char *path, int sync_dir);
extern fw_sqlite_vfs_delete_t fw_sqlite_vfs_delete;

/* fw_voice_envelope: the voices' envelope (ADSR) block, 0x01912128. Voice v's envelope for one
 * audio block (IVG11; the L1 voice loop calls it at 0xFFA00B82 for each busy voice, before the
 * render): adsr = 0xFF8000D4 + 0x18 v (+0 stage, +4 blocks, +8 level, 0x40000000 full), env =
 * 128 gains (0xFF801D50) the OS multiplies the render by, params = the slot's 8 envelope
 * values, velocity = the voice's. Moves the stage; returns 1 when the voice is done (the loop
 * clears its busy byte and skips its render). Opus 2 (engines.hooks voice_env) calls it for
 * every voice but an own-envelope engine's. */
typedef int fw_voice_envelope_t(int *adsr, short *env, const short *params, const short *velocity);
extern fw_voice_envelope_t fw_voice_envelope;

/* fw_restart: the OS's restart, 0x01A88794. Restarts the OP-1 at once through the watchdog
 * (WDOG_CTL 0x0AD0, WDOG_CNT 1, WDOG_CTL 0x0FF0: on, its expiry a reset) and spins until it
 * does; te-boot starts the OS again, SDRAM kept. Nothing is synced first: Opus 2's push
 * (push.c) calls loader_shutdown("/yaffs2") before it, as a power-off syncs. */
typedef void fw_restart_t(void);
extern fw_restart_t fw_restart;

/* fw_string_assign: std::string::assign (Dinkumware), 0x019FF0BC. dst := src's characters from
 * pos, at most n (n -1: to the end); both are the OS's 28-byte std::string (+4 the text inline
 * while the capacity +0x18 is 15, else a heap pointer there; +0x14 the size). An out-of-range
 * pos is the library's error. The synth loader sets each entry's folder (+0x14) with it
 * (0x01A0578C). */
typedef void *fw_string_assign_t(void *dst, const void *src, unsigned pos, unsigned n);
extern fw_string_assign_t fw_string_assign;

/* fw_os_free: operator delete (the OS heap, TLSF), 0x01A5E310. Frees a block of the OS's own
 * heap under its lock: a std::string's text when its capacity is above 15 (the OS's own
 * pattern after an asString into a local), a jsoncpp node. Thread context. */
typedef void fw_os_free_t(void *p);
extern fw_os_free_t fw_os_free;

/* fw_frame_sender: the display's frame sender, 0x01A2FB68. Called by the panel's vsync handler
 * 0xFFA057B0 (IVG13) at every second PG3 edge with 1 (loaded at 0xFFA05836): once the render
 * thread's post [0x018B644C] is set, swaps buffers and posts it; then, if the ready byte
 * B[0x018B64AD] is set (or fewer than 2 frames ever started), starts a frame from
 * [0x018B64B0]. Through the whole boot, from the logo's first frames (0.6 G cycles), every 2
 * vsyncs. Interrupt context. */
typedef void fw_frame_sender_t(int vsync);
extern fw_frame_sender_t fw_frame_sender;

/* fw_frame_ready: the next frame named and marked ready, 0x01A366EC. [0x018B64B0] = frame,
 * B[0x018B64AD] = 1: the vsync's next sender call starts its DMA (0x4A codec boards). The
 * render thread's after each render; before the render thread runs, a frame put there is sent
 * once. */
typedef void fw_frame_ready_t(unsigned short *frame);
extern fw_frame_ready_t fw_frame_ready;

/* fw_fat_check: the USB disk's check, 0x01996F38. The wipe of every unknown file, the tracks'
 * and sides' check, the fragment count and the defragmenter; OP_Main at boot (0x019F0354,
 * after the sync 0x01996530) and at disk mode's no-change end (0x0199758E). Thread context,
 * FatFs mounted. */
typedef void fw_fat_check_t(void);
extern fw_fat_check_t fw_fat_check;

/* fw_bg_register: the background saver's base constructor, 0x0193F010. Writes the base table
 * 0x0190F284 at obj+4 (its save the pure-virtual stub), clears obj's dirty and pending bytes
 * and adds obj to the saver's vector: write the object's own table after it. Thread context. */
typedef void fw_bg_register_t(void *obj);
extern fw_bg_register_t fw_bg_register;

/* fw_knob_touched: an encoder's touched flag, 0x019D7E78. B[0x01DD7F74 + encoder] = 1 (0 blue
 * to 3 orange; asserts outside): the OS's own knob path sets it, and stock effect screens fade
 * a value in while it is set (delay's INPUT, read through 0x01A3BC44 -> 0x019D7C84);
 * 0x019D7ED0 clears all four. KeyHandler. */
typedef void fw_knob_touched_t(int encoder);
extern fw_knob_touched_t fw_knob_touched;

/* fw_slot_sampler: a synth slot's sampler object, 0x01A51DE8. Returns the slot's 8-byte object
 * {+0 SampleBuffer *, +4 the rate from base_freq}; asserts SynthSampler.cpp:165 outside 0-7.
 * SampleBuffer +0 m_buffer (the sound from m_buffer[8]), +0x1038 m_length (264,608). */
typedef void *fw_slot_sampler_t(int slot);
extern fw_slot_sampler_t fw_slot_sampler;

/* fw_string_equals: std::string == a C string, 0x01A01094. 1 when the OS's std::string equals
 * lit, else 0 (the start's sampler test at 0x01A01844, samples.hooks). */
typedef int fw_string_equals_t(const void *s, const char *lit);
extern fw_string_equals_t fw_string_equals;

/* fw_type_is_sampler: a preset type is sampler, 0x01940770. 1 when the OS's std::string equals
 * sampler; the browse and revert job's two tests (0x0194083A load, 0x019408DE copy). */
typedef int fw_type_is_sampler_t(const void *type);
extern fw_type_is_sampler_t fw_type_is_sampler;

/* fw_synth_sample_load: a synth slot's sample from a file, 0x0199FCE4. path: the OS's
 * std::string (e.g. /yaffs2//user/audio/synth/synth_N.raw); 0x01A51DE8(slot)'s SampleBuffer
 * reads it (0x01A348E8: the file, the rest zero-filled, the peaks rebuilt). Called by the
 * start (0x01A01920), the browse job (0x01940A42) and the sample column (0x0194017A); 10-13 M
 * cycles. */
typedef void fw_synth_sample_load_t(int slot, const void *path);
extern fw_synth_sample_load_t fw_synth_sample_load;

/* fw_sampler_set: the sampling's finish: the slot a fresh sampler, 0x01A02A46. 0x01A00850 on
 * the slot's object (0x01DDD7E8 + 0x38 x slot): type sampler, name user, knobs [0, 0, end,
 * end, 12000, 0, 0, 0x2D3F], base_freq, octave 0, the adsr's defaults, synth_version 2;
 * applied, its row written. end: the recorded end as a fraction of the buffer (0-32767).
 * Called by the finish 0x019DEE1C at 0x019DEEF2 (samples.hooks); KeyHandler. */
typedef void fw_sampler_set_t(int slot, float base_freq, int end);
extern fw_sampler_set_t fw_sampler_set;

/* fw_disk_string_equals: std::string == a C string (the USB disk's), 0x0199D498. 1 when the
 * OS's std::string equals lit, else 0; the disk mode's export (0x0199DC0E) and import
 * (0x0199F52A) ask it whether a preset is a sampler's (samples.hooks). */
typedef int fw_disk_string_equals_t(const void *s, const char *lit);
extern fw_disk_string_equals_t fw_disk_string_equals;

/* fw_list_child: the browser list's add into a folder, 0x01A185F4. folder, label: std::strings
 * (the OS's layout; the list keeps copies). Finds the entry labelled folder (made on first
 * use, id -1: a folder row with a column) and adds {label, id} to its children; the engine
 * list's sampler column (0x01A025B2: folder sampler, label the preset's name, id minus its
 * index) and Opus's sample engines' columns. */
typedef void fw_list_child_t(void *list, const void *folder, const void *label, int id);
extern fw_list_child_t fw_list_child;

/* fw_file_copy: a file copied, 0x0199FD24. dst, src: std::string paths; src opened first (read
 * only). Hold-to-save's preset .raw from synth_N.raw (0x019AD4D2), the browse job's
 * synth_N.raw from the preset's .raw (0x01940950), the sample column's (0x01940250). */
typedef void fw_file_copy_t(const void *dst, const void *src);
extern fw_file_copy_t fw_file_copy;

/* fw_f_rename: ff.c f_rename, 0x0199CBEC. 8 (FR_EXIST) when the new name exists: FatFs R0.08
 * replaces nothing (remove the old first); both paths on the one volume, mounted. ff.c order:
 * after f_mkdir. */
typedef int fw_f_rename_t(const char *path_old, const char *path_new);
extern fw_f_rename_t fw_f_rename;

/* fw_vdk_create_semaphore: VDK CreateSemaphore, 0xFFA0AD80. A counting semaphore's id; db2
 * makes its lock with (1, 1, 0, 0). Thread context. */
typedef int fw_vdk_create_semaphore_t(int initial, int max, unsigned delay, unsigned period);
extern fw_vdk_create_semaphore_t fw_vdk_create_semaphore;

/* fw_vdk_pend_semaphore: VDK PendSemaphore, 0xFFA0B6E8. Waits for the semaphore (timeout 0:
 * for ever, as db2 does). Thread context only, never in an interrupt; not recursive. */
typedef int fw_vdk_pend_semaphore_t(int sem, unsigned timeout);
extern fw_vdk_pend_semaphore_t fw_vdk_pend_semaphore;

/* fw_vdk_post_semaphore: VDK PostSemaphore, 0xFFA0B96C. */
typedef void fw_vdk_post_semaphore_t(int sem);
extern fw_vdk_post_semaphore_t fw_vdk_post_semaphore;

/* fw_save_overlay_count: the save overlay counting, 0x01A3AAA0. Shows the save overlay with
 * its clock's hand at counter (320 the start of one clockwise turn, 0 its end), the slot's
 * number and the synth's or the drum's icon; the OS calls it every OP_Main pass of its
 * countdown from 320 down. OP_Main. */
typedef void fw_save_overlay_count_t(int slot, int counter, int is_synth);
extern fw_save_overlay_count_t fw_save_overlay_count;

/* fw_save_overlay_off: the save overlay hidden, 0x01A3AA58. The overlay off (the OS: a
 * countdown cancelled). Plain stores: any thread. */
typedef void fw_save_overlay_off_t(void);
extern fw_save_overlay_off_t fw_save_overlay_off;

/* fw_dbox_voice: dbox.cpp dbox::voice, 0x0197189C. dbox's voice i (0-11): its object at
 * 0xFFB00000 + 0x48 i (L1), made on demand (dbox.cpp:264 asserts the range); the drum
 * factory's case 9 calls it for each of the twelve, then dbox::set_voice (+0x14 = i). */
typedef void *fw_dbox_voice_t(int i);
extern fw_dbox_voice_t fw_dbox_voice;

/* fw_drum_post_apply: keys::set_5030, 0x019C2BA0. */
typedef void fw_drum_post_apply_t(int slot);
extern fw_drum_post_apply_t fw_drum_post_apply;

/* fw_drum_t1_screen: ScreenId.cpp (the drum chooser), 0x01A3BFDA. A drum engine number's T1
 * screen id: 8 (the sampler drum) 0x10, 9 (dbox) 0x11; any other a fatal assert
 * (ScreenId.cpp:74 no screen found for drum %i). */
typedef int fw_drum_t1_screen_t(int engine);
extern fw_drum_t1_screen_t fw_drum_t1_screen;

/* fw_drum_list_pos: patch.cpp patch::drum_slot_type_id, 0x01A01FFE. The drum engine list's row
 * to open on for drum slot (DrumController::shift_key_down, before the list's build):
 * patch::drum_type_id of the slot's kit (dbox's row for any dbox kit); the synth's twin is
 * fw_list_pos. */
typedef int fw_drum_list_pos_t(int slot, char *found);
extern fw_drum_list_pos_t fw_drum_list_pos;

/* fw_synth_key_down: synth_controller::key_down, 0x01A51058. The synth mode's key-down (vtable
 * 0x01911994 slot 2): for key 0x24 (left) and 0x25 (right) the octave step down or up, its
 * popup and the slot's sound keeping it, as the plain arrows do in stock; ctl is not read for
 * those two keys (pass 0). Returns 1 when it took the key. KeyHandler thread. */
typedef int fw_synth_key_down_t(void *ctl, unsigned key);
extern fw_synth_key_down_t fw_synth_key_down;

#endif
